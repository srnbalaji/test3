# Databricks notebook source
# MAGIC %run ./common_functions 

# COMMAND ----------

# ================================================================
# Source Connectors
# ================================================================

def _parse_config(connection_config: str) -> dict:
    """
    Parse the connection_config string.
    Supports two formats:
      1. Valid JSON with key:value pairs, e.g.:
         {"host":"...", "port":"...", "database":"...", "user":"...", "password":"..."}
      2. Comma-separated list of secret key names (no key:value), e.g.:
         {"WindBIOracleDev_DB_host","WindBIOracleDev_DB_port","WindBIOracleDev_DB_Name","WindBIOracleDev_DB_user","WindBIOracleDev_DB_pwd"}
         These are mapped positionally to: host, port, database, user, password
    """
    try:
        return json.loads(connection_config)
    except json.JSONDecodeError:
        # Handle set-like format: {"key1","key2","key3",...}
        # Strip braces, split by comma, strip quotes/spaces
        stripped = connection_config.strip().strip('{}')
        keys = [k.strip().strip('"').strip("'") for k in stripped.split(',')]
        # Map positionally: host, port, database, user, password
        field_names = ["host", "port", "database", "user", "password"]
        cfg = {}
        for i, field in enumerate(field_names):
            if i < len(keys):
                cfg[field] = keys[i]
        return cfg


def _readsecrets() -> dict:
    import json
    import re
    import boto3    

    SERVICE_CREDENTIAL = "epdnv-of567-neers-geniq-service-credential"
    SECRET_ID = "2giqnv-ne338-geniq-Databricks-Secret"
    REGION = "us-east-1"

    boto3_session = boto3.Session(
        botocore_session=dbutils.credentials.getServiceCredentialsProvider(SERVICE_CREDENTIAL),
        region_name=REGION
    )

    # Retrieve the secret from the remote AWS account
    sm_client = boto3_session.client("secretsmanager")
    response = sm_client.get_secret_value(SecretId=SECRET_ID)

    # Fix invalid backslash escapes before JSON parsing
    raw_secret = response["SecretString"]
    fixed_secret = re.sub(r'\\(?!["\\\//bfnrtu])', r'\\\\', raw_secret)
    secret_dict = json.loads(fixed_secret)
    return secret_dict


def _resolve(secret_dict: dict, key: str) -> str:
    """
    Resolve a config value: if it exists as a key in secret_dict, return
    the secret value. Otherwise treat it as a literal value.
    """
    return secret_dict.get(key, key)


# ------------------------------------------------------------------
# JDBC Connectors
# ------------------------------------------------------------------
# connection_config JSON expected keys:
#   host, port, database, user, password
#   These values are either KEY NAMES in the AWS secret dictionary
#   or literal values. The _resolve() helper handles both cases.
#   (optional) fetch_size, driver_class, extra_options {}
#
# NOTE: The Oracle JDBC driver (ojdbc8.jar) must be installed as a
#       cluster library. Dynamic JAR loading (ADD JAR, spark._jvm) is
#       not supported on User Isolation (Unity Catalog) clusters.
#       Install via: Cluster → Libraries → Install New → Maven:
#         com.oracle.database.jdbc:ojdbc8:21.9.0.0
#       Or upload the JAR from:
#         /Workspace/GenIQ WindBI/geniq/drivers/ojdbc8.jar
#
# NOTE: For SQL Server, install the JDBC driver as a cluster library:
#       Maven: com.microsoft.sqlserver:mssql-jdbc:12.4.2.jre11
# ------------------------------------------------------------------

def _jdbc_url(source_type: str, cfg: dict) -> str:
    """Build the JDBC URL based on source type."""
    # Fetch the secret dictionary from AWS Secrets Manager
    secret_dict = _readsecrets()

    # Resolve cfg values using dict comprehension — look up in secret_dict
    required_keys = [cfg["host"], cfg["port"], cfg["database"]]
    mapped_config = {key: secret_dict.get(key) for key in required_keys if key in secret_dict}

    # Get host, port, db — use mapped value if found, otherwise use literal
    host = mapped_config.get(cfg["host"], cfg["host"])
    port = mapped_config.get(cfg["port"], cfg["port"])
    db   = mapped_config.get(cfg["database"], cfg["database"])

    if source_type == "jdbc_oracle":
        # Oracle thin driver (ojdbc8.jar must be pre-installed as cluster library)
        return f"jdbc:oracle:thin:@{host}:{port}/{db}"
    elif source_type == "jdbc_rds":
        # RDS MySQL or PostgreSQL – dialect key selects driver
        dialect = cfg.get("dialect", "postgresql")
        return f"jdbc:{dialect}://{host}:{port}/{db}"
    elif source_type == "jdbc_redshift":
        return f"jdbc:redshift://{host}:{port}/{db}"
    elif source_type == "jdbc_sqlserver":
        # Microsoft SQL Server
        # Handle named instance: host may contain backslash (e.g. GOXSA4865\WI576T)
        # Split into hostname and instance name, and append FQDN suffix
        if "\\" in host:
            server_name, instance_name = host.split("\\", 1)
        else:
            server_name = host
            instance_name = None
        
        # Append FQDN suffix if the server name is a short NetBIOS name
        if "." not in server_name:
            server_name = f"{server_name}.fplu.fpl.com"
        
        url = f"jdbc:sqlserver://{server_name}:{port};databaseName={db};encrypt=true;trustServerCertificate=true"
        if instance_name:
            url = f"jdbc:sqlserver://{server_name}:{port};instanceName={instance_name};databaseName={db};encrypt=true;trustServerCertificate=true"
        return url
    else:
        raise ValueError(f"Unknown JDBC source type: {source_type}")


def _jdbc_driver(source_type: str, cfg: dict) -> str:
    """Return the JDBC driver class name."""
    if cfg.get("driver_class"):
        return cfg["driver_class"]
    drivers = {
        "jdbc_oracle":     "oracle.jdbc.driver.OracleDriver",
        "jdbc_rds":        "org.postgresql.Driver",  # override via driver_class for MySQL
        "jdbc_redshift":   "com.amazon.redshift.jdbc42.Driver",
        "jdbc_sqlserver":  "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    }
    return drivers[source_type]


def read_jdbc(source_type: str, cfg: dict, source_schema: str,
              source_table: str, source_sql: str, ingestion_mode: str,
              incremental_column: str = None,
              watermark_value: str = None) -> DataFrame:
    """Read from a JDBC source (Oracle / RDS / Redshift / SQL Server).
    If source_sql is provided, use it directly as the query
    and ignore source_schema & source_table."""
    url    = _jdbc_url(source_type, cfg)
    driver = _jdbc_driver(source_type, cfg)

    # Fetch credentials from AWS Secrets Manager using cfg key names
    secret_dict = _readsecrets()
    required_keys = [cfg["user"], cfg["password"]]
    mapped_config = {key: secret_dict.get(key) for key in required_keys if key in secret_dict}

    user = mapped_config.get(cfg["user"], cfg["user"])
    pwd  = mapped_config.get(cfg["password"], cfg["password"])

    fetch_size = str(cfg.get("fetch_size", 10000))

    # Priority: source_sql > source_schema.source_table
    if source_sql and source_sql.strip():
        query = f"({source_sql}) src_qry"
    else:
        dbtable = f"{source_schema}.{source_table}" if source_schema else source_table
        if ingestion_mode == "incremental" and watermark_value:
            query = f"(SELECT * FROM {dbtable} WHERE {incremental_column} > '{watermark_value}') src_qry"
        else:
            query = dbtable

    reader = (
        spark.read.format("jdbc")
        .option("url", url)
        .option("dbtable", query)
        .option("user", user)
        .option("password", pwd)
        .option("driver", driver)
        .option("fetchsize", fetch_size)
    )
    # Apply any extra JDBC options
    for k, v in cfg.get("extra_options", {}).items():
        reader = reader.option(k, str(v))

    return reader.load()


# ------------------------------------------------------------------
# REST API Connector
# ------------------------------------------------------------------
def read_rest_api(cfg: dict) -> DataFrame:
    """Read data from a paginated REST API and return a Spark DataFrame."""
    url     = cfg["url"]
    method  = cfg.get("method", "GET").upper()
    headers = cfg.get("headers", {})
    params  = dict(cfg.get("params", {}))

    # ---------- authentication ----------
    auth_type = cfg.get("auth_type", "none")
    auth = None
    if auth_type == "bearer":
        token = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_token"])
        headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic":
        u = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_user"])
        p = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_password"])
        auth = (u, p)

    # ---------- pagination ----------
    pagination = cfg.get("pagination")
    json_path  = cfg.get("response_json_path", "")
    all_records = []

    def _extract(body, path):
        """Walk the dot-separated path into the JSON body."""
        obj = body
        for p in path.split(".") if path else []:
            obj = obj[p]
        return obj if isinstance(obj, list) else [obj]

    if pagination and pagination.get("type") == "offset":
        offset = 0
        page_size = int(pagination.get("page_size", 100))
        while True:
            params[pagination["limit_param"]]  = page_size
            params[pagination["offset_param"]] = offset
            resp = requests.request(method, url, headers=headers, params=params, auth=auth, timeout=120)
            resp.raise_for_status()
            records = _extract(resp.json(), json_path)
            if not records:
                break
            all_records.extend(records)
            offset += page_size
    elif pagination and pagination.get("type") == "cursor":
        cursor = None
        page_size = int(pagination.get("page_size", 100))
        while True:
            params[pagination["limit_param"]] = page_size
            if cursor:
                params[pagination.get("cursor_param", "cursor")] = cursor
            resp = requests.request(method, url, headers=headers, params=params, auth=auth, timeout=120)
            resp.raise_for_status()
            body = resp.json()
            records = _extract(body, json_path)
            if not records:
                break
            all_records.extend(records)
            cursor = body.get(pagination.get("cursor_field", "next_cursor"))
            if not cursor:
                break
    else:
        resp = requests.request(method, url, headers=headers, params=params, auth=auth, timeout=120)
        resp.raise_for_status()
        all_records = _extract(resp.json(), json_path)

    if not all_records:
        return spark.createDataFrame([], StructType([]))

    return spark.createDataFrame(all_records)


# ------------------------------------------------------------------
# SFTP Connector
# ------------------------------------------------------------------
def read_sftp(cfg: dict) -> DataFrame:
    """
    Read files from an SFTP server.
    Downloads files to a temp volume, then reads them with Spark.
    """
    import paramiko
    import os
    import fnmatch

    host = cfg["host"]
    port = int(cfg.get("port", 22))
    user = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_user"])
    pwd  = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_password"])
    remote_path  = cfg["remote_path"]
    file_format  = cfg.get("file_format", "csv")
    file_pattern = cfg.get("file_pattern", "*")
    read_opts    = cfg.get("read_options", {})
    local_tmp    = cfg.get("local_tmp_path", "/tmp/sftp_staging")

    os.makedirs(local_tmp, exist_ok=True)

    transport = paramiko.Transport((host, port))
    transport.connect(username=user, password=pwd)
    sftp = paramiko.SFTPClient.from_transport(transport)

    downloaded_files = []
    for fname in sftp.listdir(remote_path):
        if fnmatch.fnmatch(fname, file_pattern):
            remote_file = f"{remote_path}/{fname}"
            local_file  = f"{local_tmp}/{fname}"
            sftp.get(remote_file, local_file)
            downloaded_files.append(local_file)

    sftp.close()
    transport.close()

    if not downloaded_files:
        print("  ⚠ No files matched pattern on SFTP server")
        return spark.createDataFrame([], StructType([]))

    dbfs_staging = f"dbfs:/tmp/sftp_staging/{uuid.uuid4()}"
    for lf in downloaded_files:
        dbutils.fs.cp(f"file:{lf}", f"{dbfs_staging}/{os.path.basename(lf)}")

    reader = spark.read.format(file_format)
    for k, v in read_opts.items():
        reader = reader.option(k, v)

    df = reader.load(dbfs_staging)
    dbutils.fs.rm(dbfs_staging, recurse=True)
    return df


# ------------------------------------------------------------------
# Unity Catalog Volume Connector
# ------------------------------------------------------------------
def read_volume(cfg: dict) -> DataFrame:
    """
    Read files from a Unity Catalog Volume.
    Directly reads from the Volume path — no staging or downloads needed.
    """
    volume_path  = cfg["volume_path"].rstrip("/")
    file_format  = cfg.get("file_format", "csv").lower()
    file_pattern = cfg.get("file_pattern", "")
    read_opts    = cfg.get("read_options", {})

    read_path = f"{volume_path}/{file_pattern}" if file_pattern else volume_path

    default_opts = {
        "csv":  {"header": "true", "inferSchema": "true"},
        "json": {"multiLine": "true"},
    }
    merged_opts = {**default_opts.get(file_format, {}), **read_opts}

    reader = spark.read.format(file_format)
    for k, v in merged_opts.items():
        reader = reader.option(k, str(v))

    df = reader.load(read_path)
    print(f"  ✔ Volume read complete: {read_path}  ({file_format})")
    return df


# ------------------------------------------------------------------
# Unified source reader
# ------------------------------------------------------------------
def read_source(row: dict) -> DataFrame:
    """Route to the correct connector based on source_type."""
    cfg = _parse_config(row["connection_config"])
    src_type = row["source_type"].strip().lower()

    if src_type.startswith("jdbc"):
        return read_jdbc(
            source_type=src_type,
            cfg=cfg,
            source_schema=row.get("source_schema"),
            source_table=row.get("source_table"),
            source_sql=row.get("source_sql"),
            ingestion_mode=row["ingestion_mode"],
            incremental_column=row.get("incremental_column"),
            watermark_value=row.get("watermark_value"),
        )
    elif src_type == "rest_api":
        return read_rest_api(cfg)
    elif src_type == "sftp":
        return read_sftp(cfg)
    elif src_type == "volume":
        return read_volume(cfg)
    else:
        raise ValueError(f"Unsupported source_type: {src_type}")


print("✔ Source connectors loaded (JDBC [Oracle, RDS, Redshift, SQL Server], REST API, SFTP, Volume)")

# COMMAND ----------

# # Retrieve secrets from AWS Secrets Manager and inspect all key-value pairs
# secret_dict = _readsecrets()

# # Display all keys and their values (mask passwords)
# print("Available keys and values in secret:")
# print("=" * 60)
# for key in sorted(secret_dict.keys()):
#     value = secret_dict[key]
#     # Mask password values for security
#     if "pwd" in key.lower() or "password" in key.lower():
#         display_value = value[:3] + "*" * (len(value) - 3)
#     else:
#         display_value = value
#     print(f"  {key:40s} = {display_value}")

# print(f"\n{'=' * 60}")
# print(f"Total keys: {len(secret_dict)}")