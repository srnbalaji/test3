# Databricks notebook source
# MAGIC %run ./common_functions 

# COMMAND ----------

# DBTITLE 1,Cell 2
# ================================================================
# Source Connectors (Volume + UC JDBC — no JAR dependency)
# ================================================================

from pyspark.sql import DataFrame
import json

def _parse_config(connection_config: str) -> dict:
    """Parse the JSON connection_config string."""
    return json.loads(connection_config)

# ------------------------------------------------------------------
# Unity Catalog Volume Connector  (CSV / Parquet / JSON / XML)
# ------------------------------------------------------------------
def read_volume(cfg: dict) -> DataFrame:
    """
    Read files from a Unity Catalog Volume.
    Directly reads from the Volume path — no staging or downloads needed.
    """
    volume_path  = cfg["volume_path"].rstrip("/")
    file_format  = cfg.get("file_format", "csv").lower()
    file_pattern = cfg.get("file_pattern", "")
    read_opts    = cfg.get("read_options", {})

    # Build the full read path
    read_path = f"{volume_path}/{file_pattern}" if file_pattern else volume_path

    # Apply sensible defaults per format
    default_opts = {
        "csv":  {"header": "true", "inferSchema": "true"},
        "json": {"multiLine": "true"},
    }
    merged_opts = {**default_opts.get(file_format, {}), **read_opts}

    reader = spark.read.format(file_format)
    for k, v in merged_opts.items():
        reader = reader.option(k, str(v))

    df = reader.load(read_path)
    print(f"  \u2714 Volume read complete: {read_path}  ({file_format})")
    return df

# ------------------------------------------------------------------
# JDBC Connector (Redshift/Other JDBC sources)
# ------------------------------------------------------------------
def read_jdbc(cfg: dict) -> DataFrame:
    """
    Read from a JDBC source using provided connection config.
    """
    url = cfg["url"]
    dbtable = cfg["dbtable"]
    user = cfg.get("user")
    password = cfg.get("password")
    driver = cfg.get("driver", "org.postgresql.Driver")
    reader = (
        spark.read.format("jdbc")
        .option("url", url)
        .option("dbtable", dbtable)
        .option("driver", driver)
    )
    if user:
        reader = reader.option("user", user)
    if password:
        reader = reader.option("password", password)
    return reader.load()

# ------------------------------------------------------------------
# UC JDBC Connector (no JAR required)
# ------------------------------------------------------------------
def read_jdbc_uc(cfg: dict) -> DataFrame:
    """
    Read from a JDBC source using Unity Catalog connection reference.
    No driver JAR needed — UC manages the connection.
    """
    uc_connection = cfg["uc_connection_name"]
    dbtable = cfg["dbtable"]
    user = cfg.get("user")
    password = cfg.get("password")
    fetchsize = cfg.get("fetchsize", 10000)
    reader = (
        spark.read.format("jdbc")
        .option("databricks.connection", uc_connection)
        .option("dbtable", dbtable)
        .option("fetchsize", str(fetchsize))
    )
    if user:
        reader = reader.option("user", user)
    if password:
        reader = reader.option("password", password)
    return reader.load()

# ------------------------------------------------------------------
# Unified source reader
# ------------------------------------------------------------------
def read_source(row: dict) -> DataFrame:
    """Route to the correct connector based on source_type."""
    cfg = _parse_config(row["connection_config"])
    src_type = row["source_type"].strip().lower()

    if src_type == "volume":
        return read_volume(cfg)
    elif src_type.startswith("oracle_connection"):
        uc_connection = cfg.get("uc_connection_name")
        if uc_connection:
            source_sql = row.get("source_sql")
            # Priority: source_sql > source_schema.source_table
            if source_sql and source_sql.strip():
                query = f"({source_sql}) src_qry"
            else:
                dbtable = f"{row['source_schema']}.{row['source_table']}" if row.get("source_schema") else row["source_table"]
                ingestion_mode = row.get("ingestion_mode", "").strip().lower()
                watermark_value = row.get("watermark_value")
                incremental_column = row.get("incremental_column")
                if ingestion_mode == "incremental" and watermark_value:
                    query = f"(SELECT * FROM {dbtable} WHERE {incremental_column} > '{watermark_value}') src_qry"
                else:
                    query = dbtable

            fetchsize = cfg.get("fetchsize", "10000")
            df = (spark.read
                .format("jdbc")
                .option("databricks.connection", uc_connection)
                .option("dbtable", query)
                .option("fetchsize", fetchsize)
                .load())
            return df
    elif src_type.startswith("jdbc"):
        # Build dbtable from source_schema + source_table
        dbtable = f"{row['source_schema']}.{row['source_table']}" if row.get("source_schema") else row["source_table"]
        cfg["dbtable"] = dbtable
        if "uc_connection_name" in cfg:
            return read_jdbc_uc(cfg)
        else:
            return read_jdbc(cfg)
    elif src_type == "rest_api":
        raise ValueError(f"REST API connector not loaded in test mode — source '{row['source_name']}' skipped.")
    elif src_type == "sftp":
        raise ValueError(f"SFTP connector not loaded in test mode — source '{row['source_name']}' skipped.")
    else:
        raise ValueError(f"Unsupported source_type: {src_type}")

print("\u2714 Source connectors loaded (Volume + JDBC + UC JDBC — no JAR dependency)")