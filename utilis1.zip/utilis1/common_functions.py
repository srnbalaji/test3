# Databricks notebook source
# MAGIC %run ./../config1/source_to_target_mapping 

# COMMAND ----------

# ================================================================
# Imports
# ================================================================
import json
import uuid
import requests
from datetime import datetime
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType
from pyspark.sql.window import Window
from delta.tables import DeltaTable

print("✔ Imports loaded")

# COMMAND ----------

# ================================================================
# Helper Utilities
# ================================================================

def generate_batch_id() -> str:
    """Generate a unique batch identifier."""
    return str(uuid.uuid4())


def lowercase_columns(df: DataFrame) -> DataFrame:
    """Rename all DataFrame columns to lowercase."""
    for col_name in df.columns:
        df = df.withColumnRenamed(col_name, col_name.strip().lower())
    return df


def get_fully_qualified_target(row) -> str:
    """Build the lowercase fully-qualified target table name."""
    cat = (row["target_catalog"] or tgt_catalog).strip().lower()
    sch = (row["target_schema"] or bronze_schema).strip().lower()
    tbl = row["target_table"].strip().lower()
    return f"{cat}.{sch}.{tbl}"


# ---------- Bronze Audit Log Helpers ----------
def log_audit_start(source_id: str, source_name: str, batch_id: str,
                    ingestion_mode: str, source_type: str,
                    target_table: str, watermark_before: str) -> str:
    """Insert a 'running' record into the audit log. Returns audit_id."""
    audit_id = str(uuid.uuid4())
    fq_log_tbl = f"{tgt_catalog}.{bronze_schema}.{bronze_log_tbl}"
    spark.sql(f"""
        INSERT INTO {fq_log_tbl}
        (audit_id, source_id, source_name, batch_id, ingestion_mode,
         source_type, target_table, start_time, status, watermark_before)
        VALUES
        ('{audit_id}', '{source_id}', '{source_name}', '{batch_id}',
         '{ingestion_mode}', '{source_type}', '{target_table}',
         current_timestamp(), 'running', '{watermark_before or ""}')
    """)
    return audit_id


def log_audit_end(audit_id: str, status: str, rows_read: int = 0,
                  rows_written: int = 0, watermark_after: str = "",
                  error_message: str = ""):
    """Update the audit log record on completion or failure."""
    err_safe = error_message.replace("'", "''")[:4000]
    fq_log_tbl = f"{tgt_catalog}.{bronze_schema}.{bronze_log_tbl}"
    spark.sql(f"""
        UPDATE {fq_log_tbl}
        SET end_time         = current_timestamp(),
            status           = '{status}',
            rows_read        = {rows_read},
            rows_written     = {rows_written},
            watermark_after  = '{watermark_after or ""}',
            error_message    = '{err_safe}'
        WHERE audit_id = '{audit_id}'
    """)


def update_watermark(source_id: str, new_watermark: str):
    """Persist the latest watermark back into the metadata table."""
    fq_config_tbl = f"{tgt_catalog}.{bronze_schema}.{bronze_config_tbl}"
    spark.sql(f"""
        UPDATE {fq_config_tbl}
        SET watermark_value = '{new_watermark}',
            updated_at      = current_timestamp()
        WHERE source_id = '{source_id}'
    """)


print("✔ Helper utilities loaded")

# COMMAND ----------

# DBTITLE 1,read_source_data — SQL or table fallback
# ================================================================
# Source Data Reader — source_sql or source_schema/source_table
# Supports watermark-based incremental reads
# ================================================================

def read_source_data(source_sql: str, source_fqn: str, source_filter: str = "",
                     watermark_column: str = "", last_processed_at=None) -> "DataFrame":
    """
    Read source data using either a custom SQL query or the fully-qualified table name.

    Priority:
      1. If source_sql is provided (non-empty), execute it via spark.sql()
      2. Otherwise, fall back to spark.table(source_fqn)
    
    After reading, applies:
      - Watermark filter (if watermark_column + last_processed_at are set)
      - source_filter (if any) as an additional WHERE clause

    Parameters
    ----------
    source_sql : str
        Custom SQL query from metadata (source_sql column). If present, this
        takes priority over source_fqn.
    source_fqn : str
        Fully-qualified table name (catalog.schema.table) used as fallback.
    source_filter : str
        Optional filter expression applied after reading.
    watermark_column : str
        Column name in the source used for incremental watermark filtering.
        If set along with last_processed_at, only rows WHERE watermark_column > last_processed_at are read.
    last_processed_at : str or timestamp, optional
        The watermark value from the last successful run. Used to filter new records.

    Returns
    -------
    DataFrame
        The source DataFrame ready for further processing.
    """
    if source_sql and source_sql.strip():
        print(f"    ▶ Reading source via custom SQL query")
        source_df = spark.sql(source_sql.strip())
    else:
        print(f"    ▶ Reading source from table: {source_fqn}")
        source_df = spark.table(source_fqn)

    # Apply watermark-based incremental filter
    if watermark_column and watermark_column.strip() and last_processed_at:
        wm_filter = f"{watermark_column.strip()} > '{last_processed_at}'"
        print(f"    ▶ Applying watermark filter: {wm_filter}")
        source_df = source_df.filter(wm_filter)
    elif watermark_column and watermark_column.strip() and not last_processed_at:
        print(f"    ℹ Watermark column '{watermark_column}' configured but no last_processed_at — full read (first run)")

    # Apply additional source_filter if configured
    if source_filter and source_filter.strip():
        print(f"    ▶ Applying source_filter: {source_filter}")
        source_df = source_df.filter(source_filter.strip())

    return source_df


def get_max_watermark(df: "DataFrame", watermark_column: str):
    """
    Get the max value of the watermark column from the processed DataFrame.
    This value is saved to last_processed_at for the next incremental run.

    Parameters
    ----------
    df : DataFrame
        The processed source DataFrame.
    watermark_column : str
        The column to compute MAX on.

    Returns
    -------
    str or None
        The max watermark value as a string, or None if not applicable.
    """
    if not watermark_column or not watermark_column.strip():
        return None

    max_val = df.agg(F.max(F.col(watermark_column.strip()))).collect()[0][0]
    if max_val is not None:
        print(f"    ▶ New watermark value ({watermark_column}): {max_val}")
        return str(max_val)
    return None


def save_watermark(processing_id, max_watermark_value, config_table_fqn):
    """
    Save the max watermark value to last_processed_at in the metadata table.
    Called after successful processing when watermark_column is configured.

    Parameters
    ----------
    processing_id : int
        The processing_id of the current row in metadata.
    max_watermark_value : str
        The max watermark timestamp to store.
    config_table_fqn : str
        Fully-qualified name of the silver metadata config table.
    """
    if max_watermark_value:
        spark.sql(f"""
            UPDATE {config_table_fqn}
            SET last_processed_at = '{max_watermark_value}', updated_at = current_timestamp()
            WHERE processing_id = {processing_id}
        """)
        print(f"    ✔ Watermark saved: last_processed_at = {max_watermark_value}")


print("✔ read_source_data + watermark helpers loaded")

# COMMAND ----------

# ================================================================
# Schema Evolution
# ================================================================

def evolve_schema(df: DataFrame, target_table: str) -> DataFrame:
    """
    Handle schema evolution between incoming DataFrame and existing target table.
    - New columns in source are added to the target via mergeSchema.
    - Columns that exist in target but not in source are left untouched (NULLs).
    - Returns the DataFrame aligned to write safely with mergeSchema enabled.
    """
    if not spark.catalog.tableExists(target_table):
        print(f"  ℹ Target table {target_table} does not exist yet – will be created on first write")
        return df

    target_cols = {f.name.lower(): f.dataType for f in spark.table(target_table).schema.fields}
    source_cols = {f.name.lower(): f.dataType for f in df.schema.fields}

    new_cols = set(source_cols.keys()) - set(target_cols.keys())
    if new_cols:
        print(f"  📌 Schema evolution: new columns detected -> {new_cols}")

    # Log type mismatches as warnings (Delta handles safe casts)
    for col in set(source_cols.keys()) & set(target_cols.keys()):
        if source_cols[col] != target_cols[col]:
            print(f"  ⚠ Column '{col}' type mismatch: source={source_cols[col]} vs target={target_cols[col]}")

    return df


print("✔ Schema evolution logic loaded")

# COMMAND ----------

# DBTITLE 1,add_audit_columns
def add_audit_columns(df: DataFrame, source_name: str, batch_id: str,
                      target_table: str = None, key_columns: list = None,
                      ingestion_mode: str = "full_load",
                      cdc_operation_col: str = None) -> DataFrame:
    """
    Append standard audit columns and write to target.
    - full_load / append: sets both inserted_at and updated_at, returns DataFrame.
    - merge: performs MERGE INTO target; inserted_at on INSERT, updated_at on UPDATE.
    - cdc: processes CDC feed (INSERT/UPDATE/DELETE) based on operation column.
    """
    # Add source system and batch columns
    df = (df
        .withColumn("dl_source_system", F.lit(source_name))
        .withColumn("dl_batch_id", F.lit(batch_id))
    )

    if ingestion_mode == "merge":
        # --- MERGE path ---
        if not target_table or not key_columns:
            raise ValueError("target_table and key_columns are required for merge mode")

        df.createOrReplaceTempView("_merge_source")

        join_condition = " AND ".join([f"target.{k} = source.{k}" for k in key_columns])

        # UPDATE: refresh only updated_at
        update_cols = [c for c in df.columns if c not in key_columns]
        set_clause = ", ".join([f"target.{c} = source.{c}" for c in update_cols])
        set_clause += ", target.bronze_dwh_updated_at = current_timestamp()"

        # INSERT: set both timestamps
        all_cols = df.columns
        insert_cols = ", ".join(all_cols + ["bronze_dwh_inserted_at", "bronze_dwh_updated_at"])
        insert_vals = ", ".join([f"source.{c}" for c in all_cols] + ["current_timestamp()", "current_timestamp()"])

        spark.sql(f"""
            MERGE INTO {target_table} AS target
            USING _merge_source AS source
            ON {join_condition}
            WHEN MATCHED THEN UPDATE SET {set_clause}
            WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})
        """)
        return None

    elif ingestion_mode == "cdc":
        # --- CDC path ---
        if not target_table or not key_columns or not cdc_operation_col:
            raise ValueError("target_table, key_columns, and cdc_operation_col are required for cdc mode")

        # Separate CDC operations
        df_inserts = df.filter(F.upper(F.col(cdc_operation_col)).isin("I", "INSERT"))
        df_updates = df.filter(F.upper(F.col(cdc_operation_col)).isin("U", "UPDATE"))
        df_deletes = df.filter(F.upper(F.col(cdc_operation_col)).isin("D", "DELETE"))

        # Drop the CDC operation column before writing
        data_cols = [c for c in df.columns if c != cdc_operation_col]

        # Combine inserts + updates for MERGE
        df_upserts = df_inserts.unionByName(df_updates).select(data_cols)
        df_upserts.createOrReplaceTempView("_cdc_upserts")

        join_condition = " AND ".join([f"target.{k} = source.{k}" for k in key_columns])

        # UPDATE: refresh only updated_at
        update_cols = [c for c in data_cols if c not in key_columns]
        set_clause = ", ".join([f"target.{c} = source.{c}" for c in update_cols])
        set_clause += ", target.bronze_dwh_updated_at = current_timestamp()"

        # INSERT: set both timestamps
        insert_cols = ", ".join(data_cols + ["bronze_dwh_inserted_at", "bronze_dwh_updated_at"])
        insert_vals = ", ".join([f"source.{c}" for c in data_cols] + ["current_timestamp()", "current_timestamp()"])

        # MERGE for inserts + updates
        spark.sql(f"""
            MERGE INTO {target_table} AS target
            USING _cdc_upserts AS source
            ON {join_condition}
            WHEN MATCHED THEN UPDATE SET {set_clause}
            WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})
        """)

        # Handle DELETES
        if df_deletes.count() > 0:
            df_deletes.select(key_columns).createOrReplaceTempView("_cdc_deletes")
            delete_condition = " AND ".join([f"target.{k} = source.{k}" for k in key_columns])
            spark.sql(f"""
                DELETE FROM {target_table} AS target
                WHERE EXISTS (
                    SELECT 1 FROM _cdc_deletes AS source
                    WHERE {delete_condition}
                )
            """)

        return None

    else:
        # --- full_load / append path ---
        return (
            df
            .withColumn("bronze_dwh_inserted_at", F.current_timestamp())
            .withColumn("bronze_dwh_updated_at", F.current_timestamp())
        )

# COMMAND ----------

import json
def _apply_rename_columns(df: DataFrame, rename_columns_json: str) -> DataFrame:
    """
    Rename DataFrame columns based on a JSON mapping from the metadata table.
    Keys = current (lowercased) column names, Values = desired target column names.
    Only renames columns that actually exist in the DataFrame.
    """
    if not rename_columns_json or rename_columns_json.strip() == "":
        return df

    try:
        rename_map = json.loads(rename_columns_json)
    except (json.JSONDecodeError, TypeError):
        print("  ⚠ Could not parse rename_columns JSON – skipping rename")
        return df

    existing_cols = set(df.columns)
    for old_name, new_name in rename_map.items():
        if old_name in existing_cols:
            df = df.withColumnRenamed(old_name, new_name)
    return df 



print("✔ Rename columns logic loaded")

# COMMAND ----------

# DBTITLE 1,auto_align_source_types
# ---------------------------------------------------------------
# Auto Source Type Alignment — Bronze Layer
# Inspects the DataFrame schema once and auto-casts:
#   DecimalType(p, 0)  p <= 9   → IntegerType
#   DecimalType(p, 0)  p <= 18  → LongType
#   DecimalType(p, 0)  p >  18  → LongType   (best-effort, avoids overflow)
#   DecimalType(p, s)  s >  0   → DoubleType
#   TimestampType      → TimestampType (always kept as-is)
#   All other types    → passed through unchanged
# column_overrides dict allows per-column manual control.
# ---------------------------------------------------------------
import re
from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from pyspark.sql.types import (
    DecimalType as _DecimalType,
    TimestampType as _TimestampType,
    IntegerType,
    LongType,
    DoubleType,
    FloatType,
    DateType,
    StringType,
    TimestampType,
    BooleanType,
)

# Mapping of target type string keys to PySpark types
_CAST_TYPE_MAP = {
    "int": IntegerType(),
    "bigint": LongType(),
    "double": DoubleType(),
    "float": FloatType(),
    "date": DateType(),
    "timestamp": TimestampType(),
    "string": StringType(),
    "boolean": BooleanType(),
}

# Default patterns to detect DATE-only columns (Oracle DATE → TimestampType)
_DEFAULT_DATE_PATTERNS = [
    r".*_date$", r".*_dt$", r"^date_.*", r"^dt_.*",
    r".*_on$", r".*_day$",
]

# Default patterns to detect TIMESTAMP columns that should stay as TimestampType
# NOTE: Patterns are ONLY evaluated for columns already typed as TimestampType.
# Non-temporal columns (e.g. created_by:StringType) never enter this branch.
# Still, we use precise suffixes to avoid false positives and improve readability.
_DEFAULT_TIMESTAMP_PATTERNS = [
    r".*_timestamp$", r".*_ts$", r"^timestamp_.*", r"^ts_.*",
    r".*_at$", r".*_time$", r".*_dttm$", r".*_datetime$",
    # Audit columns: only match temporal suffixes, NOT _by/_name/_id/_user
    r"^created_(at|time|ts|timestamp|dttm|datetime)$",
    r"^updated_(at|time|ts|timestamp|dttm|datetime)$",
    r"^modified_(at|time|ts|timestamp|dttm|datetime)$",
    r"^inserted_(at|time|ts|timestamp|dttm|datetime)$",
    r"^deleted_(at|time|ts|timestamp|dttm|datetime)$",
    # Explicit _on audit columns — keep as TimestampType (takes priority over .*_on$ date pattern)
    r"^created_on$",
    r"^updated_on$",
    r"^modified_on$",
    r"^inserted_on$",
    r"^deleted_on$",
    # Staging columns that carry time (e.g. stg_insert_date, stg_load_date)
    r"stg_.*_date$",
    # Audit date columns that should remain as TimestampType
    r"^created_date$",
    r"^modified_date$",
]


def auto_align_source_types(
    df: DataFrame,
    date_name_patterns: list = None,
    timestamp_name_patterns: list = None,
    column_overrides: dict = None,
    int_precision_threshold: int = 9,
    bigint_precision_threshold: int = 18,
    verbose: bool = True,
) -> DataFrame:
    """
    Auto-detect source type mismatches and cast columns to Databricks
    bronze-layer target types without requiring the caller to enumerate
    each column manually.

    Detection rules (applied in order):
      1. column_overrides      — explicit per-column override wins over all.
      2. DecimalType(p, 0)     — scale=0 numerics:
           p <= int_precision_threshold   -> IntegerType  (default: p <= 9)
           p <= bigint_precision_threshold -> LongType    (default: p <= 18)
           p >  bigint_precision_threshold -> LongType    (avoids overflow)
      3. DecimalType(p, s)     — scale>0 numerics always cast to DoubleType.
      4. TimestampType → always kept as TimestampType (no downcast to Date).
      All other types pass through unchanged.

    Parameters
    ----------
    df : DataFrame
        Source DataFrame read from Oracle, RDS, Redshift, or SQL Server
        via Lakehouse Federation / JDBC.
    date_name_patterns : list[str], optional
        Regex patterns (case-insensitive) matched against column names to
        cast TimestampType → DateType.  Defaults to common Oracle DATE
        column naming conventions: _date, _dt, _on, _day, date_, dt_.
    timestamp_name_patterns : list[str], optional
        Regex patterns (case-insensitive) matched against column names to
        explicitly KEEP as TimestampType (takes precedence over date patterns).
        Defaults to: _timestamp, _ts, _at, _time, _dttm, _datetime,
        created_*, updated_*, modified_*.
    column_overrides : dict, optional
        Explicit per-column target type map: {"col_name": "target_type"}.
        Valid target types: "int", "bigint", "double", "float",
        "date", "timestamp", "string", "boolean".
        Overrides take precedence over all auto-detection rules.
    int_precision_threshold : int, default 9
        Maximum Decimal precision to cast as IntegerType (32-bit safe).
    bigint_precision_threshold : int, default 18
        Maximum Decimal precision to cast as LongType (64-bit safe).
    verbose : bool, default True
        Print detection summary table and before/after schema info.

    Returns
    -------
    DataFrame
        DataFrame with detected mismatches resolved, applied in a single
        .withColumns() call to avoid plan nesting (SCPAP004 compliant).
        Schema is inspected once (SCPAP001 compliant).
    """
    date_patterns = [
        re.compile(p, re.IGNORECASE)
        for p in (date_name_patterns or _DEFAULT_DATE_PATTERNS)
    ]
    ts_patterns = [
        re.compile(p, re.IGNORECASE)
        for p in (timestamp_name_patterns or _DEFAULT_TIMESTAMP_PATTERNS)
    ]
    overrides = {k.lower(): v.lower() for k, v in (column_overrides or {}).items()}

    # --- Inspect schema ONCE outside any loop (SCPAP001 compliant) ---
    fields = df.schema.fields
    cast_map: dict = {}
    detection_log: list = []

    for field in fields:
        col_lower = field.name.lower()
        ftype = field.dataType
        resolved = None
        rule = None

        # Rule 1: explicit column override
        if col_lower in overrides:
            resolved = overrides[col_lower]
            rule = "override"

        # Rule 2 & 3: DecimalType auto-detection
        elif isinstance(ftype, _DecimalType):
            if ftype.scale == 0:
                if ftype.precision <= int_precision_threshold:
                    resolved = "int"
                else:
                    resolved = "bigint"
            else:
                resolved = "double"
            rule = "auto:decimal"

        # Rule 4: TimestampType — always keep as TimestampType in target
        elif isinstance(ftype, _TimestampType):
            resolved = "timestamp"
            rule = "auto:keep_timestamp"

        if resolved and resolved in _CAST_TYPE_MAP:
            cast_map[field.name] = col(f"`{field.name}`").cast(_CAST_TYPE_MAP[resolved])
            detection_log.append((field.name, str(ftype), resolved.upper(), rule))

    if verbose:
        print("=== Auto Type Detection — Bronze Layer ===")
        if detection_log:
            header = f"  {'Column':<35} {'Source Type':<28} {'→ Target':<14} Rule"
            print(header)
            print("  " + "-" * (len(header) - 2))
            for col_nm, src_t, tgt_t, rl in detection_log:
                print(f"  {col_nm:<35} {src_t:<28} {tgt_t:<14} [{rl}]")
        else:
            print("  No type mismatches detected — all columns pass through unchanged.")

    # --- Apply all casts in ONE pass (SCPAP004 compliant) ---
    if cast_map:
        df = df.withColumns(cast_map)

    if verbose:
        print(f"\nTotal casts applied : {len(cast_map)}")
        print(f"Columns unchanged   : {len(fields) - len(cast_map)}")
        if cast_map:
            print("\n=== Schema After Auto Alignment ===")
            df.printSchema()

    return df


print("✔ Auto source type alignment loaded — handles Decimal, Date, and Timestamp")

# COMMAND ----------

# DBTITLE 1,select_columns
def apply_column_selection(df: DataFrame, row: dict, ingestion_mode: str) -> DataFrame:
    """Apply column selection if configured (works for all connectors; JDBC also gets pushdown)."""
    source_columns = row.get("source_columns")
    if source_columns and str(source_columns).strip():
        cols = [c.strip().lower() for c in source_columns.split(",")]
        missing = [c for c in cols if c not in df.columns]
        if missing:
            raise ValueError(f"source_columns contains columns not found in source data: {missing}")
        # Guard: for CDC mode, all primary keys must be included in selected columns
        if ingestion_mode == "cdc" and row.get("primary_keys"):
            pk_list = [k.strip().lower() for k in row["primary_keys"].split(",")]
            missing_pks = [pk for pk in pk_list if pk not in cols]
            if missing_pks:
                raise ValueError(
                    f"CDC primary_keys not included in source_columns — add them: {missing_pks}"
                )
        df = df.select(cols)
        print(f"    ✔ Column selection applied: {len(cols)} column(s) → {cols}")
    else:
        print(f"    ℹ No column selection configured — reading all columns")
    return df


print("✔ Column selection logic loaded")

# COMMAND ----------

# DBTITLE 1,silver utilis
# ------------------------------------------------------------------
# Utility: Compute SCD hash
# Reference: sk_generator pattern — auto-detect tracked columns by
# excluding primary keys + SCD framework columns when explicit
# column list is not provided.
# ------------------------------------------------------------------

# SCD2 framework columns (always excluded from hash computation)
_SCD2_META_COLS = [
    "effective_start_date", "effective_end_date", "is_current",
    "scd_hash", "silver_dwh_inserted_at", "silver_dwh_updated_at","create_date", "create_user", "modify_date", "modify_user",
    "load_utc_date_time","active_flag", "created_by", "created_on", "updated_by", "updated_on"
]

# Bronze audit/metadata columns (always excluded — these change on every
# bronze reload and must NOT trigger SCD change detection)
_BRONZE_AUDIT_COLS = [
    "dl_source_system", "dl_batch_id",
    "bronze_dwh_inserted_at", "bronze_dwh_updated_at"
]


def _compute_scd_hash(df, columns=None, primary_keys=None, extra_exclude_cols=None):
    """
    Compute MD5 hash over specified columns for SCD change detection.

    Parameters
    ----------
    df : DataFrame
        Source DataFrame to compute hash on.
    columns : list[str], optional
        Explicit list of columns to include in hash.
        If None, auto-detects by excluding primary_keys + SCD meta columns.
    primary_keys : list[str] or str, optional
        Primary key column(s) to exclude from hash. Accepts comma-separated
        string or list. Required when columns is None.
    extra_exclude_cols : list[str], optional
        Additional columns to exclude from hash (e.g., audit columns from bronze).

    Returns
    -------
    DataFrame with 'scd_hash' column appended.
    """
    if columns is None:
        # --- Auto-detect tracked columns (sk_generator pattern) ---
        pk_list = []
        if primary_keys:
            pk_list = (
                [k.strip().lower() for k in primary_keys.split(",")]
                if isinstance(primary_keys, str)
                else [k.strip().lower() for k in primary_keys]
            )

        exclude_set = set(pk_list + _SCD2_META_COLS + _BRONZE_AUDIT_COLS + (extra_exclude_cols or []))
        columns = sorted([c for c in df.columns if c.lower() not in exclude_set])

    # --- Compute MD5 hash (identical logic to sk_generator) ---
    return df.withColumn(
        "scd_hash",
        F.md5(F.concat_ws("|", *[
            F.coalesce(F.col(c).cast("string"), F.lit("__NULL__"))
            for c in columns
        ]))
    )


# ------------------------------------------------------------------
# Utility: Get columns to exclude (from metadata config)
# ------------------------------------------------------------------
def _get_exclude_columns(source_df, exclude_cols):
    """Return list of columns to drop, filtered to those actually in source."""
    source_columns = source_df.columns
    return [c for c in exclude_cols if c in source_columns]


# ------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------
def _log_silver_processing(processing_id, source_table, target_table, process_mode,
                           status, rows_read=0, rows_written=0,
                           metrics=None, error_msg="", run_start=None, run_end=None):
    """Insert a record into the silver processing log table."""
    try:
        metrics_str = json.dumps(metrics or {}).replace("'", "''")
        error_str = str(error_msg).replace("'", "''")
        spark.sql(f"""
            INSERT INTO {tgt_catalog}.{silver_tgt_schema}.{silver_log_tbl}
            (processing_id, source_table, target_table, process_mode, run_status,
             rows_read, rows_written, operation_metrics, error_message,
             run_start, run_end, created_at)
            VALUES (
                {processing_id}, '{source_table}', '{target_table}',
                '{process_mode}', '{status}', {rows_read}, {rows_written},
                '{metrics_str}', '{error_str}',
                '{run_start}', '{run_end}', current_timestamp()
            )
        """)
    except Exception as e:
        print(f"    ⚠ Log write failed: {e}")