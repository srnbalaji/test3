# Databricks notebook source
# DBTITLE 1,ROCC Post-Transform — WBI Dim, GADS Classification, SCD2
# MAGIC %md
# MAGIC # ROCC Post-Transform Pipeline
# MAGIC
# MAGIC **Called after** `metadata_ingestion_bronze_api` ingests raw Jira data into the raw bronze table.
# MAGIC
# MAGIC ## Pipeline Flow:
# MAGIC 1. **Read** flattened data from `bronze_raw_rocc_jira` (output of framework ingestion)
# MAGIC 2. **WBI Dim Fan-out** — Joins each issue to WBI dimension by site_id/feeder, multiplying rows 1→N
# MAGIC 3. **GADS Classification** — Assigns gads_category_sk, event_type, event_sk based on issue_type + regex patterns
# MAGIC 4. **SCD Type 2** — Compares incoming vs existing `bronze_rocc_jira_issue`, inserts new/expired records
# MAGIC
# MAGIC ## Integration with Framework:
# MAGIC - Run standalone: `dbutils.notebook.run("rocc_post_transform", timeout_seconds=3600)`
# MAGIC - Or schedule as a downstream job task after the `metadata_ingestion_bronze_api` task

# COMMAND ----------

# DBTITLE 1,Section 1 — Config & Imports
# Section 1 ── Config & Imports
import math
import re
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.types import StructType
from delta.tables import DeltaTable

# ── Table references
CATALOG        = "neer_soltn_dev"
SCHEMA         = "geniq_wind_bronze"
RAW_TABLE      = f"{CATALOG}.{SCHEMA}.bronze_raw_rocc_jira"
FACT_TABLE     = f"{CATALOG}.{SCHEMA}.bronze_rocc_jira_issue1"
DIM_TABLE      = f"{CATALOG}.{SCHEMA}.bronze_ods_wbi_rocc"
DEVICE_DIM     = f"{CATALOG}.{SCHEMA}.bronze_ods_device_event" 

CHUNK_SIZE     = 1000

# ── GADS category surrogate keys
GADS = {
    "FEEDER": 66, "PADMOUNT": 51, "ACOUSTIC": 143, "SOFTWARE": 72,
    "OVERHEAD": 68, "ICING": 166, "TRINTERNAL": 119, "OFFTAKER": 120,
    "FIRE": 79, "WEATHER": 166, "ANIMAL": 119, "LIGHTNING": 83,
    "SUBSTATION": 69, "OTHER": 86, "CURTAILMENT": 0, "UNPLAN_EQUIP": 0,
}

# ── GADS regex patterns
GADS_PATTERNS = [
    ("FEEDER",     re.compile(r"(?i).*feeder.*|.*breaker.*|.*circuit.*")),
    ("PADMOUNT",   re.compile(r"(?i).*pad.?mount.*")),
    ("ACOUSTIC",   re.compile(r"(?i).*acoust.*")),
    ("SOFTWARE",   re.compile(r"(?i).*soft.?ware.*")),
    ("OVERHEAD",   re.compile(r"(?i).*over.?head.?line.*")),
    ("ICING",      re.compile(r"(?i).*\bice\b.*|.*\bicing\b.*")),
    ("TRINTERNAL", re.compile(r"(?i).*transmission.?internal.*")),
    ("ANIMAL",     re.compile(r"(?i).*animal.*")),
    ("OFFTAKER",   re.compile(r"(?i).*off.?taker.*")),
    ("FIRE",       re.compile(r"(?i).*fire.*")),
    ("WEATHER",    re.compile(r"(?i).*weather.*")),
    ("LIGHTNING",  re.compile(r"(?i).*lightning.*")),
    ("SUBSTATION", re.compile(r"(?i).*substation.*")),
]
VOLT_PAT    = re.compile(r"(?i).*volt.*")
AMBIENT_PAT = re.compile(r"(?i).*ambient.*")
WIND_PAT    = re.compile(r"(?i).*wind.*")
ICING_PAT   = re.compile(r"(?i).*\bice\b.*|.*\bicing\b.*")

print("✅ Section 1 — Config loaded.")

# COMMAND ----------

# DBTITLE 1,Section 2 — WBI Dim Fan-out
# Section 2 ── WBI Dim Fan-out
# Joins each flat issue record to WBI dimension by site_id + breaker/feeder.
# A single issue may fan-out to multiple rows (one per matching turbine).

def build_dim_index(dim_records):
    plant_idx, feeder_idx = {}, {}
    seen = set()
    for row in dim_records:
        pid = row.get("rocc_site_id")
        fdr = row.get("rocc_feeder_name")
        tsk = row.get("wbi_turbine_sk")
        key = (pid, fdr, tsk)
        if key in seen:
            continue
        seen.add(key)
        plant_idx.setdefault(pid, []).append(row)
        feeder_idx.setdefault(pid, {}).setdefault(fdr, []).append(row)
    return plant_idx, feeder_idx


NA_DIM = {
    "wbi_feeder_name": "NA", "wbi_site_id": 0,
    "wbi_turbine_sk": None, "wbi_turbine_display_name": "NA",
}


def fanout_with_dim(flat_records, dim_list):
    """Fan-out records by matching WBI dimension rows."""
    plant_idx, feeder_idx = build_dim_index(dim_list)
    result = []
    for rec in flat_records:
        site_id = rec.get("site_id_raw") or rec.get("site_id")
        breakers = rec.get("breaker_switch_list") or []
        matched_dims = []
        if breakers and isinstance(breakers, list):
            site_feeders = feeder_idx.get(site_id, {})
            for b in breakers:
                matched_dims.extend(site_feeders.get(b, []))
        if not matched_dims:
            matched_dims = plant_idx.get(site_id, [NA_DIM])
        for dim in matched_dims:
            row = {**rec}
            row["wbi_feedername"] = dim.get("rocc_feeder_name") or dim.get("wbi_feeder_name")
            row["wbi_plantid"] = dim.get("wbi_site_id")
            row["wbi_turbine_sk"] = dim.get("wbi_turbine_sk")
            row["wbi_turbinedisplayname"] = dim.get("wbi_turbine_display_name") or dim.get("turbine_display_name")
            result.append(row)
    return result


print("✅ Section 2 — WBI Dim Fan-out loaded.")

# COMMAND ----------

# DBTITLE 1,Section 3 — GADS Classification
# Section 3 ── GADS Classification

def _match_gads(text):
    if not text:
        return None
    for name, pat in GADS_PATTERNS:
        if pat.search(text):
            return name
    return None


def classify_gads(record, device_dim_lookup):
    issue_type   = (record.get("issue_type") or "").replace("\n", "")
    issue_detail = (record.get("summary") or "").replace("\n", "")
    issue_desc   = (record.get("description") or "").replace("\n", "")
    reason       = (record.get("reason_for_outage") or "").replace("\n", "")

    def _resolve_gads(primary, fallback_a, fallback_b):
        if primary and primary not in ("null", ""):
            return _match_gads(primary)
        return _match_gads(fallback_a) or _match_gads(fallback_b)

    def _apply_outage_type(event_type, event_type_id, gads_name):
        sk = GADS.get(gads_name, GADS["OTHER"]) if gads_name else GADS["OTHER"]
        record["gads_category_sk"] = sk
        record["event_type"] = event_type
        record["event_type_id"] = event_type_id
        tt = record.get("technology_type")
        key = (sk, tt)
        record["event_sk"] = device_dim_lookup.get(key) or device_dim_lookup.get((sk, None))

    if issue_type == "Planned Outage":
        _apply_outage_type("Planned", 2, _resolve_gads(reason, issue_desc, issue_detail))
    elif issue_type == "Unplanned Outage":
        _apply_outage_type("Forced", 1, _resolve_gads(reason, issue_desc, issue_detail))
    elif issue_type in ("Planned Curtailment", "Realtime Curtailment"):
        record["gads_category_sk"] = GADS["CURTAILMENT"]
        record["event_type"] = "Reserve Shutdown"
        record["event_type_id"] = 4
        key = (GADS["CURTAILMENT"], record.get("technology_type"))
        record["event_sk"] = device_dim_lookup.get(key) or device_dim_lookup.get((GADS["CURTAILMENT"], None))
    elif issue_type == "Unplanned Equipment Outage":
        record["gads_category_sk"] = GADS["UNPLAN_EQUIP"]
        record["event_type"] = "Forced"
        record["event_type_id"] = 1
        key = (GADS["UNPLAN_EQUIP"], record.get("technology_type"))
        record["event_sk"] = device_dim_lookup.get(key) or device_dim_lookup.get((GADS["UNPLAN_EQUIP"], None))

    # Flag checks (independent of issue_type)
    combined = f"{issue_type} {issue_desc} {issue_detail} {reason}"
    if VOLT_PAT.search(combined):    record["voltage_flag"] = "Y"
    if AMBIENT_PAT.search(combined): record["ambient_flag"] = "Y"
    if WIND_PAT.search(combined):    record["high_wind_flag"] = "Y"
    if ICING_PAT.search(combined):   record["ice_outage_flag"] = "Y"
    return record


print("✅ Section 3 — GADS Classification loaded.")

# COMMAND ----------

# DBTITLE 1,Section 4 — SCD Type 2 Logic
# Section 4 ── SCD Type 2 Logic

def classify_scd(incoming, existing_rows):
    """Compare incoming records to existing fact table rows.
    Returns (to_insert, to_expire) lists."""
    if not existing_rows:
        return incoming, []
    ex_by_id = {}
    for row in existing_rows:
        ex_by_id.setdefault(row["issue_id"], []).append(row)
    to_insert, to_expire = [], []
    seen_exp_sks = set()
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    for rec in incoming:
        iid = rec["issue_id"]
        created = rec["created"]
        updated = rec["updated_u"]
        per_issue_rows = ex_by_id.get(iid, [])
        matched = [r for r in per_issue_rows if r["created"] == created]
        is_insert = not matched
        active_up_to_date = any(
            r["updated_u"] == updated and r["scd_active_flag"] == "Y"
            for r in matched
        )
        is_update = (not is_insert) and (not active_up_to_date)
        if is_update:
            for r in matched:
                if r["scd_active_flag"] == "Y":
                    sk = r["rocc_issue_sk"]
                    if sk not in seen_exp_sks:
                        seen_exp_sks.add(sk)
                        to_expire.append({
                            "roccissuesk": sk,
                            "roccdumpupdateddatetime": now,
                            "scdeffectiveenddate": now,
                            "scdactiveflag": "N",
                        })
        if is_insert or is_update:
            to_insert.append(rec)
    return to_insert, to_expire


print("✅ Section 4 — SCD Type 2 Logic loaded.")

# COMMAND ----------

# DBTITLE 1,Section 5 — Main Orchestration
# Section 5 ── Main Orchestration
# Reads from the raw bronze table (framework output), applies transforms, writes SCD2.

def run_post_transform():
    """Run the full post-transform pipeline."""
    # 1. Load dimension data
    dim_records = (
        spark.table(DIM_TABLE)
             .filter((F.col("active_flag") == "1") & F.col("rocc_site_id").isNotNull() & F.col("rocc_site_name").isNotNull())
             .collect()
    )
    dim_list = [row.asDict() for row in dim_records]
    print(f"DIM table record count: {len(dim_list)}")

    dev_rows = spark.table(DEVICE_DIM).select("gads_category_id", "turbine_type_id", "event_id").collect()
    device_dim_lookup = {(r["gads_category_id"], r["turbine_type_id"]): r["event_id"] for r in dev_rows}

    # 2. Read raw flattened data from framework output
    raw_df = spark.table(RAW_TABLE)
    raw_records = [row.asDict() for row in raw_df.collect()]
    total_count = len(raw_records)
    num_pages = math.ceil(total_count / CHUNK_SIZE)
    print(f"Raw records: {total_count} → {num_pages} batches of {CHUNK_SIZE}")

    # 3. Get fact table schema
    _old_table = f"{CATALOG}.{SCHEMA}.bronze_fact_rocc_jira_issues"
    is_fresh_load = not spark.catalog.tableExists(FACT_TABLE)
    _schema_src = FACT_TABLE if not is_fresh_load else (_old_table if spark.catalog.tableExists(_old_table) else None)
    fact_schema = StructType([f for f in spark.table(_schema_src).schema.fields if f.name != "rocc_issue_sk"]) if _schema_src else None
    _long_cols = {f.name for f in fact_schema.fields if str(f.dataType) == "LongType()"} if fact_schema else set()

    if is_fresh_load and _schema_src:
        spark.sql(f"CREATE TABLE IF NOT EXISTS {FACT_TABLE} LIKE {_schema_src}")
        is_fresh_load = False
        print(f"✅ Pre-created {FACT_TABLE} schema from {_schema_src}")

    total_new, total_expired = 0, 0

    # 4. Process in batches
    for page in range(num_pages):
        batch = raw_records[page * CHUNK_SIZE:(page + 1) * CHUNK_SIZE]
        if not batch:
            continue

        # WBI Dim Fan-out
        fanned = fanout_with_dim(batch, dim_list)

        # GADS Classification
        classified = [classify_gads(r, device_dim_lookup) for r in fanned]

        # SCD2 comparison
        issue_ids = list({r["issue_id"] for r in classified})
        existing_raw = [] if is_fresh_load else (
            spark.table(FACT_TABLE)
                 .filter(F.col("issue_id").isin(issue_ids))
                 .select("rocc_issue_sk", "issue_id", "created", "updated_u", "scd_active_flag")
                 .collect()
        )
        to_insert, to_expire = classify_scd(classified, existing_raw)

        # Expire old records
        if to_expire:
            expire_df = spark.createDataFrame(to_expire)
            DeltaTable.forName(spark, FACT_TABLE).alias("tgt").merge(
                expire_df.alias("src"), "tgt.rocc_issue_sk = src.roccissuesk"
            ).whenMatchedUpdate(set={
                "scd_active_flag": "src.scdactiveflag",
                "scd_effective_end_date": "src.scdeffectiveenddate",
                "rocc_dump_updated_datetime": "src.roccdumpupdateddatetime",
            }).execute()

        # Insert new records
        if to_insert:
            def _clean_row(r):
                row = {k: v for k, v in r.items() if not k.startswith("_")}
                for col in _long_cols:
                    if isinstance(row.get(col), str):
                        try: row[col] = int(row[col])
                        except (ValueError, TypeError): row[col] = None
                return row
            clean = [_clean_row(r) for r in to_insert]
            insert_df = spark.createDataFrame(clean, schema=fact_schema) if fact_schema else spark.createDataFrame(clean)
            insert_df.write.format("delta").mode("append").saveAsTable(FACT_TABLE)
            if fact_schema is None:
                fact_schema = StructType([f for f in spark.table(FACT_TABLE).schema.fields if f.name != "rocc_issue_sk"])
                _long_cols = {f.name for f in fact_schema if str(f.dataType) == "LongType()"}

        total_new += len(to_insert)
        total_expired += len(to_expire)
        print(f"Batch {page+1}/{num_pages} — new: {len(to_insert)}  expired: {len(to_expire)}")

    print(f"\n✅ Post-transform complete: inserted={total_new}, expired={total_expired}")
    return {"inserted": total_new, "expired": total_expired}


# Execute post-transform pipeline
import json as _json
result = run_post_transform()
print(f"\n✅ Final Result: {result}")
dbutils.notebook.exit(_json.dumps(result))