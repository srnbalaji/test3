# Databricks notebook source
# MAGIC %run ./common_functions

# COMMAND ----------

# MAGIC %run ./../config/source_to_target_mapping

# COMMAND ----------

src_catalog = catalogs['source_catalog']
tgt_catalog = catalogs['target_catalog']
tgt_schema = schemas['wind_target']["foundation"]

metadata_config_tbl = ref_tables['metadata_config']
metadata_log_tbl = ref_tables['metadata_log']

print(src_catalog)
print(tgt_catalog)
print(tgt_schema)


# COMMAND ----------

# ---------- ingestion metadata (config) table ----------
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {tgt_catalog}.{tgt_schema}.{metadata_config_tbl} (
  source_id           STRING    COMMENT 'Unique source identifier',
  source_name         STRING    COMMENT 'Human-readable source name',
  source_type         STRING    COMMENT 'jdbc_oracle | jdbc_rds | jdbc_redshift | rest_api | sftp',
  connection_config   STRING    COMMENT 'JSON with connection details (host, port, db, secret_scope/key, url, path, etc.)',
  source_schema       STRING    COMMENT 'Source schema / database',
  source_table        STRING    COMMENT 'Source table or endpoint / file pattern',
  target_catalog      STRING    COMMENT 'Target Unity Catalog name',
  target_schema       STRING    COMMENT 'Target schema name',
  target_table        STRING    COMMENT 'Target table name (will be lowercased)',
  ingestion_mode      STRING    COMMENT 'full | incremental | cdc',
  incremental_column  STRING    COMMENT 'Watermark column for incremental loads',
  primary_keys        STRING    COMMENT 'Comma-separated PK columns for CDC merge',
  watermark_value     STRING    COMMENT 'Last successfully processed watermark value',
  cdc_delete_column   STRING    COMMENT 'Column indicating soft-delete in CDC source (optional)',
  cdc_delete_value    STRING    COMMENT 'Value in delete column that means deleted (optional)',
  is_active           BOOLEAN   DEFAULT true   COMMENT 'Enable/disable this source',
  created_at          TIMESTAMP DEFAULT current_timestamp(),
  updated_at          TIMESTAMP
)
USING DELTA
TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported')
COMMENT 'Metadata configuration driving the ingestion framework'
""")

# COMMAND ----------

# ---------- audit log table ----------
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {tgt_catalog}.{tgt_schema}.{metadata_log_tbl} (
  audit_id            STRING     COMMENT 'Unique audit record ID (UUID)',
  source_id           STRING     COMMENT 'FK to ingestion_metadata.source_id',
  source_name         STRING     COMMENT 'Source name for readability',
  batch_id            STRING     COMMENT 'Batch run identifier (UUID)',
  ingestion_mode      STRING     COMMENT 'append | full | incremental | cdc',
  source_type         STRING     COMMENT 'Source connector type',
  target_table        STRING     COMMENT 'Fully qualified target table',
  start_time          TIMESTAMP  COMMENT 'Ingestion start timestamp',
  end_time            TIMESTAMP  COMMENT 'Ingestion end timestamp',
  status              STRING     COMMENT 'running | success | failed',
  rows_read           BIGINT     COMMENT 'Rows read from source',
  rows_written        BIGINT     COMMENT 'Rows written / merged to target',
  watermark_before    STRING     COMMENT 'Watermark value before this run',
  watermark_after     STRING     COMMENT 'Watermark value after this run',
  error_message       STRING     COMMENT 'Error details if status = failed',
  created_at          TIMESTAMP  DEFAULT current_timestamp()
)
USING DELTA
TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported')
COMMENT 'Audit log tracking every ingestion run'
""")



# COMMAND ----------

print(f"✔ Metadata table ready : wind_metadata_ingestion")
print(f"✔ Audit log table ready: wind_metadata_ingestion_log")