# Databricks notebook source
# MAGIC %run ./common_functions

# COMMAND ----------

# DBTITLE 1,Cell 2
# ================================================================
# Source Connectors (Volume + UC JDBC — no JAR dependency)
# ================================================================

from pyspark.sql import DataFrame
def _parse_config(connection_config: str) -> dict:

    """Parse the JSON connection_config string."""
    return json.loads(connection_config)


# ------------------------------------------------------------------
# Unity Catalog Volume Connector  (CSV / Parquet / JSON / XML)
# ------------------------------------------------------------------
def read_volume(cfg: dict) -> DataFrame:
    """
    Read files from a Unity Catalog Volume.
    Directly reads from the Volume path — no staging or downloads needed.
    """
    volume_path  = cfg["volume_path"].rstrip("/")
    file_format  = cfg.get("file_format", "csv").lower()
    file_pattern = cfg.get("file_pattern", "")
    read_opts    = cfg.get("read_options", {})

    # Build the full read path
    read_path = f"{volume_path}/{file_pattern}" if file_pattern else volume_path

    # Apply sensible defaults per format
    default_opts = {
        "csv":  {"header": "true", "inferSchema": "true"},
        "json": {"multiLine": "true"},
    }
    merged_opts = {**default_opts.get(file_format, {}), **read_opts}

    reader = spark.read.format(file_format)
    for k, v in merged_opts.items():
        reader = reader.option(k, str(v))

    df = reader.load(read_path)
    print(f"  \u2714 Volume read complete: {read_path}  ({file_format})")
    return df


# ------------------------------------------------------------------
# JDBC via Unity Catalog Connection (no JAR required)
# ------------------------------------------------------------------
def read_jdbc_uc_connection(connection_name: str, dbtable: str, connection_config: str, fetchsize: int = 10000) -> DataFrame:
    """
    Read from a JDBC source using a Unity Catalog connection reference.
    No driver JAR needed — UC manages the connection.
    """
    cfg = json.loads(connection_config)
    user = cfg.get("user")
    password = cfg.get("password")
    reader = (
        spark.read.format("jdbc")
        .option("databricks.connection", connection_name)
        .option("dbtable", dbtable)
        .option("fetchsize", str(fetchsize))
    )
    if user and password:
        reader = reader.option("user", user).option("password", password)
    return reader.load()


# ------------------------------------------------------------------
# Unified source reader (JDBC sources SKIPPED — no JAR)
# ------------------------------------------------------------------
def read_source(row: dict) -> DataFrame:
    """Route to the correct connector based on source_type."""
    cfg = _parse_config(row["connection_config"])
    src_type = row["source_type"].strip().lower()

    if src_type == "volume":
        return read_volume(cfg)
    elif src_type.startswith("oracle_connection"):
        # Check if a UC connection name is provided — use JAR-free UC connector
        uc_connection = cfg.get("uc_connection_name")
        if uc_connection:
            source_sql         = row.get("source_sql")
            source_schema      = row.get("source_schema")
            source_table_name  = row.get("source_table")
            ingestion_mode     = row.get("ingestion_mode", "full_load")
            watermark_value    = row.get("watermark_value")
            incremental_column = row.get("incremental_column")
            columns            = row.get("source_columns")

            # Priority: source_sql > source_schema.source_table
            if source_sql and source_sql.strip():
                query = f"({source_sql}) src_qry"
            else:
                dbtable  = f"{source_schema}.{source_table_name}" if source_schema else source_table_name
                col_list = columns.strip() if columns and columns.strip() else "*"
                if ingestion_mode == "incremental" and watermark_value:
                    query = f"(SELECT {col_list} FROM {dbtable} WHERE {incremental_column} > '{watermark_value}') src_qry"
                else:
                    query = f"(SELECT {col_list} FROM {dbtable}) src_qry" if col_list != "*" else dbtable

            fetchsize     = cfg.get("fetchsize", "10000")
            custom_schema = cfg.get("customSchema")
            reader = (spark.read
                .format("jdbc")
                .option("databricks.connection", uc_connection)
                .option("dbtable", query)
                .option("fetchsize", fetchsize))
            if custom_schema:
                reader = reader.option("customSchema", custom_schema)
            return reader.load()

    elif src_type.startswith("jdbc"):
        # Check if a UC connection name is provided — use JAR-free UC connector
        uc_connection = cfg.get("uc_connection_name")
        if uc_connection:
            source_sql         = row.get("source_sql")
            source_schema      = row.get("source_schema")
            source_table_name  = row.get("source_table")
            ingestion_mode     = row.get("ingestion_mode", "full_load")
            watermark_value    = row.get("watermark_value")
            incremental_column = row.get("incremental_column")
            columns            = row.get("source_columns")

            # Priority: source_sql > source_schema.source_table
            if source_sql and source_sql.strip():
                query = f"({source_sql}) src_qry"
            else:
                dbtable  = f"{source_schema}.{source_table_name}" if source_schema else source_table_name
                col_list = columns.strip() if columns and columns.strip() else "*"
                if ingestion_mode == "incremental" and watermark_value:
                    query = f"(SELECT {col_list} FROM {dbtable} WHERE {incremental_column} > '{watermark_value}') src_qry"
                else:
                    query = f"(SELECT {col_list} FROM {dbtable}) src_qry" if col_list != "*" else dbtable

            return read_jdbc_uc_connection(uc_connection, query, row["connection_config"])
        else:
            raise ValueError(
                f"JDBC source '{row['source_name']}' skipped — traditional JDBC drivers "
                f"are not supported in Unity Catalog USER_ISOLATION mode. "
                f"Use a UC connection (add 'uc_connection_name' to connection_config) or set is_active=false."
            )
    elif src_type == "rest_api":
        custom_param = row.get("custom_parameter")
        if custom_param and custom_param.strip() and custom_param.strip().lower() != "null":
            # Fetch raw records and apply custom_parameter flatten mapping
            raw_records = _fetch_rest_api_records(cfg)
            mapping = json.loads(custom_param)
            flattened = apply_custom_parameter(raw_records, mapping)
            if not flattened:
                return spark.createDataFrame([], StructType([]))
            # Use pandas to handle all-None columns (Spark can't infer type from NoneType)
            import pandas as pd
            pdf = pd.DataFrame(flattened)
            # Cast all-None columns to nullable string instead of dropping — preserves schema structure
            all_none_cols = [c for c in pdf.columns if pdf[c].isna().all()]
            if all_none_cols:
                print(f"    ⚠ Retaining {len(all_none_cols)} all-None columns as nullable string: {all_none_cols[:5]}{'...' if len(all_none_cols) > 5 else ''}")
                for c in all_none_cols:
                    pdf[c] = pdf[c].astype(pd.StringDtype())
            return spark.createDataFrame(pdf)
        return read_rest_api(cfg)
    elif src_type == "sftp":
        raise ValueError(f"SFTP connector not loaded in test mode — source '{row['source_name']}' skipped.")
    else:
        raise ValueError(f"Unsupported source_type: {src_type}")


# ------------------------------------------------------------------
# REST API Connector (aligned with source_connector pattern)
# ------------------------------------------------------------------
def read_rest_api(cfg: dict) -> DataFrame:
    """
    Read data from a paginated REST API and return a Spark DataFrame.
    
    connection_config JSON keys:
      - url             : Full API endpoint URL (e.g. "https://10.110.34.206/rest/api/2/search")
      - method          : HTTP method (default "GET")
      - headers         : Optional dict of extra headers
      - params          : Static query params dict (e.g. {"jql": "project=LOGID"})
      - verify_ssl      : true/false (default true) — set false for self-signed certs
      - auth_type       : "basic" | "bearer" | "none"
        For basic auth:
          - secret_scope / secret_key_user / secret_key_password  (dbutils.secrets)
          - OR user / password  (literal values — fallback if no secret_scope)
        For bearer auth:
          - secret_scope / secret_key_token
      - response_json_path : dot-notation path to records array (e.g. "issues")
      - pagination:
          type           : "offset" | "cursor" | "none"
          page_size      : Records per page (default 1000)
          limit_param    : Query param name for page size (e.g. "maxResults")
          offset_param   : Query param name for offset (e.g. "startAt")
          cursor_param   : Query param for cursor token (cursor-based)
          cursor_field   : JSON path to next cursor in response
    """
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    url        = cfg["url"]
    method     = cfg.get("method", "GET").upper()
    headers    = cfg.get("headers", {})
    params     = dict(cfg.get("params", {}))
    verify_ssl = cfg.get("verify_ssl", True)

    # ---------- authentication ----------
    auth_type = cfg.get("auth_type", "none").lower()
    auth = None
    if auth_type == "bearer":
        token = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_token"])
        headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic":
        if cfg.get("secret_scope"):
            u = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_user"])
            p = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_password"])
        else:
            # Literal user/password (fallback for dev/test)
            u = cfg["user"]
            p = cfg["password"]
        auth = (u, p)

    # ---------- pagination ----------
    pagination = cfg.get("pagination")
    json_path  = cfg.get("response_json_path", "")
    all_records = []

    def _extract(body, path):
        """Walk the dot-separated path into the JSON body."""
        obj = body
        for p in path.split(".") if path else []:
            obj = obj[p]
        return obj if isinstance(obj, list) else [obj]

    if pagination and pagination.get("type") == "offset":
        offset = 0
        page_size = int(pagination.get("page_size", 1000))
        limit_param  = pagination["limit_param"]
        offset_param = pagination["offset_param"]
        while True:
            params[limit_param]  = page_size
            params[offset_param] = offset
            resp = requests.request(method, url, headers=headers, params=params,
                                    auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
            resp.raise_for_status()
            records = _extract(resp.json(), json_path)
            if not records:
                break
            all_records.extend(records)
            if len(records) < page_size:
                break
            offset += page_size
            if (offset // page_size) % 10 == 0:
                print(f"    ... fetched {offset} records so far")

    elif pagination and pagination.get("type") == "cursor":
        cursor = None
        page_size = int(pagination.get("page_size", 1000))
        limit_param = pagination.get("limit_param", "maxResults")
        while True:
            params[limit_param] = page_size
            if cursor:
                params[pagination.get("cursor_param", "cursor")] = cursor
            resp = requests.request(method, url, headers=headers, params=params,
                                    auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
            resp.raise_for_status()
            body = resp.json()
            records = _extract(body, json_path)
            if not records:
                break
            all_records.extend(records)
            cursor = body.get(pagination.get("cursor_field", "next_cursor"))
            if not cursor:
                break
    else:
        # No pagination — single request
        resp = requests.request(method, url, headers=headers, params=params,
                                auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
        resp.raise_for_status()
        all_records = _extract(resp.json(), json_path)

    print(f"    REST API: Total records fetched: {len(all_records)}")

    if not all_records:
        return spark.createDataFrame([], StructType([]))

    df = spark.createDataFrame(all_records)
    print(f"  \u2714 REST API read complete: {url}  ({len(all_records)} records)")
    return df


# ------------------------------------------------------------------
# Custom Parameter Flatten Logic (for REST API responses)
# ------------------------------------------------------------------
def _navigate_path(record: dict, path: str):
    """Navigate a dot-notation path into a nested dict. Returns None if any key is missing."""
    obj = record
    for key in path.split("."):
        if obj is None:
            return None
        if isinstance(obj, list):
            try:
                obj = obj[int(key)]
            except (IndexError, ValueError):
                return None
        elif isinstance(obj, dict):
            obj = obj.get(key)
        else:
            return None
    return obj


def _parse_timestamp(val):
    """Parse an ISO timestamp string to Python datetime."""
    if val is None:
        return None
    from datetime import datetime
    try:
        # Handle Jira-style: "2024-01-15T10:30:00.000+0000" or "2024-01-15T10:30:00.000-0500"
        s = str(val).replace("Z", "+0000")
        # Try multiple formats
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z",
                    "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(s, fmt).replace(tzinfo=None)
            except ValueError:
                continue
        return None
    except Exception:
        return None


def _parse_utc(val):
    """Parse a timestamp string and convert to UTC."""
    if val is None:
        return None
    from datetime import datetime, timezone
    try:
        s = str(val).replace("Z", "+0000")
        for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
            try:
                dt = datetime.strptime(s, fmt)
                return dt.astimezone(timezone.utc).replace(tzinfo=None)
            except ValueError:
                continue
        return _parse_timestamp(val)
    except Exception:
        return None


def apply_custom_parameter(records: list, mapping: dict) -> list:
    """
    Flatten raw API records using the custom_parameter JSON mapping.
    
    Each key in mapping is the target column name.
    Each value is a dict with:
      - path: dot-notation path to extract from the raw record
      - type: string | int | timestamp | utc | value | truncate | join_list
      - max_length: (optional) for truncate type
    """
    flattened = []
    for record in records:
        flat = {}
        for target_col, spec in mapping.items():
            path = spec["path"]
            col_type = spec.get("type", "string")
            raw_val = _navigate_path(record, path)

            if col_type == "string":
                flat[target_col] = str(raw_val) if raw_val is not None else None

            elif col_type == "int":
                try:
                    flat[target_col] = int(raw_val) if raw_val is not None else None
                except (ValueError, TypeError):
                    flat[target_col] = None

            elif col_type == "timestamp":
                flat[target_col] = _parse_timestamp(raw_val)

            elif col_type == "utc":
                flat[target_col] = _parse_utc(raw_val)

            elif col_type == "value":
                # Extract .value from enum/select field objects
                if isinstance(raw_val, dict):
                    flat[target_col] = raw_val.get("value")
                elif isinstance(raw_val, str):
                    flat[target_col] = raw_val
                else:
                    flat[target_col] = None

            elif col_type == "truncate":
                max_len = spec.get("max_length", 4000)
                if raw_val is not None:
                    flat[target_col] = str(raw_val)[:max_len]
                else:
                    flat[target_col] = None

            elif col_type == "join_list":
                if isinstance(raw_val, list):
                    flat[target_col] = ", ".join(str(item) for item in raw_val if item)
                else:
                    flat[target_col] = str(raw_val) if raw_val is not None else None

            elif col_type == "default":
                # Always set to the configured default_value (typically None)
                flat[target_col] = spec.get("default_value")

            elif col_type == "current_timestamp":
                # Set to current UTC datetime (naive)
                from datetime import datetime, timezone
                flat[target_col] = datetime.now(timezone.utc).replace(tzinfo=None)

            elif col_type == "literal":
                # Use the literal default_value as-is
                lit_val = spec.get("default_value")
                # Handle datetime literal strings
                if lit_val and "T" in str(lit_val) and len(str(lit_val)) >= 19:
                    try:
                        from datetime import datetime
                        flat[target_col] = datetime.fromisoformat(str(lit_val))
                    except ValueError:
                        flat[target_col] = lit_val
                else:
                    flat[target_col] = lit_val

            elif col_type == "raw_list":
                # Keep the raw list/value as-is (no string conversion)
                flat[target_col] = raw_val if raw_val is not None else []

            else:
                flat[target_col] = str(raw_val) if raw_val is not None else None

        flattened.append(flat)

    print(f"  \u2714 Custom parameter flatten applied: {len(flattened)} records, {len(mapping)} columns")
    return flattened


def _fetch_rest_api_records(cfg: dict) -> list:
    """Fetch raw records from REST API (same logic as read_rest_api but returns list of dicts)."""
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    url        = cfg["url"]
    method     = cfg.get("method", "GET").upper()
    headers    = cfg.get("headers", {})
    params     = dict(cfg.get("params", {}))
    verify_ssl = cfg.get("verify_ssl", True)

    auth_type = cfg.get("auth_type", "none").lower()
    auth = None
    if auth_type == "bearer":
        token = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_token"])
        headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic":
        if cfg.get("secret_scope"):
            u = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_user"])
            p = dbutils.secrets.get(cfg["secret_scope"], cfg["secret_key_password"])
        else:
            u = cfg["user"]
            p = cfg["password"]
        auth = (u, p)

    pagination = cfg.get("pagination")
    json_path  = cfg.get("response_json_path", "")
    all_records = []

    def _extract(body, path):
        obj = body
        for p in path.split(".") if path else []:
            obj = obj[p]
        return obj if isinstance(obj, list) else [obj]

    if pagination and pagination.get("type") == "offset":
        offset = 0
        page_size = int(pagination.get("page_size", 1000))
        limit_param  = pagination["limit_param"]
        offset_param = pagination["offset_param"]
        while True:
            params[limit_param]  = page_size
            params[offset_param] = offset
            resp = requests.request(method, url, headers=headers, params=params,
                                    auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
            resp.raise_for_status()
            records = _extract(resp.json(), json_path)
            if not records:
                break
            all_records.extend(records)
            if len(records) < page_size:
                break
            offset += page_size
            if (offset // page_size) % 10 == 0:
                print(f"    ... fetched {offset} records so far")
    elif pagination and pagination.get("type") == "cursor":
        cursor = None
        page_size = int(pagination.get("page_size", 1000))
        limit_param = pagination.get("limit_param", "maxResults")
        while True:
            params[limit_param] = page_size
            if cursor:
                params[pagination.get("cursor_param", "cursor")] = cursor
            resp = requests.request(method, url, headers=headers, params=params,
                                    auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
            resp.raise_for_status()
            body = resp.json()
            records = _extract(body, json_path)
            if not records:
                break
            all_records.extend(records)
            cursor = body.get(pagination.get("cursor_field", "next_cursor"))
            if not cursor:
                break
    else:
        resp = requests.request(method, url, headers=headers, params=params,
                                auth=auth, verify=verify_ssl, timeout=cfg.get("read_timeout", 300))
        resp.raise_for_status()
        all_records = _extract(resp.json(), json_path)

    print(f"    REST API: Total records fetched: {len(all_records)}")
    return all_records


print("\u2714 Source connectors loaded (Volume + UC JDBC + REST API)") 
