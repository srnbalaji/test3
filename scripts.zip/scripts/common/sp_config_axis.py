def fix_src_path(src_path, environment):  
  if environment.lower() == "dev":
    return src_path.replace("2env", "2env")  
  elif environment.lower() == "qa":
    return src_path.replace("2env", "2eqv")
  elif environment.lower() == "prod":
    return src_path.replace("2env", "2epv")

def fix_redshift_db_table(REDSHIFT_DB_TABLE, environment):  
  if environment.lower() == "qa":
    return REDSHIFT_DB_TABLE.replace("edpdev", "edp")
  elif environment.lower() == "prod":
    return REDSHIFT_DB_TABLE.replace("edpdev", "edp")
  elif environment.lower() == "dev":
    return REDSHIFT_DB_TABLE.replace("edpdev", "edpdev")


redshift_connection = {
    "DEV":  {			  
      "REDSHIFT_CONNECTION_NAME":"2env-en411-edp-axis-redshift-conn",
      "REDSHIFT_TEMP_DIR":"s3://aws-glue-assets-288355943657-us-east-1/temporary/",
      "REDSHIFT_TRANSFORMATION_CTX":"AmazonRedshift_node1706296225363",
      "REDSHIFT_JDBC_DRIVER_PATH":"s3://2env-edp-data4ai-en411-s3/redshiftjarpath/redshift-jdbc42-2.1.0.26.jar"
    },
    "QA":   {
      "REDSHIFT_CONNECTION_NAME":"2eqv-en411-edp-axis-redshift-conn",
      "REDSHIFT_TEMP_DIR":"s3://aws-glue-assets-129801215131-us-east-1/temporary/",
      "REDSHIFT_TRANSFORMATION_CTX":"",
      "REDSHIFT_JDBC_DRIVER_PATH":"s3://2eqv-edp-data4ai-en411-s3/redshiftjarpath/redshift-jdbc42-2.1.0.26.jar"
    },
    "PROD": {
      "REDSHIFT_CONNECTION_NAME":"2epv-en411-edp-axis-redshift-conn",
      "REDSHIFT_TEMP_DIR":"s3://aws-glue-assets-434940588922-us-east-1/temporary/",
      "REDSHIFT_TRANSFORMATION_CTX":"",
      "REDSHIFT_JDBC_DRIVER_PATH":"s3://2epv-edp-data4ai-en411-s3/redshiftjarpath/redshift-jdbc42-2.1.0.26.jar"
    }
}


s3_staging_path = {
    "DEV": "s3://2env-edp-platform-en411-s3/tmp/axis",
    "QA": "s3://2eqv-edp-platform-en411-s3/tmp/axis",
    "PROD": "s3://2epv-edp-platform-en411-s3/tmp/axis"
}

api_sub_job_name = {
  "DEV": "2env-en411-edp-axis-gexa-account-api-sfdata",
  "QA": "2eqv-en411-edp-axis-gexa-account-api-sfdata",
  "PROD": "2epv-en411-edp-axis-gexa-account-api-sfdata"
}
secrets = {
    "DEV": {
      "rs_secret": "2env-en411-edp-axis-redshift-zzz0talendaxis-secret",
      "sf_secret": "2env-en411-edp-axis-salesforce-gexa-secret"
    },
    "QA": { 
      "rs_secret": "2eqv-en411-edp-axis-redshift-zzz0talendaxis-secret",
      "sf_secret": "2eqv-en411-edp-axis-salesforce-gexa-secret"
    },
    "PROD": { 
      "rs_secret": "2epv-en411-edp-axis-redshift-zzz0talendaxis-secret",
      "sf_secret": "2epv-en411-edp-axis-salesforce-gexa-secret"
    }
}


iam_role = {
    "DEV" : {              
        "copy_cmd_role" : "arn:aws:iam::288355943657:role/2env-en411-allbu-redshift-assumerole"
    },
    "QA" : {
        "copy_cmd_role" : "arn:aws:iam::129801215131:role/2eqv-en411-allbu-redshift-assumerole"
    },
    "PROD" : {
        "copy_cmd_role" : "arn:aws:iam::434940588922:role/2epv-en411-allbu-redshift-assumerole"
    }
}

sns_arn = {
    "DEV" : "arn:aws:sns:us-east-1:288355943657:2env-en411-edp-axis-support-alert-sns-topic",
    "QA" : "arn:aws:sns:us-east-1:129801215131:2eqv-en411-edp-axis-support-alert-sns-topic",
    "PROD" : "arn:aws:sns:us-east-1:434940588922:2epv-en411-edp-axis-support-alert-sns-topic"
}

TEMP_DIR = {
    "DEV" : "s3://aws-glue-assets-288355943657-us-east-1/temporary/",
    "QA" : "s3://aws-glue-assets-129801215131-us-east-1/temporary/",
    "PROD" : "s3://aws-glue-assets-434940588922-us-east-1/temporary/",
}

bucket = {
    "DEV"  : "2env-edp-platform-en411-s3",
    "QA"   : "2eqv-edp-platform-en411-s3",
    "PROD" : "2epv-edp-platform-en411-s3",
}

LOG_FILES_Bloomberg = {
    "DEV"  : "/aws-axis/axis/output/2env-en411-edp-axis-bloomberg",
    "QA"   : "/aws-axis/axis/output/2eqv-en411-edp-axis-bloomberg",
    "PROD" : "/aws-axis/axis/output/2epv-en411-edp-axis-bloomberg",
}
LOG_FILES_Neercrm = {
    "DEV"  : "/aws-axis/axis/output/2env-en411-edp-axis-neercrm",
    "QA"   : "/aws-axis/axis/output/2eqv-en411-edp-axis-neercrm",
    "PROD" : "/aws-axis/axis/output/2epv-en411-edp-axis-neercrm",
}
LOG_FILES_Fples = {
    "DEV"  : "/aws-axis/axis/output/2env-en411-edp-axis-fples",
    "QA"   : "/aws-axis/axis/output/2eqv-en411-edp-axis-fples",
    "PROD" : "/aws-axis/axis/output/2epv-en411-edp-axis-fples",
}
LOG_FILES_Gexa = {
    "DEV"  : "/aws-axis/axis/output/2env-en411-edp-axis-gexa",
    "QA"   : "/aws-axis/axis/output/2eqv-en411-edp-axis-gexa",
    "PROD" : "/aws-axis/axis/output/2epv-en411-edp-axis-gexa",
}
LOG_FILES_Everbright = {
    "DEV"  : "/aws-axis/axis/output/2env-en411-edp-axis-everbright",
    "QA"   : "/aws-axis/axis/output/2eqv-en411-edp-axis-everbright",
    "PROD" : "/aws-axis/axis/output/2epv-en411-edp-axis-everbright",
}

failure_email_body = """
    Project Name  :  EDP_AXIS,
    Job Name  :  {job_name},
    Job RunDate  :  {run_date},
    Job Environment Name   :  {environment},
    Job Status  :  Failure ,
    Job Failure Reason  :  {error},
    Service  :  AWS-Glue  
"""

success_email_body = """
    Project Name  :  EDP_AXIS,
    Job Name  :  {job_name},
    Job RunDate  :  {run_date},
    Job Environment Name  :  {environment},
    Job Status  :  Success,
    Service  :  AWS-Glue
"""

EXTRA_PARAMS_GLUE = {
    "raw-base-companies" : {
        "REDSHIFT_DB_TABLE":"edpdev",
        "user_id":"zzz0talendaxis", 
        "batch_status":"Started", 
        "load_type":"FULL", 
        "project_name":"EDP_AXIS", 
        "source_system":"EXT-Bloomberg-Raw-Base", 
        "stage_name":"Raw-to-Base", 
        "target_table_name":"companies_raw", 
        "landing_zone":"tmp/axis/output/ext-bloomberg-raw-base-companies/staging/", 
        "created_by":"glue_ETL", 
        "modified_by":"glue_ETL", 
        "target_db_schema":"common_raw", 
        "target_db_table":"companies_raw", 
        "database_name":"edp", 
        "schema_name":"common_raw", 
        "staging_table_schema":"common_raw",
        "staging_table_name":"companies_raw",
        "owner":"Bloomberg",
        "src_path":"s3://2env-edp-raw-trading-en411-s3/landing/external/bloomberg/",
        "audit_schema":"vendor_customer_opportunities_raw",
        "audit_table":"edp_axis_batch_control_log"
        }
}

gexa_account = {
    "created_by" : 'Glue_ETL',
    "modified_by" : 'Glue_ETL',
    "s3_key" :"s3://",
    "batch_status" : "Batch Started",
    "audit_schema" : "vendor_customer_opportunities_raw",
    "audit_table":  "edp_axis_batch_control_log",
    "region_name": "us-east-1",
    "load_type": "DELTA",
    "s3_object_key":"tmp/axis",
    "batch_status": "Batch Started",
    "project_name": "EDP_AXIS",
    "source_system": "Specific_SS_Salesforce_GEXA_Account",
    "stage_name": "Source-to-Base",
    "environment": "ENVCODE",
    "staging_table_name": "vendor_customer_opportunities_staging.stg_sfdc_gexa_account_raw",
    "target_table_name": "vendor_customer_opportunities_raw.sfdc_gexa_account_raw",
    "landing_zone": "tmp/axis/gexa/output/edp_axis_sfdc_gexa_source_raw_account/staging/json",
    "soql_query": "select+Id, IsDeleted, MasterRecordId, Name, Type, RecordTypeId, ParentId, BillingStreet, BillingCity, BillingState, BillingPostalCode, BillingCountry, BillingLatitude, BillingLongitude, BillingGeocodeAccuracy, BillingAddress, ShippingStreet, ShippingCity, ShippingState, ShippingPostalCode, ShippingCountry, ShippingLatitude, ShippingLongitude, ShippingGeocodeAccuracy, ShippingAddress, Phone, Fax, AccountNumber, Website, PhotoUrl, Sic, Industry, AnnualRevenue, NumberOfEmployees, Ownership, TickerSymbol, Description, Rating, Site, OwnerId, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById, SystemModstamp, LastActivityDate, LastViewedDate, LastReferencedDate, Jigsaw, JigsawCompanyId, AccountSource, SicDesc, vlocity_cmt__AccountPaymentType__c, vlocity_cmt__Active__c, vlocity_cmt__AutoPaymentAmount__c, vlocity_cmt__AutoPaymentCardType__c, vlocity_cmt__AutoPaymentLimitAmount__c, vlocity_cmt__AutoPaymentMethodId__c, vlocity_cmt__BillCycle__c, vlocity_cmt__BillDeliveryMethod__c, vlocity_cmt__BillFormat__c, vlocity_cmt__BillFrequency__c, vlocity_cmt__BillNumberOfCopies__c, vlocity_cmt__BillingEmailAddress__c, vlocity_cmt__CLTV__c, vlocity_cmt__CalculatedAddress__c, vlocity_cmt__Churn__c, vlocity_cmt__ContactPreferences__c, vlocity_cmt__CreditRating__c, vlocity_cmt__CreditScore__c, vlocity_cmt__CustomerClass__c, vlocity_cmt__CustomerOfBrand__c, vlocity_cmt__CustomerValue__c, vlocity_cmt__DateFounded__c, vlocity_cmt__DirectoryListed__c, vlocity_cmt__Disclosure1__c, vlocity_cmt__Disclosure2__c, vlocity_cmt__Disclosure3__c, vlocity_cmt__EnableAutopay__c, vlocity_cmt__IsPersonAccount__c, vlocity_cmt__IsRootResolved__c, vlocity_cmt__Juridsiction1__c, vlocity_cmt__Jurisdiction2__c, vlocity_cmt__LegalForm__c, vlocity_cmt__NetWorth__c, vlocity_cmt__NumberofLocations__c, vlocity_cmt__PartyId__c, vlocity_cmt__PersonContactId__c, vlocity_cmt__PreferredLanguage__c, vlocity_cmt__PremisesId__c, vlocity_cmt__PrepayReloadThreshold__c, vlocity_cmt__PrimaryContactId__c, vlocity_cmt__RootAccountId__c, vlocity_cmt__SLA__c, vlocity_cmt__Status__c, vlocity_cmt__TaxExemptionEndDate__c, vlocity_cmt__TaxExemptionPercentage__c, vlocity_cmt__TaxExemptionStartDate__c, vlocity_cmt__TaxExemptionType__c, vlocity_cmt__TaxID__c, vlocity_cmt__vCustomerPriority__c, vlocity_cmt__vSLAExpirationDate__c, vlocity_cmt__vSLASerialNumber__c, vlocity_cmt__vSLA__c, vlocity_cmt__BillingAccountStatus__c, vlocity_cmt__FraudReason__c, vlocity_cmt__HasFraud__c, AccountCounter__c, Account_ID18__c, Accounting_ID__c, Associated__c, Auto_Approve__c, Billing_AccountId__c, Billing_AccountName__c, Billing_BillingStatus__c, Billing_BillingSystem__c, Billing__c, BrokerId18__c, BrokerName__c, BrokerStatus__c, Broker_AgreementEffectiveDate__c, Broker_Integration_Id__c, Broker_MobilePhone__c, BusinessPhone__c, CESReady__c, CSP_Status__c, Co_Owner1__c, Co_Owner2__c, ContactName__c, CurrentCreditRequest__c, Current_Associated_Contract__c,  DUNS__c, Email__c, Enrich_Error_Message__c, Enrich_UAN_Status__c, Entity_ID__c, Entity_Name__c, Estimated_End_Date__c, Estimated_Monthly_Usage_kWh__c, Estimated_Start_Date__c, FaxPhone__c, GForseva_City__c, GForseva_Country__c, GForseva_Postal_Code__c, GForseva_State__c, GForseva_Street__c, HU_Requested_Timestamp__c, Inactive__c, Installer_PPSAgent__c, Installer_Status__c, Installer_VendorID__c, Is_Minimum_Stay__c, LPC_Percent_Charge__c, LastLENChangeDate__c, Last_Enrich_Date__c, LeadSource__c, LegacyAccountID__c, Legacy_Id__c, LegalEntityName__c, MainCity__c, MainCountry__c, MainState__c, MainStreet__c, MainZipCode__c, Main_State__c, Meter_Tampering__c, NITS__c, NameExternalId__c, Notes__c,  Off_Peak__c, On_Peak__c, Open_Service_Orders__c, PPL_ER_Enrollment_Number_ID__c, PhoneExt__c, PrepaidPercentage__c, Prepay__c, PreviouslyKnownLegalEntityName__c, Request_ICAP__c, Request_Rate_Class__c, SLAExpirationDate__c, SLASerialNumber__c,  ServiceCity__c, ServiceCountry__c, ServiceStreet__c, ServiceZipCode__c, Service_Account_Unique_ID__c, Service_Annual_Consumption__c, Service_AssumedMeterType__c, Service_Avg_Usage__c, Service_BillingAccount__c, Service_Billing_City__c, Service_Billing_Country__c, Service_Billing_State__c, Service_Billing_Street__c, Service_Billing_ZipCode__c, Service_CAP_PLC__c, Service_CESUniqueAccountId__c, Service_CSP__c, Service_CapTagMaxEffectiveDate__c, Service_CapTagStatus__c, Service_Capacity__c, Service_ContractSegment__c, Service_CostingValidationStatus__c, Service_County__c, Service_CurrentReading__c, Service_CustomerClass__c, Service_DUNSGROUP__c, Service_DUNSNumber__c, Service_DropDate__c, Service_EstimatedEndDate__c, Service_EstimatedEndDatebatchupdate__c, Service_EstimatedMonthlyUsage__c, Service_ForecastedEstimatedMonthlyUsage__c, Service_GRTTax_Exemption__c, Service_HIStatus__c, Service_HURNotes__c, Service_HURReceivedTimestamp__c, Service_HURStatus__c, Service_HUStatus__c, Service_KW__c, Service_LastEnrichDate__c, Service_LifeSupportEquipment__c, Service_LoadProfile__c, Service_LocationName__c, Service_Marketer__c, Service_Matrix_Bill_Date__c, Service_Matrix_Capacity__c, Service_Matrix_Meter_Read_End__c, Service_Matrix_Meter_Read_Start__c, Service_Matrix_Monthly_Usage__c, Service_Matrix_NITS__c, Service_Max_Usage__c, Service_MemberID__c, Service_MeterReadCycle__c, Service_MeterType__c, Service_MeterTypeforMatrix__c, Service_Metered__c, Service_NITSMaxEffectiveDate__c, Service_NITSStatus__c, Service_NITSTagStatus__c, Service_NITS_PLC__c, Service_OfferCode__c, Service_OnFlowDate__c, Service_OnFlowDatebatchupdatePremiseinfo__c, Service_OptyIDUanNumberUnique__c, Service_OptyStartDate__c, Service_PMVISelfselectedFeeApproval__c, Service_PORUtility__c, Service_POR_Loss__c, Service_PowerRegion__c, Service_PremiseType__c, Service_RequireUDCCode__c, Service_RoundtheClock__c, Service_SalesTaxExemption__c, Service_SpecialBilling__c, Service_StationCode__c, Service_StationName__c, Service_Status__c, Service_TimeStampforUtilityAccount__c, Service_Type2__c, Service_Type_2__c, Service_UDCCode__c, Service_UsageReceivedTimestamp__c, Service_UsageRequestStatus__c, Service_UsageRequestedBy__c, Service_UsageRequestedTimestamp__c, Service_UtilityAccountNumber__c, Service_Utility__c, Special_Handling__c, TRMProcess__c, TX_Public_Utility_Assessment_Exemption__c, TaxIDNumber__c, Tax_Exemption_Certificate__c, Tax_Exemption_City_Local_Percent__c, Tax_Exemption_City_Percent__c, Tax_Exemption_County_Local_Percent__c, Tax_Exemption_County_Percent__c, Tax_Exemption_State_Percent__c, TerminationLetterSent__c, Tier__c,  Utility_CESReady__c, Utility_DEMANDAT1500__c, Utility_DEMANDAT2500__c, Utility_DEMANDAT3500__c, Utility_GEXABASECHARGE__c, Utility_HUNameKeyRequired__c, Utility_HUResponseTime__c, Utility_IDRResponseTime__c, Utility_LDCCode__c, Utility_LDCName__c, Utility_Market__c, Utility_MaxPricingDate__c, Utility_NeedICAP__c, Utility_NeedRateClasses__c, Utility_NeedUDCCode__c, Utility_Offcycle__c, Utility_PORPolicyinPlace__c, Utility_PORUtilityRateClass__c, Utility_PORbyRateClass__c, Utility_ReceiverDUNS__c, Utility_SenderDUNS__c, Utility_State__c, Utility_SupplierAccountNumber__c, Utility_TDSP_DEMANDAT1500__c, Utility_TDSP_DEMANDAT2500__c, Utility_TDSP_DEMANDAT3500__c, Utility_TDSP_KWHAT1500__c, Utility_TDSP_KWHAT2500__c, Utility_TDSP_KWHAT3500__c, Utility_TDSP_MONTHLYAT1500__c, Utility_TDSP_MONTHLYAT2500__c, Utility_TDSP_MONTHLYAT3500__c, Utility_UANLength__c, Utility_UANPrefix__c, UtiltiyAccountId18__c, Zone__c, OpportunityCount__c, Billing_BillOption__c, CompanyName__c, NY_Tax_applied__c, ServiceState__c, ServiceTypeCode__c, Service_ISO__c, Service_Material__c, Service_Matrix_Rate_Class__c, Service_Max_Pricing_Date__c, Service_RateClass__c, Service_ServiceType__c, Service_Type_Code__c, Service_Zone__c, Utility_Picklist__c, Utility_Receiver_Duns__c, uantest__c, Project__c, Resource_Type__c, Utility_CES_Utility_Code__c+FROM+Account+where+LastModifiedDate+>+{last_load_dttm}"

    }


EXTRA_PARAMS_NEERC_GLUE = {
  "raw-base-activity-event": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce-NEERCRM-Event",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-event",
    "target_table_name": "sfdc_neercrm_activity_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "owner": "Salesforce_NEERCRM",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_activity_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_activity_raw",
    "user_id": "zzz0talendaxis",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-activity-task": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Task",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-task",
    "target_table_name": "sfdc_neercrm_activity_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_activity_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_activity_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-contact-user": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_User",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-user",
    "target_table_name": "neercrm_contact_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_contact_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_contact_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-contact": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Contact",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-contact",
    "target_table_name": "sfdc_neercrm_contact_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_contact_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_contact_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-opportunity-details": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce-NEERCRM-Opportunity-Details",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-opportunity-details",
    "target_table_name": "sfdc_neercrm_opportunity_details_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_opportunity_details_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_opportunity_details_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-opportunity-team-member": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Opportunity_Team_Members",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-opportunity-team-member",
    "target_table_name": "sfdc_neercrm_opportunity_team_member_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_contact_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "sfdc_neercrm_opportunity_team_member_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-opportunity": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Opportunity",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-opportunity",
    "target_table_name": "sfdc_neercrm_opportunity_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_opportunity_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_opportunity_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-product": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Product",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-product",
    "target_table_name": "sfdc_neercrm_product_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_product_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_product_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-project-lookup": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Project",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-project",
    "target_table_name": "sfdc_neercrm_project_lookup_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_project_lookup_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_project_lookup_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-project": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Product",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-product",
    "target_table_name": "sfdc_neercrm_project_raw",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM_Owner",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "sfdc_neercrm_project_raw",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "stg_sfdc_neercrm_project_raw",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-system-users": {
    "REDSHIFT_DB_TABLE" : "edpdev",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name ": "EDP_AXIS",
    "source_system": "Salesforce_NEERCRM_Source_Task",
    "stage_name": "Raw-to-Base",
    "filename": "neercrm-source-raw-system-users",
    "target_table_name": "system_users",
    "landing_zone": "/landing/neer/neercrm/etl_batch_id.csv",
    "owner": "Salesforce_NEERCRM",
    "contact_identifier": "External",
    "target_db_schema": "vendor_customer_opportunities_raw",
    "target_db_table": "system_users",
    "staging_table_schema": "vendor_customer_opportunities_staging",
    "staging_table_name": "",
    "created_by": "Glue_ETL",
    "modified_by": "Glue_ETL",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  }
}

EXTRA_PARAMS_FPLES_GLUE = {
  "raw-base-activity-event": {
    "file_name": "raw-base-activity-event-s3",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/activityevent",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_activity_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_activity_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-activity-task": {
    "file_name": "raw-base-account-s3",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/account",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_activity_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_activity_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-contact": {
    "file_name": "raw-base-account-s3",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/account",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_contact_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_contact_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-account": {
    "file_name": "raw-base-account-s3",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/account",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_account_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_account_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-contact-user": {
    "file_name": "raw-base-account-s3",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/account",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_contact_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_contact_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  },
  "raw-base-opportunity": {
    "file_name": "source_raw_opportunity",
    "batch_status": "Batch Started",
    "load_type": "FULL",
    "project_name": "AXIS-FPLES",
    "source_system": "Source",
    "stage_name": "Raw-to-Base",
    "landing_zone": "landing/axis/fples/fples_source_raw_opportunity",
    "staging_table_schema": "vendor_customer_opportunities_raw",
    "staging_table_name": "stg_fples_opportunity_raw",
    "target_table_schema": "vendor_customer_opportunities_raw",
    "target_table_name": "fples_opportunity_raw",
    "audit_schema": "vendor_customer_opportunities_raw",
    "audit_table": "edp_axis_batch_control_log"
  }
}
