import boto3
from botocore.exceptions import ClientError
from datetime import datetime
import botocore
import time


class Handler:

    def __init__(self, params, batch_id):
        self.pipeline_name = params['pipeline_name']
        self.batch_id = batch_id
        self.log_group_name = params['log_group_name']
        self.logging_client = boto3.client('logs')
        self.region = 'us-east-1'
        self.sequenceToken = '999'
        
    def cloudwatchlog_url(self):
        base_url = "https://{}.console.aws.amazon.com/cloudwatch/home?region={}#logsV2:log-groups/log-group/".format(
            self.region, self.region)
        log_group_name = "{}/log-events/".format(self.log_group_name)
        logstream_name = "{}$2520-$2520{}".format(self.batch_id)
        final_url = base_url + log_group_name + logstream_name
        return final_url

    def log_to_stream(self, message):
        message = str(message)

        log_stream_name = self.batch_id

        now = int(time.time() * 1000) 

        event_log = {
            'logGroupName': self.log_group_name,
            'logStreamName': log_stream_name,
            'logEvents': [
                {
                    'timestamp': now,
                    'message': message
                }
            ],
            'sequenceToken': self.sequenceToken
        }
        max_retry = 2
        for retry in range(max_retry):
            try:
                response = self.logging_client.put_log_events(**event_log)
                self.sequenceToken = response["nextSequenceToken"]
                break
            except botocore.exceptions.ClientError as error:
                if error.response['Error']['Code'] == "InvalidSequenceTokenException":
                    print('in InvalidSequenceTokenException Retry Count-->' + str(retry))
                    event_log.update({"sequenceToken": error.response["Error"]["Message"].split("is: ")[-1]})
                    time.sleep(3)
                if error.response['Error']['Code'] == "DataAlreadyAcceptedException":
                    time.sleep(3)
                    pass
                if error.response['Error']['Code'] == "ResourceNotFoundException":
                    print('in ResourceNotFoundException  Creating ' + log_stream_name)
                    self.logging_client.create_log_stream(logGroupName=self.log_group_name,
                                                         logStreamName=log_stream_name)
                    event_log = {
                        'logGroupName': self.log_group_name,
                        'logStreamName': log_stream_name,
                        'logEvents': [
                            {
                                'timestamp': now,
                                'message': message
                            }
                        ]}

                    response = self.logging_client.put_log_events(**event_log)
                    self.sequenceToken = response["nextSequenceToken"]
                    pass

