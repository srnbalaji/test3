#!/bin/sh

template=$1

aws cloudformation validate-template --template-body file://$template

if [ $? -eq 0 ] 
then
    echo "Ok to proceed"
else
    echo "CFT Template validation failed for $template..."
    exit 1
fi
