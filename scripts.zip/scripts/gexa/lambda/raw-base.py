import json, time, re, os, sys
import boto3
import dateutil, time
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from redshiftutils.gmputils import connection as cn
from redshiftutils.gmputils import cloudwatch_logging as cwl
from updateinsertutils.gmputils import update_insert as ui
from axisconfig.gmputils import sp_config_axis as config



s3_key = os.environ['s3_key']


def lambda_handler(event, context):
   
    payload                 = event.get('Payload').get('payload')
    batch_id                = payload.get('batch_id')
    s3_bucket               = event.get('Payload').get('s3_bucket')
    job_name                = payload.get('job_name')
    environment             = payload.get('environment')
    landing_zone            = payload.get('landing_zone')
    rs_secret               = payload.get('rs_secret')
    region_name             = payload.get('region_name')
    staging_schema_table    = payload.get('staging_table')
    target_schema_table     = payload.get('target_table')
    params                  = payload.get('params')
    load_type               = payload.get('load_type')
    api_response_code       = event.get('Payload').get('api_response_code')
    
    staging_path            = s3_key + s3_bucket + '/'+ event.get('Payload').get('staging_path')
    iam_role                = config.iam_role[environment]['copy_cmd_role']
    CLOUDWATCH = cwl.Handler( params, batch_id)
    
    _secret = cn.get_secret(rs_secret,region_name,CLOUDWATCH )
    
    rs_conn = cn.get_redshift_conn(_secret, region_name)
    CLOUDWATCH.log_to_stream(' after getting RS connection ')
    cursor = rs_conn.cursor() 
    
    staging_table_name = staging_schema_table.split('.')[1]
    target_table_name = target_schema_table.split('.')[1]
    update_query_tgt = ""
    insert_query_tgt = ""
    
    try:
        delete_query = f"""DELETE FROM {staging_schema_table}"""
        CLOUDWATCH.log_to_stream('delete Statement  ' + delete_query  )
        cursor.execute(delete_query) 
        
        copy_query = f"""COPY {staging_schema_table} FROM '{staging_path}' iam_role '{iam_role}' FORMAT CSV delimiter ',' QUOTE '"' IGNOREHEADER 1"""
        cursor.execute(copy_query)
        
        staging_count_query = f"""(SELECT COUNT(*) FROM {staging_schema_table} custom)"""
        cursor.execute(staging_count_query)  
        staging_count = cursor.fetchone()[0]
        CLOUDWATCH.log_to_stream("stage count --> "+str(staging_count))
        
        
        if 'account' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_account(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
        elif 'event' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_event(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
        elif 'task' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_task(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
        elif 'opportunity' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_opportunity(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
        elif 'user' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_user(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
        elif 'contact' in job_name:
            update_query_tgt, insert_query_tgt  = ui.update_insert_contact(target_schema_table, target_table_name, staging_schema_table,staging_table_name)
          
         
        cursor.execute(update_query_tgt)  
        update_count = cursor.rowcount
        CLOUDWATCH.log_to_stream("update query executed successfully \n update count --> "+str(update_count))
       
        cursor.execute(insert_query_tgt)
        insert_count = cursor.rowcount
        CLOUDWATCH.log_to_stream("insert query executed successfully \n insert count --> "+str(insert_count))
        
        cursor.close()
        rs_conn.commit()
        rs_conn.close()
        CLOUDWATCH.log_to_stream(' after closing the connection ')
        
    except Exception as ex:
        CLOUDWATCH.log_to_stream('exception raised ' + str(ex))
        raise ex
        
    return {
        'statusCode'        : 200,
        'payload'           : payload,
        'modified_dttm'     : event.get('Payload').get('modified_dttm'),
        'records_updated'   : update_count,
        'records_inserted'  : insert_count,
        'sns_message'       : event.get('Payload').get('sns_message'),
        'api_response_code' : api_response_code
    }
