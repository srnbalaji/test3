import json, time, re, os, sys
import boto3
import dateutil, time
import pandas as pd
import csv
from io import StringIO
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from transformutils.gmputils import common_functions as cf
from transformutils.gmputils import transform as tr
from transformutils.gmputils import cloudwatch_logging as cwl



created_by  = os.environ['created_by']
modified_by = os.environ['modified_by']



def lambda_handler(event, context):
    # TODO implement
   
    payload         = event.get('Payload').get('payload')
    landing_zone    = payload.get('landing_zone')
    bucket          = event.get('Payload').get('s3_bucket')
    job_name        = payload.get('job_name')
    source_system   = payload.get('source_system')
    created_dttm    = payload.get('created_dttm')
    batch_id        = payload.get('batch_id')
    params          = payload.get('params')
    api_response_code = event.get('Payload').get('api_response_code')
    
    
    CLOUDWATCH      =   cwl.Handler( params, batch_id)
    s3_client = boto3.client('s3')
    
    csv_path = landing_zone.replace('json', 'csv/')
    modified_dttm = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
    
    
        
    json_filenames = cf.list_s3_files(s3_client,bucket,landing_zone)
    json_data_list = []
    
    
    for file in json_filenames:
        csv_file_name = file.split('/')[-1].replace('.json','')
        json_data_list = cf.read_json_df(bucket,s3_client,file)
        df = pd.DataFrame(json_data_list)
    
        if len(df) != 0:
        
            if 'account' in job_name : 
                df = tr.transform_gexa_raw_base_account(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
            elif 'contact' in job_name:
                df = tr.transform_gexa_raw_base_contact(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
            elif 'event' in job_name:
                df = tr.transform_gexa_raw_base_event(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)        
            elif 'opportunity' in job_name:
                df = tr.transform_gexa_raw_base_opportunity(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
            elif 'task' in job_name:  
                df = tr.transform_gexa_raw_base_task(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
            elif 'user' in  job_name:
                df = tr.transform_gexa_raw_base_user(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                
            cf.write_csv(df,bucket,s3_client,csv_path,csv_file_name)
            CLOUDWATCH.log_to_stream("json data written to csv")
           
    
        else:
            cf.write_csv(df,bucket,s3_client,csv_path,csv_file_name)
            CLOUDWATCH.log_to_stream("empty json data written to csv")
       
    return {
        'statusCode'    : 200,
        'payload'       : payload,
        'staging_path'  : csv_path,
        's3_bucket'     : bucket,
        'modified_dttm' : modified_dttm,
        'sns_message'   : event.get('Payload').get('sns_message'),
        'api_response_code' : api_response_code
    }

