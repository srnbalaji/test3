import json, time, re, os, sys
import psycopg2
import boto3
import json
import dateutil, time
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from redshiftutils.gmputils import connection as cn
from redshiftutils.gmputils import cloudwatch_logging as cwl

JOB_NAME        =""
RS_SECRET       =""
REGION_NAME     =""

batch_id1    = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] 
params      = { "pipeline_name": os.environ['pipeline_name'], "log_group_name": os.environ['log_group_name'] }
#CLOUDWATCH  = cwl.Handler( params, batch_id1)

audit_schema = os.environ['audit_schema']
audit_table = os.environ['audit_table']
environment = os.environ['environment']
sns_arn = os.environ['sns_arn']

def sns_publish(sns_arn, email_sub, email_body, CLOUDWATCH):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        CLOUDWATCH.log_to_stream(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag, job_name, envronment, error, CLOUDWATCH):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = cn.timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name   :  {environment},
            Job Status  :  Failure ,
            Job Failure Reason  :  {error},
            Lambda Name : Last_Load_Date,
            Service  :  AWS -Lambda  
        """
        success_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name  :  {environment},
            Job Status  :  Success,
            Lambda Name : Last_Load_Date,
            Service  :  AWS-Lambda,
        """
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment, error=error)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_GEXA_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        CLOUDWATCH.log_to_stream(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e

def lambda_handler(event, context):
    global JOB_NAME, RS_SECRET, REGION_NAME, etl_batch_id, CLOUDWATCH
    JOB_NAME        = event.get('job_name')
    etl_batch_id    = f"{JOB_NAME}_source_raw_{batch_id1}"
    CLOUDWATCH  = cwl.Handler( params, etl_batch_id)
    try:
        # TODO implement
        
        RS_SECRET       = event.get('rs_secret')
        SF_SECRET       = event.get('sf_secret')
        REGION_NAME     = event.get('region_name')
        LOAD_TYPE       = event.get('load_type')
        BATCH_STATUS    = event.get('batch_status')
        PROJECT_NAME    = event.get('project_name')
        SOURCE_SYSTEM   = event.get('source_system')
        STAGE_NAME      = event.get('stage_name')
        STAGING_TABLE   = event.get('staging_table_name')
        TARGET_TABLE    = event.get('target_table_name')
        LANDING_ZONE    = event.get('landing_zone')

        ENVIRONMENT     = event.get('environment')
        SOQL_QUERY      = event.get('soql_query')
        
        
        created_dttm        = cn.timestamp_generator('%Y-%m-%d %H:%M:%S.%f')[:-3]
        job_start_dttm      = created_dttm
        batch_start_dttm    = created_dttm
        job_end_dttm        = created_dttm
        batch_init_status   = "Batch Successful"
        
        _secret = cn.get_secret(RS_SECRET, REGION_NAME,CLOUDWATCH)
        CLOUDWATCH.log_to_stream( ' secret received ')
        sql_stmt = cn.get_sql_stmt(JOB_NAME,audit_schema,audit_table, batch_init_status)
        CLOUDWATCH.log_to_stream (' sql statement ' + sql_stmt )
        
        rs_conn = cn.get_redshift_conn(_secret, REGION_NAME)
        CLOUDWATCH.log_to_stream(' after getting RS connection ')
        
        cursor = rs_conn.cursor() 
        cursor.execute(sql_stmt) 
        results = cursor.fetchall()
        last_load_dttm=results[0][0].strftime('%Y/%m/%d %H:%M:%S')
        CLOUDWATCH.log_to_stream('last load date and time ' + last_load_dttm )
        
        
        cursor.close()
        rs_conn.commit()
        rs_conn.close()
        CLOUDWATCH.log_to_stream(' after closing the connection ')

        if 'edp-axis-gexa-source-raw-account' in JOB_NAME:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(1)
        elif 'edp-axis-gexa-source-raw-contact' in JOB_NAME:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(2)
        elif 'edp-axis-gexa-source-raw-event' in JOB_NAME:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(3)
        elif 'edp-axis-gexa-source-raw-opportunity' in JOB_NAME:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(4)
        elif 'edp-axis-gexa-source-raw-task' in JOB_NAME:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(5)
        else:
            batch_id = cn.timestamp_generator("%Y%m%d%H%M%S%f")[:-3] + str(6)
        
        return {
            'statusCode': 200,
            'last_load_dttm' : last_load_dttm,
            'body'          : " Successful execution to get last load date ",
            'batch_start_dttm' : batch_start_dttm,
            'job_name'      :   JOB_NAME, 
            'rs_secret'     :   RS_SECRET,
            'sf_secret'     :   SF_SECRET,
            'region_name'   :   REGION_NAME,
            'load_type'     :   LOAD_TYPE,
            'batch_id'      :   batch_id,
            'batch_status'  :   BATCH_STATUS,
            'project_name'  :   PROJECT_NAME,
            'source_system' :   SOURCE_SYSTEM,
            'stage_name'    :   STAGE_NAME,
            'staging_table' :   STAGING_TABLE,
            'target_table'  :   TARGET_TABLE,
            'landing_zone'  :   LANDING_ZONE,
            'created_dttm'  :   created_dttm,
            'environment'   :   ENVIRONMENT,
            'soql_query'    :   SOQL_QUERY,
            'params'        :   params,
            'audit_schema'  :   audit_schema,
            'audit_table'   :   audit_table,
            'etl_batch_id'  :   etl_batch_id
        }
    except Exception as e:
        CLOUDWATCH.log_to_stream(f"Job failed with following error ......{e}")
        error = str(e).replace("'", '"')
        email_content = generate_email_body("failure", JOB_NAME, error)
        email_sub = email_content[0]
        email_body = email_content[1]
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            CLOUDWATCH.log_to_stream("Failure Email sent successfully")
        else:
            CLOUDWATCH.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
        error_message = f"Job failed with following error: {str(e)}"
        CLOUDWATCH.log_to_stream(error_message)
        CLOUDWATCH.log_to_stream(' error in execution ' + str(e) )
        return {
            'statusCode': 500,
            'error'     : str(e)
        }
        
