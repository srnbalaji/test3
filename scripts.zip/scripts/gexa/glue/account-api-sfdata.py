import json
import requests
import boto3 
import sys, re
import math
import time
import dateutil
import psycopg2
import pandas as pd
import sp_config_axis as config
import cloudwatch_logging
from io import StringIO
from multiprocessing import Process
from datetime import datetime, timedelta
from awsglue.utils import getResolvedOptions
from urllib.parse import urlparse



##################################  JOB_NAME -- EDP_Servicenow_Tech_Stacks #############################
args = getResolvedOptions(sys.argv,["batch_id","sf_secret", "job_name","landing_zone","load_type","environment","region_name","last_load_dttm","soql_query","s3_bucket","records_fetched_count_path"])
job_name = args["job_name"]
load_type = args["load_type"]
environment =  args["environment"].upper()
batch_id = args["batch_id"]
sf_secret = args["sf_secret"]
landing_zone = args["landing_zone"]
region_name = args["region_name"]
last_load_dttm = args["last_load_dttm"]
soql_query = args['soql_query']
print(f"last_load_dttm -- {last_load_dttm} and type of last_load_dttm -- {last_load_dttm}")
s3_client = boto3.client("s3")
s3_bucket = args["s3_bucket"]
records_fetched_count_path = args["records_fetched_count_path"]

sns_arn = config.sns_arn[environment]
log_group = config.LOG_FILES_Gexa[environment]

params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)
        return result
    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        cloudwatch.log_to_stream(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag):
    
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error_message)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        cloudwatch.log_to_stream(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e

def get_secret(secret_name, region_name, cloudwatch):
    try:
        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name
        )
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(get_secret_value_response['SecretString'])
        return secret
    except Exception as e:
        cloudwatch.log_to_stream(f"get_secret function failed with follwoing error..... {e} ")
        raise e

        
# write the raw data into s3
def write_to_s3(data, buc_name, obj_name):
    try:
        s3_clt = boto3.resource('s3')
        s3obj = s3_clt.Object(buc_name, obj_name)
        s3obj.put( Body=bytes(json.dumps(data).encode('UTF-8')))
        return True
    except Exception as e:
        cloudwatch.log_to_stream(f"write_to_s3 function failed with follwoing error..... {e} ")
        raise e


def list_s3_csv_files(s3_client,bucket,prefix):
    try:
        file =''
        filenames = []
        result = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if len(result) != 0 and 'Contents' in result.keys():
            for item in result['Contents']:
                file = item['Key']
                if file.endswith('.csv'):
                    #print(f"file: ", file)
                    filenames.append(file)  
        return filenames 
    except Exception as e:
        cloudwatch.log_to_stream(f"get_secret function failed with follwoing error..... {e} ")
        raise e

    
def list_s3_files(s3_client,bucket,prefix):
    try:
        file =''
        filenames = []
        result = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if len(result) != 0 and 'Contents' in result.keys():
            for item in result['Contents']:
                file = item['Key']
                if file.endswith('.json'):
                    #print(f"file: ", file)
                    filenames.append(file)  
            return filenames
        return filenames
    except Exception as e:
        cloudwatch.log_to_stream(f"get_secret function failed with follwoing error..... {e} ")
        raise e

def get_redshift_conn(__secret, region_name):
    try:
        
        rs_host     = __secret.get('hostname') ##"jdbc:redshift://redshift-edp-dev.czvsewxs0afi.us-east-1.redshift.amazonaws.com:5617/edpdev"
        rs_port     = __secret.get('port')
        rs_db       = __secret.get('databasename') ##"edpdev"
        rs_username = __secret.get('username')
        rs_password = __secret.get('password')
        
        conn = psycopg2.connect( host=rs_host, port=rs_port, user=rs_username, password=rs_password,dbname=rs_db)
        cloudwatch.log_to_stream("Created redshift connection")
        return conn
    except Exception as e:
        cloudwatch.log_to_stream(f"redshift_conn function failed with follwoing error..... {e} ")
        raise e

def convert_datetime_to_sf_format(last_load_dttm):
    try:
        dt_obj=datetime.strptime(last_load_dttm, '%Y/%m/%d %H:%M:%S')
        sf_formatted_date = dt_obj.strftime("%Y-%m-%dT%H:%M:%SZ")
        dt_obj.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]+"+0000"    
        cloudwatch.log_to_stream(f' sf_formatted_date -----  {sf_formatted_date}' )
        return sf_formatted_date
    except Exception as e:
        cloudwatch.log_to_stream(f"get_secret function failed with follwoing error..... {e} ")
        raise e

def get_token (jdata):
    data = {'client_id': jdata.get('clientId'), 'username': jdata.get('username'), 'password': jdata.get('password'), 'client_secret': jdata.get('clientSecret'), 'grant_type': jdata.get('passwordGrantType')}

    headers = {"Content-Type": "application/json; charset=utf-8"}

    try:
       response = requests.post(jdata.get('urlToken'), data, verify=False).content.decode('utf-8')
       return json.loads(response)
    except Exception as e:
       cloudwatch.log_to_stream(f" Error in getting KC access.. {str(e)}" )


try:
    #### SF api data #####
    csv_path = landing_zone.replace('json','csv')

    jsecret = get_secret(sf_secret, region_name,cloudwatch)
    url_end_pt = jsecret.get('urlEndpoint').replace('composite','query?q=')
    
    purl = urlparse(url_end_pt)
    base_url  = purl.scheme +'://' + purl.netloc + '/'
    
    resp = get_token(jsecret)
    cloudwatch.log_to_stream(f' access response received')
    
    access_token = resp.get('access_token')
    cloudwatch.log_to_stream(f'granted token access' )
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + access_token }
    
    
    if load_type.upper() == "FULL":
        full_url_end_point = url_end_pt + soql_query.replace('+where+LastModifiedDate+>+{last_load_dttm}','' )
        
    elif load_type.upper() == "DELTA" :
        sf_formatted_date = convert_datetime_to_sf_format(last_load_dttm)
        full_url_end_point = url_end_pt + soql_query.replace('{last_load_dttm}',sf_formatted_date )
        
    else:
        cloudwatch.log_to_stream("Warning : Not a valid load type, it should be FULL or DELTA")
        
    #cloudwatch.log_to_stream(f' full URL end point :  {full_url_end_point}' )
    print(f"full URL end point -- {full_url_end_point}")

    ###Delete existing csv files
    delete_csv = list_s3_csv_files(s3_client,s3_bucket,csv_path)
    if len(delete_csv) != 0:
        for object in delete_csv:
        	s3_client.delete_object(Bucket=s3_bucket, Key=object) 

    #Delete the previous run json files from the path
    delete_json = list_s3_files(s3_client,s3_bucket,landing_zone)
    if len(delete_json) != 0:
        for object in delete_json:
        	s3_client.delete_object(Bucket=s3_bucket, Key=object)  
        	
    __done = False
    records = []  
    write_count = 0
        
    records_fetched_count = 0
    api_response_code = 0
    
    while not __done:
        try:
            response = requests.get(full_url_end_point, headers=headers)
            api_response_code = response.status_code
            if response.status_code == 200:
                cloudwatch.log_to_stream(f' inside IF. response. status :  {str(response.status_code)}' )
                data = json.loads(response.text)
                records_fetched_count = data['totalSize']
                cloudwatch.log_to_stream(f" ----- done :  {str(data['done'])}  totalSize :  {str(data['totalSize'])}")
                if data.get('nextRecordsUrl') is not None:
                    cloudwatch.log_to_stream(f" nextRecordsUrl ----- > {str(data.get('nextRecordsUrl'))}" )
                    
                if len(data['records']) > 0 :
                    records.extend(data['records'])
                if len(records) >= 10000:
                    filename= landing_zone.rstrip('/') + '/' + batch_id + '_' + str(write_count) + '.json'
                    
                    cloudwatch.log_to_stream(f's3 bucket name  {s3_bucket}-------- the filename ------->  {filename}')
                    write_to_s3(records, s3_bucket, filename)
                    write_count+=1
                    records.clear()
                if data['done']:
                    __done = True
                    cloudwatch.log_to_stream(' stopping here....')
                else:    
                    full_url_end_point =  base_url.rstrip('/')+'/'+data.get('nextRecordsUrl').lstrip('/')
                    cloudwatch.log_to_stream(' callign the next url ' + full_url_end_point )
            else:
                raise Exception(f"{job_name} job failed with following Error  {str(response.text)}")
        except Exception as e:
            cloudwatch.log_to_stream(f"{job_name} job failed with following Error {str(response.text)}")
            raise e 

    
    cloudwatch.log_to_stream(f' -------------no of records received  {str(len(records))}' )    

    
    filename= landing_zone.rstrip('/') + '/' + batch_id + '_' + str(write_count) + '.json'
    cloudwatch.log_to_stream(f's3 bucket name  {s3_bucket}-------- the filename ------->  {filename}')
    
    write_to_s3(records, s3_bucket, filename)
    cloudwatch.log_to_stream("records written to s3")
    
    # Writing records_fetched to text file s3 hence it can be available for calling job_name
    #records_fetched_count_path = landing_zone + "/records_fetched/"+ "records_fetched_count.txt"
    cloudwatch.log_to_stream(f"records_fetched_count_path -- {records_fetched_count_path}")
    #write_to_s3(records_fetched_count, s3_bucket, records_fetched_count_path)
    
    s3_client.put_object( Body=bytes(json.dumps(records_fetched_count).encode('UTF-8')),Bucket=s3_bucket,Key=records_fetched_count_path)
    cloudwatch.log_to_stream(f"records_fetched_count written to text file {records_fetched_count}")
    # Use the put method to place the string in a new S3 object
    #s3_client.Object(s3_bucket, records_fetched_count_path).put(Body=records_fetched_count)
    #s3obj.put(Body=records_fetched_count)
    
    # On successful export of data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
    cloudwatch.log_to_stream("Script executed successfully......  check data in redshift")
    cloudwatch.log_to_stream("Writing  data to redshift has been successfully done..")
except Exception as e:
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    cloudwatch.log_to_stream(error_message)
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
    error_message = f"Job failed with following error: {str(e)}"
    cloudwatch.log_to_stream(error_message)
    raise e
