import json
import requests
import boto3 
import sys, re
import math
import time
import dateutil
import psycopg2
import pandas as pd
import sp_config_axis as config
import cloudwatch_logging
from io import StringIO
from multiprocessing import Process
from datetime import datetime, timedelta
from awsglue.utils import getResolvedOptions


##################################  JOB_NAME -- edp-axis-gexa-account #############################
args = getResolvedOptions(sys.argv,["REDSHIFT_DB_TABLE","environment", "job_name","load_type"])
job_name = args["job_name"]
load_type = args["load_type"]
environment =  args["environment"].upper()
extra_params = config.gexa_account
extra_params1 = json.dumps(extra_params)

s3_client = boto3.client('s3')
glue = boto3.client("glue")
#json_path = config.tmp_json_path + job_name + '/staging/json/'
#csv_path = json_path.replace('json','csv')
s3_bucket = config.bucket[environment]
region_name = extra_params.get("region_name")
sf_secret = config.secrets[environment]['sf_secret']
rs_secret = config.secrets[environment]['rs_secret']
api_sub_job_name = config.api_sub_job_name[environment]
audit_schema = extra_params.get('audit_schema')
audit_table = extra_params.get('audit_table')
s3_object_name  = extra_params.get('s3_object_key')
project_name =  extra_params.get("project_name")
source_system= extra_params.get("source_system")
stage_name = extra_params.get("stage_name")
staging_schema_table = extra_params.get("staging_table_name")
target_schema_table = extra_params.get("target_table_name")
landing_zone = extra_params.get("landing_zone")
soql_query = extra_params.get("soql_query")
created_by = extra_params.get("created_by")
modified_by = extra_params.get("modified_by")
s3_key = extra_params.get("s3_key")
batch_status = extra_params.get("batch_status")
records_fetched_count_path = landing_zone + "/records_fetched/"+ "records_fetched_count.txt"
sns_arn = config.sns_arn[environment]
log_group = config.LOG_FILES_Gexa[environment]

params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        cloudwatch.log_to_stream(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag):
    
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error_message)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_GEXA_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        cloudwatch.log_to_stream(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e

### all util functions
def get_secret(secret_name, region_name, cloudwatch):
    try:
        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(service_name='secretsmanager',region_name=region_name)
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(get_secret_value_response['SecretString'])
        return secret
    except Exception as e:
        cloudwatch.log_to_stream(f"get_secret function failed with follwoing error..... {e} ")
        raise e

         
# write the raw data into s3
def write_to_s3(data, buc_name, obj_name):
    try:
        s3_clt = boto3.resource('s3')
        s3obj = s3_clt.Object(buc_name, obj_name)
        s3obj.put( Body=bytes(json.dumps(data).encode('UTF-8')))
        cloudwatch.log_to_stream("Successfully passed in write_to_s3 function")
        return True
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in write_to_s3 function with following error : {e}")
        raise e


def list_s3_csv_files(s3_client,bucket,prefix):
    try:
        file =''
        filenames = []
        result = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if len(result) != 0 and 'Contents' in result.keys():
            for item in result['Contents']:
                file = item['Key']
                if file.endswith('.csv'):
                    #print(f"file: ", file)
                    filenames.append(file) 
        cloudwatch.log_to_stream("Successfully passed in list_s3_csv_files function")
        return filenames 
    except Exception as e:
            cloudwatch.log_to_stream(f"Job failed in list_s3_csv_files function with following error : {e}")
            raise e

    
def list_s3_files(s3_client,bucket,prefix):
    try:
        file =''
        filenames = []
        result = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if len(result) != 0 and 'Contents' in result.keys():
            for item in result['Contents']:
                file = item['Key']
                if file.endswith('.json'):
                    #print(f"file: ", file)
                    filenames.append(file)  
            return filenames
        cloudwatch.log_to_stream("Successfully passed in list_s3_files function")
        return filenames
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in list_s3_files function with following error : {e}")
        raise e
  


def get_sql_stmt(job_name,audit_schema,audit_table, batch_init_status):
    try:
        SQL_STMT= f""" Select nvl(max(last_load_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm  from {audit_schema}.{audit_table} where job_name = '{job_name}' and batch_status = '{batch_init_status}' """    
        cloudwatch.log_to_stream(f"Successfully passed get_sql_stmt function")
        return SQL_STMT
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in get_sql_stmt function with following error : {e}")
        raise e
  
def get_redshift_conn(__secret, region_name):
    try:
        
        rs_host     = __secret.get('hostname') ##"jdbc:redshift://redshift-edp-dev.czvsewxs0afi.us-east-1.redshift.amazonaws.com:5617/edpdev"
        rs_port     = __secret.get('port')
        rs_db       = __secret.get('databasename') ##"edpdev"
        rs_username = __secret.get('username')
        rs_password = __secret.get('password')
        
        conn = psycopg2.connect( host=rs_host, port=rs_port, user=rs_username, password=rs_password,dbname=rs_db)
        cloudwatch.log_to_stream("Created redshift connection")
        return conn
    except Exception as e:
        cloudwatch.log_to_stream(f"redshift_conn function failed with follwoing error..... {e} ")
        raise e


def read_json_df(BUCKET,s3_client,filename):
    try:
        # Get the file inside the S3 Bucket
        s3_response = s3_client.get_object(Bucket=BUCKET,Key=filename)
        # Get the Body object in the S3 get_object() response
        s3_object_body = s3_response.get('Body')
        # Read the data in bytes format
        content = s3_object_body.read()
        s3_json_data = json.loads(content)
        cloudwatch.log_to_stream(f"Successfully passed read_json_df function")
        return s3_json_data
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in read_json_df function with following error : {e}")
        raise e

def add_columns(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm ):
    try:
        df['batch_id'] = batch_id
        df['source_system'] = source_system
        df['created_by'] = created_by
        df['created_dttm'] = created_dttm
        df['modified_by'] = modified_by
        df['modified_dttm'] = modified_dttm
        cloudwatch.log_to_stream("Successfully passed in add_columns function")
        return df
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in add_columns function with following error : {e}")
        raise e


def transform_gexa_raw_base_account(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm):
    try:
        #df['Description'] = df['Description'].replace({'\\r\\n|\\r|\\n' : '',None:'','null':''},regex=True).str[:64000]
        df['Description'] = (df['Description'].str.replace('\\r\\n|\\r|\\n', '', regex=True).str.replace('None', '', regex=True).str.replace('null', '', regex=True).str[:64000])
        ##df['Enrich_Error_Message__c'] =df.loc[df['Enrich_Error_Message__c'].notnull()]
        ##print(df1['Enrich_Error_Message__c'])
        df['Enrich_Error_Message__c'] =  df['Enrich_Error_Message__c'].str[:50]
        #df['MainStreet__c'] = df['MainStreet__c'].replace({'\\r\\n|\\r|\\n' : '',None:'','null':''},regex=True).str[:255]
        df['MainStreet__c'] = (df['MainStreet__c'].str.replace('\\r\\n|\\r|\\n', '', regex=True).str.replace('None', '', regex=True).str.replace('null', '', regex=True).str[:255])
        df['Service_Billing_Street__c'] =  df['Service_Billing_Street__c'].str[:50]
        df['Service_HURNotes__c'] = ''
        df['sla__c'] = ''
        df['customerpriority__c'] = ''
        df['numberoflocations__c'] = ''
        df['upsellopportunity__c'] = ''
        df['CreatedDate'] = pd.to_datetime(df.CreatedDate)
        df['LastModifiedDate'] = pd.to_datetime(df.LastModifiedDate)
        df['SystemModstamp'] = pd.to_datetime(df.SystemModstamp)
        df['Service_HURReceivedTimestamp__c'] = pd.to_datetime(df.Service_HURReceivedTimestamp__c)
        df['Service_LastEnrichDate__c'] = pd.to_datetime(df.Service_LastEnrichDate__c)
        df['Service_UsageReceivedTimestamp__c'] = pd.to_datetime(df.Service_UsageReceivedTimestamp__c)
        df['HU_Requested_Timestamp__c'] = pd.to_datetime(df.HU_Requested_Timestamp__c)
        df['vlocity_cmt__TaxExemptionEndDate__c'] = pd.to_datetime(df.vlocity_cmt__TaxExemptionEndDate__c, errors = 'coerce')
        df['vlocity_cmt__TaxExemptionStartDate__c'] = pd.to_datetime(df.vlocity_cmt__TaxExemptionStartDate__c, errors = 'coerce')
        df['NumberOfEmployees'] = df['NumberOfEmployees'].fillna(0).astype(int)
        df = add_columns(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm )
        
        #renaming columns to lower to avoid key error
        df = df.rename(columns=str.lower)
        
        new_df = df[['id','isdeleted','masterrecordid','name','type','recordtypeid','parentid','billingstreet',
        'billingcity','billingstate','billingpostalcode','billingcountry','billinglatitude','billinglongitude',
        'billinggeocodeaccuracy','billingaddress','shippingstreet','shippingcity','shippingstate','shippingpostalcode',
        'shippingcountry','shippinglatitude','shippinglongitude','shippinggeocodeaccuracy','shippingaddress','phone','fax',
        'accountnumber','website','photourl','sic','industry','annualrevenue','numberofemployees','ownership','tickersymbol',
        'description','rating','site','ownerid','createddate','createdbyid','lastmodifieddate','lastmodifiedbyid','systemmodstamp',
        'lastactivitydate','lastvieweddate','lastreferenceddate','jigsaw','jigsawcompanyid','accountsource','sicdesc','vlocity_cmt__accountpaymenttype__c',
        'vlocity_cmt__active__c','vlocity_cmt__autopaymentamount__c','vlocity_cmt__autopaymentcardtype__c','vlocity_cmt__autopaymentlimitamount__c',
        'vlocity_cmt__autopaymentmethodid__c','vlocity_cmt__billcycle__c','vlocity_cmt__billdeliverymethod__c','vlocity_cmt__billformat__c',
        'vlocity_cmt__billfrequency__c','vlocity_cmt__billnumberofcopies__c','vlocity_cmt__billingemailaddress__c','vlocity_cmt__cltv__c',
        'vlocity_cmt__calculatedaddress__c','vlocity_cmt__churn__c','vlocity_cmt__contactpreferences__c','vlocity_cmt__creditrating__c',
        'vlocity_cmt__creditscore__c','vlocity_cmt__customerclass__c','vlocity_cmt__customerofbrand__c','vlocity_cmt__customervalue__c',
        'vlocity_cmt__datefounded__c','vlocity_cmt__directorylisted__c','vlocity_cmt__disclosure1__c','vlocity_cmt__disclosure2__c',
        'vlocity_cmt__disclosure3__c','vlocity_cmt__enableautopay__c','vlocity_cmt__ispersonaccount__c','vlocity_cmt__isrootresolved__c',
        'vlocity_cmt__juridsiction1__c','vlocity_cmt__jurisdiction2__c','vlocity_cmt__legalform__c','vlocity_cmt__networth__c',
        'vlocity_cmt__numberoflocations__c','vlocity_cmt__partyid__c','vlocity_cmt__personcontactid__c','vlocity_cmt__preferredlanguage__c',
        'vlocity_cmt__premisesid__c','vlocity_cmt__prepayreloadthreshold__c','vlocity_cmt__primarycontactid__c','vlocity_cmt__rootaccountid__c',
        'vlocity_cmt__sla__c','vlocity_cmt__status__c','vlocity_cmt__taxexemptionenddate__c','vlocity_cmt__taxexemptionpercentage__c',
        'vlocity_cmt__taxexemptionstartdate__c','vlocity_cmt__taxexemptiontype__c','vlocity_cmt__taxid__c','vlocity_cmt__vcustomerpriority__c',
        'vlocity_cmt__vslaexpirationdate__c','vlocity_cmt__vslaserialnumber__c','vlocity_cmt__vsla__c','vlocity_cmt__billingaccountstatus__c',
        'vlocity_cmt__fraudreason__c','vlocity_cmt__hasfraud__c','accountcounter__c','account_id18__c','accounting_id__c','associated__c','auto_approve__c',
        'billing_accountid__c','billing_accountname__c','billing_billingstatus__c','billing_billingsystem__c','billing__c','brokerid18__c','brokername__c',
        'brokerstatus__c','broker_agreementeffectivedate__c','broker_integration_id__c','broker_mobilephone__c','businessphone__c','cesready__c','csp_status__c',
        'co_owner1__c','co_owner2__c','contactname__c','currentcreditrequest__c','current_associated_contract__c','customerpriority__c','duns__c','email__c',
        'enrich_error_message__c','enrich_uan_status__c','entity_id__c','entity_name__c','estimated_end_date__c','estimated_monthly_usage_kwh__c','estimated_start_date__c',
        'faxphone__c','gforseva_city__c','gforseva_country__c','gforseva_postal_code__c','gforseva_state__c','gforseva_street__c','hu_requested_timestamp__c','inactive__c',
        'installer_ppsagent__c','installer_status__c','installer_vendorid__c','is_minimum_stay__c','lpc_percent_charge__c','lastlenchangedate__c','last_enrich_date__c',
        'leadsource__c','legacyaccountid__c','legacy_id__c','legalentityname__c','maincity__c','maincountry__c','mainstate__c','mainstreet__c','mainzipcode__c',
        'main_state__c','meter_tampering__c','nits__c','nameexternalid__c','notes__c','numberoflocations__c','off_peak__c','on_peak__c','open_service_orders__c',
        'ppl_er_enrollment_number_id__c','phoneext__c','prepaidpercentage__c','prepay__c','previouslyknownlegalentityname__c','request_icap__c','request_rate_class__c',
        'slaexpirationdate__c','slaserialnumber__c','sla__c','servicecity__c','servicecountry__c','servicestreet__c','servicezipcode__c','service_account_unique_id__c',
        'service_annual_consumption__c','service_assumedmetertype__c','service_avg_usage__c','service_billingaccount__c','service_billing_city__c','service_billing_country__c',
        'service_billing_state__c','service_billing_street__c','service_billing_zipcode__c','service_cap_plc__c','service_cesuniqueaccountid__c','service_csp__c',
        'service_captagmaxeffectivedate__c','service_captagstatus__c','service_capacity__c','service_contractsegment__c','service_costingvalidationstatus__c','service_county__c',
        'service_currentreading__c','service_customerclass__c','service_dunsgroup__c','service_dunsnumber__c','service_dropdate__c','service_estimatedenddate__c',
        'service_estimatedenddatebatchupdate__c','service_estimatedmonthlyusage__c','service_forecastedestimatedmonthlyusage__c','service_grttax_exemption__c',
        'service_histatus__c','service_hurnotes__c','service_hurreceivedtimestamp__c','service_hurstatus__c','service_hustatus__c','service_kw__c','service_lastenrichdate__c',
        'service_lifesupportequipment__c','service_loadprofile__c','service_locationname__c','service_marketer__c','service_matrix_bill_date__c','service_matrix_capacity__c',
        'service_matrix_meter_read_end__c','service_matrix_meter_read_start__c','service_matrix_monthly_usage__c','service_matrix_nits__c','service_max_usage__c',
        'service_memberid__c','service_meterreadcycle__c','service_metertype__c','service_metertypeformatrix__c','service_metered__c','service_nitsmaxeffectivedate__c',
        'service_nitsstatus__c','service_nitstagstatus__c','service_nits_plc__c','service_offercode__c','service_onflowdate__c','service_onflowdatebatchupdatepremiseinfo__c',
        'service_optyiduannumberunique__c','service_optystartdate__c','service_pmviselfselectedfeeapproval__c','service_porutility__c','service_por_loss__c',
        'service_powerregion__c','service_premisetype__c','service_requireudccode__c','service_roundtheclock__c','service_salestaxexemption__c','service_specialbilling__c',
        'service_stationcode__c','service_stationname__c','service_status__c','service_timestampforutilityaccount__c','service_type2__c','service_type_2__c','service_udccode__c',
        'service_usagereceivedtimestamp__c','service_usagerequeststatus__c','service_usagerequestedby__c','service_usagerequestedtimestamp__c','service_utilityaccountnumber__c',
        'service_utility__c','special_handling__c','trmprocess__c','tx_public_utility_assessment_exemption__c','taxidnumber__c','tax_exemption_certificate__c',
        'tax_exemption_city_local_percent__c','tax_exemption_city_percent__c','tax_exemption_county_local_percent__c','tax_exemption_county_percent__c',
        'tax_exemption_state_percent__c','terminationlettersent__c','tier__c','upsellopportunity__c','utility_cesready__c','utility_demandat1500__c','utility_demandat2500__c',
        'utility_demandat3500__c','utility_gexabasecharge__c','utility_hunamekeyrequired__c','utility_huresponsetime__c','utility_idrresponsetime__c','utility_ldccode__c',
        'utility_ldcname__c','utility_market__c','utility_maxpricingdate__c','utility_needicap__c','utility_needrateclasses__c','utility_needudccode__c','utility_offcycle__c',
        'utility_porpolicyinplace__c','utility_porutilityrateclass__c','utility_porbyrateclass__c','utility_receiverduns__c','utility_senderduns__c','utility_state__c',
        'utility_supplieraccountnumber__c','utility_tdsp_demandat1500__c','utility_tdsp_demandat2500__c','utility_tdsp_demandat3500__c','utility_tdsp_kwhat1500__c',
        'utility_tdsp_kwhat2500__c','utility_tdsp_kwhat3500__c','utility_tdsp_monthlyat1500__c','utility_tdsp_monthlyat2500__c','utility_tdsp_monthlyat3500__c',
        'utility_uanlength__c','utility_uanprefix__c','utiltiyaccountid18__c','zone__c','opportunitycount__c','billing_billoption__c','companyname__c','ny_tax_applied__c',
        'servicestate__c','servicetypecode__c','service_iso__c','service_material__c','service_matrix_rate_class__c','service_max_pricing_date__c','service_rateclass__c',
        'service_servicetype__c','service_type_code__c','service_zone__c','utility_picklist__c','utility_receiver_duns__c','uantest__c','project__c','resource_type__c',
        'utility_ces_utility_code__c','batch_id','source_system','created_by','created_dttm','modified_by','modified_dttm']] 
        cloudwatch.log_to_stream(f"successfully passed in new_df function")
        return new_df
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in new_df function with following error {e}") 
        raise e

def update_insert_account(target_schema_table, target_table_name, staging_schema_table,staging_table_name):
    try:
        update_query = f"""UPDATE {target_schema_table}
        SET
        IsDeleted = {staging_table_name}.IsDeleted,
        MasterRecordId = {staging_table_name}.MasterRecordId,
        Name = {staging_table_name}.Name,
        Type = {staging_table_name}.Type,
        RecordTypeId = {staging_table_name}.RecordTypeId,
        ParentId = {staging_table_name}.ParentId,
        BillingStreet = {staging_table_name}.BillingStreet,
        BillingCity = {staging_table_name}.BillingCity,
        BillingState = {staging_table_name}.BillingState,
        BillingPostalCode = {staging_table_name}.BillingPostalCode,
        BillingCountry = {staging_table_name}.BillingCountry,
        BillingLatitude = {staging_table_name}.BillingLatitude,
        BillingLongitude = {staging_table_name}.BillingLongitude,
        BillingGeocodeAccuracy = {staging_table_name}.BillingGeocodeAccuracy,
        BillingAddress = {staging_table_name}.BillingAddress,
        ShippingStreet = {staging_table_name}.ShippingStreet,
        ShippingCity = {staging_table_name}.ShippingCity,
        ShippingState = {staging_table_name}.ShippingState,
        ShippingPostalCode = {staging_table_name}.ShippingPostalCode,
        ShippingCountry = {staging_table_name}.ShippingCountry,
        ShippingLatitude = {staging_table_name}.ShippingLatitude,
        ShippingLongitude = {staging_table_name}.ShippingLongitude,
        ShippingGeocodeAccuracy = {staging_table_name}.ShippingGeocodeAccuracy,
        ShippingAddress = {staging_table_name}.ShippingAddress,
        Phone = {staging_table_name}.Phone,
        Fax = {staging_table_name}.Fax,
        AccountNumber = {staging_table_name}.AccountNumber,
        Website = {staging_table_name}.Website,
        PhotoUrl = {staging_table_name}.PhotoUrl,
        Sic = {staging_table_name}.Sic,
        Industry = {staging_table_name}.Industry,
        AnnualRevenue = {staging_table_name}.AnnualRevenue,
        NumberOfEmployees = {staging_table_name}.NumberOfEmployees,
        Ownership = {staging_table_name}.Ownership,
        TickerSymbol = {staging_table_name}.TickerSymbol,
        Description = {staging_table_name}.Description,
        Rating = {staging_table_name}.Rating,
        Site = {staging_table_name}.Site,
        OwnerId = {staging_table_name}.OwnerId,
        CreatedDate = {staging_table_name}.CreatedDate,
        CreatedById = {staging_table_name}.CreatedById,
        LastModifiedDate = {staging_table_name}.LastModifiedDate,
        LastModifiedById = {staging_table_name}.LastModifiedById,
        SystemModstamp = {staging_table_name}.SystemModstamp,
        LastActivityDate = {staging_table_name}.LastActivityDate,
        LastViewedDate = {staging_table_name}.LastViewedDate,
        LastReferencedDate = {staging_table_name}.LastReferencedDate,
        Jigsaw = {staging_table_name}.Jigsaw,
        JigsawCompanyId = {staging_table_name}.JigsawCompanyId,
        AccountSource = {staging_table_name}.AccountSource,
        SicDesc = {staging_table_name}.SicDesc,
        vlocity_cmt__AccountPaymentType__c = {staging_table_name}.vlocity_cmt__AccountPaymentType__c,
        vlocity_cmt__Active__c = {staging_table_name}.vlocity_cmt__Active__c,
        vlocity_cmt__AutoPaymentAmount__c = {staging_table_name}.vlocity_cmt__AutoPaymentAmount__c,
        vlocity_cmt__AutoPaymentCardType__c = {staging_table_name}.vlocity_cmt__AutoPaymentCardType__c,
        vlocity_cmt__AutoPaymentLimitAmount__c = {staging_table_name}.vlocity_cmt__AutoPaymentLimitAmount__c,
        vlocity_cmt__AutoPaymentMethodId__c = {staging_table_name}.vlocity_cmt__AutoPaymentMethodId__c,
        vlocity_cmt__BillCycle__c = {staging_table_name}.vlocity_cmt__BillCycle__c,
        vlocity_cmt__BillDeliveryMethod__c = {staging_table_name}.vlocity_cmt__BillDeliveryMethod__c,
        vlocity_cmt__BillFormat__c = {staging_table_name}.vlocity_cmt__BillFormat__c,
        vlocity_cmt__BillFrequency__c = {staging_table_name}.vlocity_cmt__BillFrequency__c,
        vlocity_cmt__BillNumberOfCopies__c = {staging_table_name}.vlocity_cmt__BillNumberOfCopies__c,
        vlocity_cmt__BillingEmailAddress__c = {staging_table_name}.vlocity_cmt__BillingEmailAddress__c,
        vlocity_cmt__CLTV__c = {staging_table_name}.vlocity_cmt__CLTV__c,
        vlocity_cmt__CalculatedAddress__c = {staging_table_name}.vlocity_cmt__CalculatedAddress__c,
        vlocity_cmt__Churn__c = {staging_table_name}.vlocity_cmt__Churn__c,
        vlocity_cmt__ContactPreferences__c = {staging_table_name}.vlocity_cmt__ContactPreferences__c,
        vlocity_cmt__CreditRating__c = {staging_table_name}.vlocity_cmt__CreditRating__c,
        vlocity_cmt__CreditScore__c = {staging_table_name}.vlocity_cmt__CreditScore__c,
        vlocity_cmt__CustomerClass__c = {staging_table_name}.vlocity_cmt__CustomerClass__c,
        vlocity_cmt__CustomerOfBrand__c = {staging_table_name}.vlocity_cmt__CustomerOfBrand__c,
        vlocity_cmt__CustomerValue__c = {staging_table_name}.vlocity_cmt__CustomerValue__c,
        vlocity_cmt__DateFounded__c = {staging_table_name}.vlocity_cmt__DateFounded__c,
        vlocity_cmt__DirectoryListed__c = {staging_table_name}.vlocity_cmt__DirectoryListed__c,
        vlocity_cmt__Disclosure1__c = {staging_table_name}.vlocity_cmt__Disclosure1__c,
        vlocity_cmt__Disclosure2__c = {staging_table_name}.vlocity_cmt__Disclosure2__c,
        vlocity_cmt__Disclosure3__c = {staging_table_name}.vlocity_cmt__Disclosure3__c,
        vlocity_cmt__EnableAutopay__c = {staging_table_name}.vlocity_cmt__EnableAutopay__c,
        vlocity_cmt__IsPersonAccount__c = {staging_table_name}.vlocity_cmt__IsPersonAccount__c,
        vlocity_cmt__IsRootResolved__c = {staging_table_name}.vlocity_cmt__IsRootResolved__c,
        vlocity_cmt__Juridsiction1__c = {staging_table_name}.vlocity_cmt__Juridsiction1__c,
        vlocity_cmt__Jurisdiction2__c = {staging_table_name}.vlocity_cmt__Jurisdiction2__c,
        vlocity_cmt__LegalForm__c = {staging_table_name}.vlocity_cmt__LegalForm__c,
        vlocity_cmt__NetWorth__c = {staging_table_name}.vlocity_cmt__NetWorth__c,
        vlocity_cmt__NumberofLocations__c = {staging_table_name}.vlocity_cmt__NumberofLocations__c,
        vlocity_cmt__PartyId__c = {staging_table_name}.vlocity_cmt__PartyId__c,
        vlocity_cmt__PersonContactId__c = {staging_table_name}.vlocity_cmt__PersonContactId__c,
        vlocity_cmt__PreferredLanguage__c = {staging_table_name}.vlocity_cmt__PreferredLanguage__c,
        vlocity_cmt__PremisesId__c = {staging_table_name}.vlocity_cmt__PremisesId__c,
        vlocity_cmt__PrepayReloadThreshold__c = {staging_table_name}.vlocity_cmt__PrepayReloadThreshold__c,
        vlocity_cmt__PrimaryContactId__c = {staging_table_name}.vlocity_cmt__PrimaryContactId__c,
        vlocity_cmt__RootAccountId__c = {staging_table_name}.vlocity_cmt__RootAccountId__c,
        vlocity_cmt__SLA__c = {staging_table_name}.vlocity_cmt__SLA__c,
        vlocity_cmt__Status__c = {staging_table_name}.vlocity_cmt__Status__c,
        vlocity_cmt__TaxExemptionEndDate__c = {staging_table_name}.vlocity_cmt__TaxExemptionEndDate__c,
        vlocity_cmt__TaxExemptionPercentage__c = {staging_table_name}.vlocity_cmt__TaxExemptionPercentage__c,
        vlocity_cmt__TaxExemptionStartDate__c = {staging_table_name}.vlocity_cmt__TaxExemptionStartDate__c,
        vlocity_cmt__TaxExemptionType__c = {staging_table_name}.vlocity_cmt__TaxExemptionType__c,
        vlocity_cmt__TaxID__c = {staging_table_name}.vlocity_cmt__TaxID__c,
        vlocity_cmt__vCustomerPriority__c = {staging_table_name}.vlocity_cmt__vCustomerPriority__c,
        vlocity_cmt__vSLAExpirationDate__c = {staging_table_name}.vlocity_cmt__vSLAExpirationDate__c,
        vlocity_cmt__vSLASerialNumber__c = {staging_table_name}.vlocity_cmt__vSLASerialNumber__c,
        vlocity_cmt__vSLA__c = {staging_table_name}.vlocity_cmt__vSLA__c,
        vlocity_cmt__BillingAccountStatus__c = {staging_table_name}.vlocity_cmt__BillingAccountStatus__c,
        vlocity_cmt__FraudReason__c = {staging_table_name}.vlocity_cmt__FraudReason__c,
        vlocity_cmt__HasFraud__c = {staging_table_name}.vlocity_cmt__HasFraud__c,
        AccountCounter__c = {staging_table_name}.AccountCounter__c,
        Account_ID18__c = {staging_table_name}.Account_ID18__c,
        Accounting_ID__c = {staging_table_name}.Accounting_ID__c,
        Associated__c = {staging_table_name}.Associated__c,
        Auto_Approve__c = {staging_table_name}.Auto_Approve__c,
        Billing_AccountId__c = {staging_table_name}.Billing_AccountId__c,
        Billing_AccountName__c = {staging_table_name}.Billing_AccountName__c,
        Billing_BillingStatus__c = {staging_table_name}.Billing_BillingStatus__c,
        Billing_BillingSystem__c = {staging_table_name}.Billing_BillingSystem__c,
        Billing__c = {staging_table_name}.Billing__c,
        BrokerId18__c = {staging_table_name}.BrokerId18__c,
        BrokerName__c = {staging_table_name}.BrokerName__c,
        BrokerStatus__c = {staging_table_name}.BrokerStatus__c,
        Broker_AgreementEffectiveDate__c = {staging_table_name}.Broker_AgreementEffectiveDate__c,
        Broker_Integration_Id__c = {staging_table_name}.Broker_Integration_Id__c,
        Broker_MobilePhone__c = {staging_table_name}.Broker_MobilePhone__c,
        BusinessPhone__c = {staging_table_name}.BusinessPhone__c,
        CESReady__c = {staging_table_name}.CESReady__c,
        CSP_Status__c = {staging_table_name}.CSP_Status__c,
        Co_Owner1__c = {staging_table_name}.Co_Owner1__c,
        Co_Owner2__c = {staging_table_name}.Co_Owner2__c,
        ContactName__c = {staging_table_name}.ContactName__c,
        CurrentCreditRequest__c = {staging_table_name}.CurrentCreditRequest__c,
        Current_Associated_Contract__c = {staging_table_name}.Current_Associated_Contract__c,
        CustomerPriority__c = {staging_table_name}.CustomerPriority__c,
        DUNS__c = {staging_table_name}.DUNS__c,
        Email__c = {staging_table_name}.Email__c,
        Enrich_Error_Message__c = {staging_table_name}.Enrich_Error_Message__c,
        Enrich_UAN_Status__c = {staging_table_name}.Enrich_UAN_Status__c,
        Entity_ID__c = {staging_table_name}.Entity_ID__c,
        Entity_Name__c = {staging_table_name}.Entity_Name__c,
        Estimated_End_Date__c = {staging_table_name}.Estimated_End_Date__c,
        Estimated_Monthly_Usage_kWh__c = {staging_table_name}.Estimated_Monthly_Usage_kWh__c,
        Estimated_Start_Date__c = {staging_table_name}.Estimated_Start_Date__c,
        FaxPhone__c = {staging_table_name}.FaxPhone__c,
        GForseva_City__c = {staging_table_name}.GForseva_City__c,
        GForseva_Country__c = {staging_table_name}.GForseva_Country__c,
        GForseva_Postal_Code__c = {staging_table_name}.GForseva_Postal_Code__c,
        GForseva_State__c = {staging_table_name}.GForseva_State__c,
        GForseva_Street__c = {staging_table_name}.GForseva_Street__c,
        HU_Requested_Timestamp__c = {staging_table_name}.HU_Requested_Timestamp__c,
        Inactive__c = {staging_table_name}.Inactive__c,
        Installer_PPSAgent__c = {staging_table_name}.Installer_PPSAgent__c,
        Installer_Status__c = {staging_table_name}.Installer_Status__c,
        Installer_VendorID__c = {staging_table_name}.Installer_VendorID__c,
        Is_Minimum_Stay__c = {staging_table_name}.Is_Minimum_Stay__c,
        LPC_Percent_Charge__c = {staging_table_name}.LPC_Percent_Charge__c,
        LastLENChangeDate__c = {staging_table_name}.LastLENChangeDate__c,
        Last_Enrich_Date__c = {staging_table_name}.Last_Enrich_Date__c,
        LeadSource__c = {staging_table_name}.LeadSource__c,
        LegacyAccountID__c = {staging_table_name}.LegacyAccountID__c,
        Legacy_Id__c = {staging_table_name}.Legacy_Id__c,
        LegalEntityName__c = {staging_table_name}.LegalEntityName__c,
        MainCity__c = {staging_table_name}.MainCity__c,
        MainCountry__c = {staging_table_name}.MainCountry__c,
        MainState__c = {staging_table_name}.MainState__c,
        MainStreet__c = {staging_table_name}.MainStreet__c,
        MainZipCode__c = {staging_table_name}.MainZipCode__c,
        Main_State__c = {staging_table_name}.Main_State__c,
        Meter_Tampering__c = {staging_table_name}.Meter_Tampering__c,
        NITS__c = {staging_table_name}.NITS__c,
        NameExternalId__c = {staging_table_name}.NameExternalId__c,
        Notes__c = {staging_table_name}.Notes__c,
        NumberofLocations__c = {staging_table_name}.NumberofLocations__c,
        Off_Peak__c = {staging_table_name}.Off_Peak__c,
        On_Peak__c = {staging_table_name}.On_Peak__c,
        Open_Service_Orders__c = {staging_table_name}.Open_Service_Orders__c,
        PPL_ER_Enrollment_Number_ID__c = {staging_table_name}.PPL_ER_Enrollment_Number_ID__c,
        PhoneExt__c = {staging_table_name}.PhoneExt__c,
        PrepaidPercentage__c = {staging_table_name}.PrepaidPercentage__c,
        Prepay__c = {staging_table_name}.Prepay__c,
        PreviouslyKnownLegalEntityName__c = {staging_table_name}.PreviouslyKnownLegalEntityName__c,
        Request_ICAP__c = {staging_table_name}.Request_ICAP__c,
        Request_Rate_Class__c = {staging_table_name}.Request_Rate_Class__c,
        SLAExpirationDate__c = {staging_table_name}.SLAExpirationDate__c,
        SLASerialNumber__c = {staging_table_name}.SLASerialNumber__c,
        SLA__c = {staging_table_name}.SLA__c,
        ServiceCity__c = {staging_table_name}.ServiceCity__c,
        ServiceCountry__c = {staging_table_name}.ServiceCountry__c,
        ServiceStreet__c = {staging_table_name}.ServiceStreet__c,
        ServiceZipCode__c = {staging_table_name}.ServiceZipCode__c,
        Service_Account_Unique_ID__c = {staging_table_name}.Service_Account_Unique_ID__c,
        Service_Annual_Consumption__c = {staging_table_name}.Service_Annual_Consumption__c,
        Service_AssumedMeterType__c = {staging_table_name}.Service_AssumedMeterType__c,
        Service_Avg_Usage__c = {staging_table_name}.Service_Avg_Usage__c,
        Service_BillingAccount__c = {staging_table_name}.Service_BillingAccount__c,
        Service_Billing_City__c = {staging_table_name}.Service_Billing_City__c,
        Service_Billing_Country__c = {staging_table_name}.Service_Billing_Country__c,
        Service_Billing_State__c = {staging_table_name}.Service_Billing_State__c,
        Service_Billing_Street__c = {staging_table_name}.Service_Billing_Street__c,
        Service_Billing_ZipCode__c = {staging_table_name}.Service_Billing_ZipCode__c,
        Service_CAP_PLC__c = {staging_table_name}.Service_CAP_PLC__c,
        Service_CESUniqueAccountId__c = {staging_table_name}.Service_CESUniqueAccountId__c,
        Service_CSP__c = {staging_table_name}.Service_CSP__c,
        Service_CapTagMaxEffectiveDate__c = {staging_table_name}.Service_CapTagMaxEffectiveDate__c,
        Service_CapTagStatus__c = {staging_table_name}.Service_CapTagStatus__c,
        Service_Capacity__c = {staging_table_name}.Service_Capacity__c,
        Service_ContractSegment__c = {staging_table_name}.Service_ContractSegment__c,
        Service_CostingValidationStatus__c = {staging_table_name}.Service_CostingValidationStatus__c,
        Service_County__c = {staging_table_name}.Service_County__c,
        Service_CurrentReading__c = {staging_table_name}.Service_CurrentReading__c,
        Service_CustomerClass__c = {staging_table_name}.Service_CustomerClass__c,
        Service_DUNSGROUP__c = {staging_table_name}.Service_DUNSGROUP__c,
        Service_DUNSNumber__c = {staging_table_name}.Service_DUNSNumber__c,
        Service_DropDate__c = {staging_table_name}.Service_DropDate__c,
        Service_EstimatedEndDate__c = {staging_table_name}.Service_EstimatedEndDate__c,
        Service_EstimatedEndDatebatchupdate__c = {staging_table_name}.Service_EstimatedEndDatebatchupdate__c,
        Service_EstimatedMonthlyUsage__c = {staging_table_name}.Service_EstimatedMonthlyUsage__c,
        Service_ForecastedEstimatedMonthlyUsage__c = {staging_table_name}.Service_ForecastedEstimatedMonthlyUsage__c,
        Service_GRTTax_Exemption__c = {staging_table_name}.Service_GRTTax_Exemption__c,
        Service_HIStatus__c = {staging_table_name}.Service_HIStatus__c,
        Service_HURNotes__c = {staging_table_name}.Service_HURNotes__c,
        Service_HURReceivedTimestamp__c = {staging_table_name}.Service_HURReceivedTimestamp__c,
        Service_HURStatus__c = {staging_table_name}.Service_HURStatus__c,
        Service_HUStatus__c = {staging_table_name}.Service_HUStatus__c,
        Service_KW__c = {staging_table_name}.Service_KW__c,
        Service_LastEnrichDate__c = {staging_table_name}.Service_LastEnrichDate__c,
        Service_LifeSupportEquipment__c = {staging_table_name}.Service_LifeSupportEquipment__c,
        Service_LoadProfile__c = {staging_table_name}.Service_LoadProfile__c,
        Service_LocationName__c = {staging_table_name}.Service_LocationName__c,
        Service_Marketer__c = {staging_table_name}.Service_Marketer__c,
        Service_Matrix_Bill_Date__c = {staging_table_name}.Service_Matrix_Bill_Date__c,
        Service_Matrix_Capacity__c = {staging_table_name}.Service_Matrix_Capacity__c,
        Service_Matrix_Meter_Read_End__c = {staging_table_name}.Service_Matrix_Meter_Read_End__c,
        Service_Matrix_Meter_Read_Start__c = {staging_table_name}.Service_Matrix_Meter_Read_Start__c,
        Service_Matrix_Monthly_Usage__c = {staging_table_name}.Service_Matrix_Monthly_Usage__c,
        Service_Matrix_NITS__c = {staging_table_name}.Service_Matrix_NITS__c,
        Service_Max_Usage__c = {staging_table_name}.Service_Max_Usage__c,
        Service_MemberID__c = {staging_table_name}.Service_MemberID__c,
        Service_MeterReadCycle__c = {staging_table_name}.Service_MeterReadCycle__c,
        Service_MeterType__c = {staging_table_name}.Service_MeterType__c,
        Service_MeterTypeforMatrix__c = {staging_table_name}.Service_MeterTypeforMatrix__c,
        Service_Metered__c = {staging_table_name}.Service_Metered__c,
        Service_NITSMaxEffectiveDate__c = {staging_table_name}.Service_NITSMaxEffectiveDate__c,
        Service_NITSStatus__c = {staging_table_name}.Service_NITSStatus__c,
        Service_NITSTagStatus__c = {staging_table_name}.Service_NITSTagStatus__c,
        Service_NITS_PLC__c = {staging_table_name}.Service_NITS_PLC__c,
        Service_OfferCode__c = {staging_table_name}.Service_OfferCode__c,
        Service_OnFlowDate__c = {staging_table_name}.Service_OnFlowDate__c,
        Service_OnFlowDatebatchupdatePremiseinfo__c = {staging_table_name}.Service_OnFlowDatebatchupdatePremiseinfo__c,
        Service_OptyIDUanNumberUnique__c = {staging_table_name}.Service_OptyIDUanNumberUnique__c,
        Service_OptyStartDate__c = {staging_table_name}.Service_OptyStartDate__c,
        Service_PMVISelfSelectedFeeApproval__c = {staging_table_name}.Service_PMVISelfSelectedFeeApproval__c,
        Service_PORUtility__c = {staging_table_name}.Service_PORUtility__c,
        Service_POR_Loss__c = {staging_table_name}.Service_POR_Loss__c,
        Service_PowerRegion__c = {staging_table_name}.Service_PowerRegion__c,
        Service_PremiseType__c = {staging_table_name}.Service_PremiseType__c,
        Service_RequireUDCCode__c = {staging_table_name}.Service_RequireUDCCode__c,
        Service_RoundtheClock__c = {staging_table_name}.Service_RoundtheClock__c,
        Service_SalesTaxExemption__c = {staging_table_name}.Service_SalesTaxExemption__c,
        Service_SpecialBilling__c = {staging_table_name}.Service_SpecialBilling__c,
        Service_StationCode__c = {staging_table_name}.Service_StationCode__c,
        Service_StationName__c = {staging_table_name}.Service_StationName__c,
        Service_Status__c = {staging_table_name}.Service_Status__c,
        Service_TimeStampforUtilityAccount__c = {staging_table_name}.Service_TimeStampforUtilityAccount__c,
        Service_Type2__c = {staging_table_name}.Service_Type2__c,
        Service_Type_2__c = {staging_table_name}.Service_Type_2__c,
        Service_UDCCode__c = {staging_table_name}.Service_UDCCode__c,
        Service_UsageReceivedTimestamp__c = {staging_table_name}.Service_UsageReceivedTimestamp__c,
        Service_UsageRequestStatus__c = {staging_table_name}.Service_UsageRequestStatus__c,
        Service_UsageRequestedBy__c = {staging_table_name}.Service_UsageRequestedBy__c,
        Service_UsageRequestedTimestamp__c = {staging_table_name}.Service_UsageRequestedTimestamp__c,
        Service_UtilityAccountNumber__c = {staging_table_name}.Service_UtilityAccountNumber__c,
        Service_Utility__c = {staging_table_name}.Service_Utility__c,
        Special_Handling__c = {staging_table_name}.Special_Handling__c,
        TRMProcess__c = {staging_table_name}.TRMProcess__c,
        TX_Public_Utility_Assessment_Exemption__c = {staging_table_name}.TX_Public_Utility_Assessment_Exemption__c,
        TaxIDNumber__c = {staging_table_name}.TaxIDNumber__c,
        Tax_Exemption_Certificate__c = {staging_table_name}.Tax_Exemption_Certificate__c,
        Tax_Exemption_City_Local_Percent__c = {staging_table_name}.Tax_Exemption_City_Local_Percent__c,
        Tax_Exemption_City_Percent__c = {staging_table_name}.Tax_Exemption_City_Percent__c,
        Tax_Exemption_County_Local_Percent__c = {staging_table_name}.Tax_Exemption_County_Local_Percent__c,
        Tax_Exemption_County_Percent__c = {staging_table_name}.Tax_Exemption_County_Percent__c,
        Tax_Exemption_State_Percent__c = {staging_table_name}.Tax_Exemption_State_Percent__c,
        TerminationLetterSent__c = {staging_table_name}.TerminationLetterSent__c,
        Tier__c = {staging_table_name}.Tier__c,
        UpsellOpportunity__c = {staging_table_name}.UpsellOpportunity__c,
        Utility_CESReady__c = {staging_table_name}.Utility_CESReady__c,
        Utility_DEMANDAT1500__c = {staging_table_name}.Utility_DEMANDAT1500__c,
        Utility_DEMANDAT2500__c = {staging_table_name}.Utility_DEMANDAT2500__c,
        Utility_DEMANDAT3500__c = {staging_table_name}.Utility_DEMANDAT3500__c,
        Utility_GEXABASECHARGE__c = {staging_table_name}.Utility_GEXABASECHARGE__c,
        Utility_HUNameKeyRequired__c = {staging_table_name}.Utility_HUNameKeyRequired__c,
        Utility_HUResponseTime__c = {staging_table_name}.Utility_HUResponseTime__c,
        Utility_IDRResponseTime__c = {staging_table_name}.Utility_IDRResponseTime__c,
        Utility_LDCCode__c = {staging_table_name}.Utility_LDCCode__c,
        Utility_LDCName__c = {staging_table_name}.Utility_LDCName__c,
        Utility_Market__c = {staging_table_name}.Utility_Market__c,
        Utility_MaxPricingDate__c = {staging_table_name}.Utility_MaxPricingDate__c,
        Utility_NeedICAP__c = {staging_table_name}.Utility_NeedICAP__c,
        Utility_NeedRateClasses__c = {staging_table_name}.Utility_NeedRateClasses__c,
        Utility_NeedUDCCode__c = {staging_table_name}.Utility_NeedUDCCode__c,
        Utility_Offcycle__c = {staging_table_name}.Utility_Offcycle__c,
        Utility_PORPolicyinPlace__c = {staging_table_name}.Utility_PORPolicyinPlace__c,
        Utility_PORUtilityRateClass__c = {staging_table_name}.Utility_PORUtilityRateClass__c,
        Utility_PORbyRateClass__c = {staging_table_name}.Utility_PORbyRateClass__c,
        Utility_ReceiverDUNS__c = {staging_table_name}.Utility_ReceiverDUNS__c,
        Utility_SenderDUNS__c = {staging_table_name}.Utility_SenderDUNS__c,
        Utility_State__c = {staging_table_name}.Utility_State__c,
        Utility_SupplierAccountNumber__c = {staging_table_name}.Utility_SupplierAccountNumber__c,
        Utility_TDSP_DEMANDAT1500__c = {staging_table_name}.Utility_TDSP_DEMANDAT1500__c,
        Utility_TDSP_DEMANDAT2500__c = {staging_table_name}.Utility_TDSP_DEMANDAT2500__c,
        Utility_TDSP_DEMANDAT3500__c = {staging_table_name}.Utility_TDSP_DEMANDAT3500__c,
        Utility_TDSP_KWHAT1500__c = {staging_table_name}.Utility_TDSP_KWHAT1500__c,
        Utility_TDSP_KWHAT2500__c = {staging_table_name}.Utility_TDSP_KWHAT2500__c,
        Utility_TDSP_KWHAT3500__c = {staging_table_name}.Utility_TDSP_KWHAT3500__c,
        Utility_TDSP_MONTHLYAT1500__c = {staging_table_name}.Utility_TDSP_MONTHLYAT1500__c,
        Utility_TDSP_MONTHLYAT2500__c = {staging_table_name}.Utility_TDSP_MONTHLYAT2500__c,
        Utility_TDSP_MONTHLYAT3500__c = {staging_table_name}.Utility_TDSP_MONTHLYAT3500__c,
        Utility_UANLength__c = {staging_table_name}.Utility_UANLength__c,
        Utility_UANPrefix__c = {staging_table_name}.Utility_UANPrefix__c,
        UtiltiyAccountId18__c = {staging_table_name}.UtiltiyAccountId18__c,
        Zone__c = {staging_table_name}.Zone__c,
        OpportunityCount__c = {staging_table_name}.OpportunityCount__c,
        Billing_BillOption__c = {staging_table_name}.Billing_BillOption__c,
        CompanyName__c = {staging_table_name}.CompanyName__c,
        NY_Tax_applied__c = {staging_table_name}.NY_Tax_applied__c,
        ServiceState__c = {staging_table_name}.ServiceState__c,
        ServiceTypeCode__c = {staging_table_name}.ServiceTypeCode__c,
        Service_ISO__c = {staging_table_name}.Service_ISO__c,
        Service_Material__c = {staging_table_name}.Service_Material__c,
        Service_Matrix_Rate_Class__c = {staging_table_name}.Service_Matrix_Rate_Class__c,
        Service_Max_Pricing_Date__c = {staging_table_name}.Service_Max_Pricing_Date__c,
        Service_RateClass__c = {staging_table_name}.Service_RateClass__c,
        Service_ServiceType__c = {staging_table_name}.Service_ServiceType__c,
        Service_Type_Code__c = {staging_table_name}.Service_Type_Code__c,
        Service_Zone__c = {staging_table_name}.Service_Zone__c,
        Utility_Picklist__c = {staging_table_name}.Utility_Picklist__c,
        Utility_Receiver_Duns__c = {staging_table_name}.Utility_Receiver_Duns__c,
        uantest__c = {staging_table_name}.uantest__c,
        Project__c = {staging_table_name}.Project__c,
        Resource_Type__c = {staging_table_name}.Resource_Type__c,
        Utility_CES_Utility_Code__c  = {staging_table_name}.Utility_CES_Utility_Code__c ,
        batch_id = {staging_table_name}.batch_id
        ,source_system = {staging_table_name}.source_system
        ,created_by = {staging_table_name}.created_by
        ,created_dttm = {staging_table_name}.created_dttm
        ,modified_by = {staging_table_name}.modified_by
        ,modified_dttm = {staging_table_name}.modified_dttm
        FROM vendor_customer_opportunities_staging.{staging_table_name}
        WHERE sfdc_gexa_account_raw.Id = {staging_table_name}.Id"""
        cloudwatch.log_to_stream(f"Successfully updated records")
        insert_query = f"""INSERT INTO {target_schema_table}
        SELECT {staging_table_name}.*
        FROM {staging_schema_table}
        LEFT JOIN {target_schema_table}
        ON {staging_table_name}.id= sfdc_gexa_account_raw.id
        WHERE sfdc_gexa_account_raw.id IS NULL"""
        cloudwatch.log_to_stream(f"Successfully inserted records")
        return update_query, insert_query 
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in update_insert_account function with following error {e}")
    

def write_csv(df,BUCKET, s3_client,staging_path,job_name):
    try:
        csv_string_object = StringIO()
        df.to_csv(csv_string_object, index=False, header=True)
        csv_bytes = csv_string_object.getvalue().encode('utf-8')
        csv_file_name = staging_path + job_name +'.csv'
        s3_client.put_object(Bucket=BUCKET,Key=csv_file_name,Body=csv_bytes)
    except Exception as e:
        cloudwatch.log_to_stream(f"Job failed in write_csv function with following error : {e}")

batch_id    = timestamp_generator("%Y%m%d%H%M%S%f")[:-3] 
#batch_start_dttm    = timestamp_generator("%Y%m%d%H%M%S%f")[:-3] 
#job_start_dttm = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
etl_batch_id = f"{job_name}_" + timestamp_generator("%Y%m%d%H%M%S")
cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")

try:
    
    created_dttm        = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3] 
    job_start_dttm      = created_dttm
    batch_start_dttm    = created_dttm
    batch_init_status   = "Batch Successful"
    
    _secret = get_secret(rs_secret, region_name,cloudwatch)
    sql_stmt = get_sql_stmt(job_name,audit_schema,audit_table, batch_init_status)
    cloudwatch.log_to_stream(f'sql statement : {sql_stmt}')
    
    rs_conn = get_redshift_conn(_secret, region_name)
    cloudwatch.log_to_stream(f' after getting RS connection ')
    
    cursor = rs_conn.cursor() 
    cursor.execute(sql_stmt) 
    results = cursor.fetchall()
    last_load_dttm=results[0][0].strftime('%Y/%m/%d %H:%M:%S')
    #last_load_dttm=results[0][0].strftime('%Y-%m-%d %H:%M:%S:%f')
    cloudwatch.log_to_stream(f'last load date and time : {last_load_dttm}')
    
    
    #cursor.close()
    #rs_conn.commit()
    #rs_conn.close()
    cloudwatch.log_to_stream(f'after closing the connection')

    
    #### SF api data job calling #####
    
    cloudwatch.log_to_stream(f"sub job name {api_sub_job_name}")
    job_args = {
    '--batch_id': batch_id,
    '--sf_secret': sf_secret,
    '--job_name':job_name,
    '--landing_zone':landing_zone,
    #'--csv_path': final_csv_path,
    '--load_type': load_type,
    '--environment':environment,
    '--region_name':region_name,
    '--last_load_dttm':str(last_load_dttm),
    '--soql_query':soql_query,
    '--s3_bucket':s3_bucket,
    '--records_fetched_count_path':records_fetched_count_path
   }   

    sub_job_response = glue.start_job_run(JobName=api_sub_job_name, Arguments=job_args)
    runid = sub_job_response['JobRunId']
    
    
    cloudwatch.log_to_stream(f"sub jobs run id  --- {runid}")
    
    for key in runid:
            while True:
                status = glue.get_job_run(JobName=api_sub_job_name, RunId=runid)['JobRun']['JobRunState']
                cloudwatch.log_to_stream(f'The {api_sub_job_name} job is: {status}')
                if status == 'SUCCEEDED':
                    break
                elif status == 'FAILED':
                    sys.exit(f"sub job {key} failed")
                time.sleep(60) 
    cloudwatch.log_to_stream(f" api_sub_job_name {api_sub_job_name}")
    
    
    ######### raw-json file csv conversion ###################
    
    data_wrtitten_check = list_s3_files(s3_client,s3_bucket,landing_zone)
    cloudwatch.log_to_stream(f" data_wrtitten_check {data_wrtitten_check}")
    
    if len(data_wrtitten_check)!=0:
        csv_path = landing_zone.replace('json', 'csv/')
        modified_dttm = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        cloudwatch.log_to_stream(f" csv_path {csv_path}")
            
        json_filenames = list_s3_files(s3_client,s3_bucket,landing_zone)
        json_data_list = []
        
        cloudwatch.log_to_stream(f" json_filenames {json_filenames}")
        
        cloudwatch.log_to_stream(f" json_data_list {json_data_list}")
        for file in json_filenames:
            csv_file_name = file.split('/')[-1].replace('.json','')
            cloudwatch.log_to_stream(f" csv_file_name {csv_file_name}")
            json_data_list = read_json_df(s3_bucket,s3_client,file)
            cloudwatch.log_to_stream(f" json_filenames1 {json_filenames}")
            df = pd.DataFrame(json_data_list)
            #print(df.to_string(max_rows=10)) 
            if len(df) != 0:
            
                df = transform_gexa_raw_base_account(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                write_csv(df,s3_bucket,s3_client,csv_path,csv_file_name)
                cloudwatch.log_to_stream(f"json data written to csv")
               
        
            else:
                write_csv(df,s3_bucket,s3_client,csv_path,csv_file_name)
                cloudwatch.log_to_stream(f"empty json data written to csv")
    
    
    # Read records count path text file to read records fetch count
    result = s3_client.list_objects_v2(Bucket=s3_bucket, Prefix=records_fetched_count_path)
    
    records_fetched_file = ''
    for item in result['Contents']:
        records_fetched_file = item['Key']
        if file.endswith('.txt'):
            cloudwatch.log_to_stream(f"file: {records_fetched_file}")
    s3_response = s3_client.get_object( Bucket=s3_bucket,  Key=records_fetched_file  )
    
    # Get the Body object in the S3 get_object() response
    s3_object_body = s3_response.get('Body')
    
    # Read the data in bytes format
    content = s3_object_body.read()
    
    records_fetched = json.loads(content)
    cloudwatch.log_to_stream(f"records_fetched --{records_fetched}")
    
    ###### raw-base redshift #############
    
    staging_path            = s3_key + s3_bucket + '/'+ csv_path
    iam_role                = config.iam_role[environment]['copy_cmd_role']
    cloudwatch.log_to_stream(f' after getting RS connection ')
    #cursor = rs_conn.cursor() 
    
    staging_table_name = staging_schema_table.split('.')[1]
    target_table_name = target_schema_table.split('.')[1]
    update_query_tgt = ""
    insert_query_tgt = ""
    
    
    delete_query = f"""DELETE FROM {staging_schema_table}"""
    cloudwatch.log_to_stream(f"delete Statement  : {delete_query}")
    cursor.execute(delete_query) 
    
    cloudwatch.log_to_stream(f"delete staging_path  : {staging_path}")
    
    copy_query = f"""COPY {staging_schema_table} FROM '{staging_path}' iam_role '{iam_role}' FORMAT CSV delimiter ',' QUOTE '"' IGNOREHEADER 1"""
    cloudwatch.log_to_stream(f'copy_query Statement  : {copy_query}')
    cursor.execute(copy_query)
   
    
    staging_count_query = f"""(SELECT COUNT(*) FROM {staging_schema_table} custom)"""
    cursor.execute(staging_count_query)  
    staging_count = cursor.fetchone()[0]
    cloudwatch.log_to_stream(f"stage count --> {str(staging_count)}")
    
    update_query_tgt, insert_query_tgt  = update_insert_account(target_schema_table, target_table_name, staging_schema_table,staging_table_name)

     
    cursor.execute(update_query_tgt)  
    update_count = cursor.rowcount
    cloudwatch.log_to_stream(f"update query executed successfully \n update count --> {str(update_count)}")
   
    cursor.execute(insert_query_tgt)
    insert_count = cursor.rowcount
    cloudwatch.log_to_stream(f"insert query executed successfully \n insert count --> {str(insert_count)}")
    
    ############ Audit insert ###############
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    last_load_dttm=results[0][0].strftime('%Y-%m-%d %H:%M:%S:%f')
    insert_stmt = f""" INSERT INTO {audit_schema}.{audit_table}(batch_id, batch_start_dttm, batch_status, load_type, last_load_dttm,    project_name, source_system, stage_name, job_name, job_start_dttm, target_table_name, landing_zone,records_fetched, created_dttm,job_end_dttm )    VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), '{batch_status}','{load_type}',to_timestamp('{last_load_dttm}', \'YYYY-MM-DD HH24:MI:SS\'),'{project_name}', '{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), '{target_table_name}','{landing_zone}','{records_fetched}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'))"""
    cloudwatch.log_to_stream(f"insert_stmt completed : {insert_stmt}")
    cursor.execute(insert_stmt) 
    
    cloudwatch.log_to_stream(f"batch_id : {batch_id}")
    batch_status = ''
    error_msg =''
    
    batch_status = 'Batch Successful'
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3] 
    batch_end_dttm= timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    cloudwatch.log_to_stream(' update batch status executed successfully ')
    update_btch_status1 = f"update {audit_schema}.{audit_table} set batch_status = '{batch_status}', batch_end_dttm =to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),job_end_dttm =to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), last_load_dttm =to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = '{batch_id}';"
    cloudwatch.log_to_stream(update_btch_status1)
    cursor.execute(update_btch_status1) 

    cursor.close()
    rs_conn.commit()
    cloudwatch.log_to_stream('after closing the connection ')
    # On successful export of data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
    cloudwatch.log_to_stream("Script executed successfully......  check data in redshift")
    cloudwatch.log_to_stream("Writing  data to redshift has been successfully done..")
except Exception as e:
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    batch_end_dttm= timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3] 
    update_audit_error = f"update {audit_schema}.{audit_table} set batch_status = 'Batch Failed', batch_end_dttm =to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), error_msg = '{error_message}',job_end_dttm =to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), last_load_dttm =to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = '{batch_id}';"
    rs_conn = get_redshift_conn(_secret, region_name)
    cloudwatch.log_to_stream(' after getting RS connection ')
    cursor = rs_conn.cursor()
    cloudwatch.log_to_stream(update_audit_error)
    cursor.execute(update_audit_error) 
    cursor.close()
    rs_conn.commit()
    rs_conn.close()
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    cloudwatch.log_to_stream(error_message)
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
    error_message = f"Job failed with following error: {str(e)}"
    cloudwatch.log_to_stream(error_message)
    raise e