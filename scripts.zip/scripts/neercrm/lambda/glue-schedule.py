import json, os
import boto3,sys 
from datetime import datetime, time
from boto3.dynamodb.conditions import Key 
from datetime import  timedelta

RoleArn = os.environ['role'] #arn:aws:iam::288355943657:role/2env-en411-edp-axis-service-role
Arn = os.environ['statemachine'] #'arn:aws:states:us-east-1:288355943657:stateMachine:2env-en411-edp-axis-neercrm-sf-data-process'
StatusTracker1 = os.environ['StatusTracker1'] #'2env-en411-edp-axis-step-func-status-tracker1'
StatusTracker = os.environ['StatusTracker'] #'2env-en411-edp-axis-step-func-status-tracker'
StatusCounter = os.environ['StatusCounter'] #'2env-en411-edp-axis-step-func-status-counter'


def read_json_df(BUCKET,s3_client,filename):
    
    # Get the file inside the S3 Bucket
    #for file in filenames:
    s3_response = s3_client.get_object(
        Bucket=BUCKET,
        Key=filename
    )
    
    # Get the Body object in the S3 get_object() response
    s3_object_body = s3_response.get('Body')
    
    # Read the data in bytes format
    content = s3_object_body.read()
    
    s3_json_data = json.loads(content)
    
    return s3_json_data


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e


def write_to_s3(data, buc_name, obj_name):
    s3_clt = boto3.resource('s3')
    s3obj = s3_clt.Object(buc_name, obj_name)
    s3obj.put( Body=bytes(json.dumps(data).encode('UTF-8')))
    return True        

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    s3_bucket =  os.environ['bucket'] #'2env-edp-platform-en411-s3'
    s3_key = 's3://'
    neercrm_scheduler_file = os.environ['schedule_file'] #'glue/scripts/axis/neercrm_glue_scheduler.json'
    job_name = ''
    
    ## Read json file for stepfunction names and input
    ##################################################
    
    sf_names_file_content = read_json_df(s3_bucket,s3_client,neercrm_scheduler_file)
    print("sf_names -- ",type(sf_names_file_content))
    SF_Scheduler_dict = sf_names_file_content["SF_scheduler"]
    target_sf= sf_names_file_content["SF_target"]
    print("SF_Scheduler_dict -- ",type(SF_Scheduler_dict))
    
    sorted_SF_Scheduler_dict = {key: SF_Scheduler_dict[key]  for key in sorted(SF_Scheduler_dict) if SF_Scheduler_dict[key]['status']==""}
    current_sf_scheduler_name = ""
    
    ### sort dynamo db to get latest jobname
    dynamodb = boto3.resource('dynamodb')
    table1 = dynamodb.Table(StatusTracker1)
    res = table1.scan()
    print("latest jobs batchid --", len(res['Items']))
    #print("sort the dynamodb --",res["Items"]) 
    response = table1.query(
        KeyConditionExpression=f"batch_id = :id",
        ExpressionAttributeValues={
            ":id": str(len(res['Items']))
        },
        ScanIndexForward=False,
    )
    job_name = response["Items"][0]["job_name"]
    print("JOB NAME from dynamoDB -- ",job_name)
    try:
       
        for key, value in sorted_SF_Scheduler_dict.items(): 
            if sorted_SF_Scheduler_dict[key]['name'] == job_name:
                current_sf_scheduler_name = sorted_SF_Scheduler_dict[key]['name']
                sorted_SF_Scheduler_dict[key]['status'] = "completed"
                SF_Scheduler_dict[key]['status'] = "completed"
        if current_sf_scheduler_name == "":
            sys.exit(" JOB_NAME from getlastloaddate lambda has not been updated into dynamodb table")
        ## for the last stepfunction to mark the overall status in dynamodb table2
        overall_status_dict = {key: sorted_SF_Scheduler_dict[key]  for key in sorted(sorted_SF_Scheduler_dict) if sorted_SF_Scheduler_dict[key]['status']==""}
        overall_status = ""
        
        if len(overall_status_dict) == 0:
            overall_status = "completed"
        else:
            overall_status = "Inprogress"
        
        print("current_sf_scheduler_name -- " + current_sf_scheduler_name)        
        print("sf cheduler post update --" , sorted_SF_Scheduler_dict.keys())
        
        
        
        ### DynamoDB get batch_id from table1 
        #####################################
        
        dynamodb = boto3.resource('dynamodb')
        table1 = dynamodb.Table(StatusCounter)
        
        
        resp = table1.scan(ProjectionExpression="batch_id")
        total_items_table1 = len(resp['Items'])
        print("table 1 -- ",resp['Items'])
        print("total_items_table1 -- ",total_items_table1) 
        if len(resp['Items']) == 0:
            table1.put_item (Item={'batch_id':1})
            resp = table1.scan(ProjectionExpression="batch_id")
            total_items_table1 = len(resp['Items'])
        dynamo_batchId =   table1.get_item(Key={ 'batch_id' : total_items_table1 })['Item']['batch_id']
        print("batchid from table1 --" ,dynamo_batchId)
       
        start_date_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #start_date_time = datetime.datetime.now().replace(microsecond=0)
        table1.put_item (
            Item={       
                'batch_id':total_items_table1+1 
                
            })
        resp = table1.scan(ProjectionExpression="batch_id")
        print("table1 after batchid incr -- ",resp['Items']) 
        
        
        ### Insert current stepfunction entry into DynamoDb table2
        ##################################################
        
        table2 = dynamodb.Table(StatusTracker)
        table2.put_item (
            Item={       
                'batch_id':dynamo_batchId+1 , 
                'stepFunction_status':{'name':current_sf_scheduler_name,'start_date':start_date_time  , 'end_date':start_date_time},
                'overall_status':overall_status
                
            })
        
        resp = table2.scan()        
        #print("tables 2 items -- " ,resp['Items'])
        
        if "system-users" not in job_name:
            ## Get the next stepfunction scheduler name
            flag = 0
            next_sf_scheduler_name = ""
            next_scheduler_input = ""
            
            for key, value in sorted_SF_Scheduler_dict.items(): 
                if flag == 0  and sorted_SF_Scheduler_dict[key]['status'] == "":
                    next_sf_scheduler_name = sorted_SF_Scheduler_dict[key]['name']
                    #next_scheduler_input = "'" + sorted_SF_Scheduler_dict[key]['input'].replace('"',"").replace("'",'"') + "'"
                    next_scheduler_input = json.dumps(sorted_SF_Scheduler_dict[key]['input']).replace('"',"").replace("'",'\"')
                    flag += 1
            print("next_sf_scheduler_name  -- " + next_sf_scheduler_name)            
            
            
            ## Create SF scheduler for the next stepfunction
            ###############################################
            sh_client = boto3.client('scheduler')
            current_hr = datetime.now().hour
            current_minute = datetime.now().minute + 2
            current_time_one_time_schedule = (datetime.now() + timedelta(minutes=3)).replace(microsecond=0).isoformat()
        
            response = sh_client.list_schedules(
            GroupName='default',
            NamePrefix= os.environ['Prefix'], #'2env-en411-edp-axis-neercrm-',
            #NextToken='string',
            State='ENABLED'
            )
            print("response list schedules -- ",response['Schedules'])
            schedules_list = [schedule["Name"] for schedule in response['Schedules']]
            print("schedules_list -->",schedules_list)
            if next_sf_scheduler_name not in schedules_list:
            
                response = sh_client.create_schedule(
                FlexibleTimeWindow={
                    'MaximumWindowInMinutes': 1,
                    'Mode': 'FLEXIBLE'
                },
                
                Name= next_sf_scheduler_name, 
                #ScheduleExpression = f'cron({current_minute} {current_hr} * * ? *)',
                ScheduleExpression = f'at({current_time_one_time_schedule})',
                StartDate = datetime.now(), 
                State='ENABLED',
                Target={
                    'Arn': Arn,
                    'RoleArn': RoleArn,
                    'Input': next_scheduler_input
                    }
                )
                print("created schedule")
            
            else:
                sh_client.update_schedule(Name=next_sf_scheduler_name,
                ScheduleExpression = f'at({current_time_one_time_schedule})',
                FlexibleTimeWindow={
                    'MaximumWindowInMinutes': 1,
                    'Mode': 'FLEXIBLE'
                },
                Target={
                    'Arn': Arn,
                    'RoleArn': RoleArn,
                    'Input': next_scheduler_input
                    }
                )
                print("updated schedule")
            
            ## write into json with the scheduler status
            sf_names_file_content["SF_scheduler"] = SF_Scheduler_dict
        else:
            for key, value in SF_Scheduler_dict.items(): 
                SF_Scheduler_dict[key]['status'] = ""
                print("final SF_Scheduler_dict -- ", SF_Scheduler_dict[key], "--", SF_Scheduler_dict[key]['status'])
            sf_names_file_content["SF_scheduler"] = SF_Scheduler_dict
        write_to_s3(sf_names_file_content, s3_bucket, neercrm_scheduler_file)
    
    except Exception as e:
        raise e
