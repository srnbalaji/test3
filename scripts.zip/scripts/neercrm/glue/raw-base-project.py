import sys
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim
from pyspark.sql import functions as F
from pyspark.sql.functions import when, length, date_format, to_timestamp
from pyspark.sql.types import DateType
from pyspark.sql.types import DecimalType

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params"])
extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]

batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
	"pipeline_name": job_name,
	"log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
	try:
		sns_client = boto3.client("sns")
		sns_status = sns_client.publish(
			TopicArn=sns_arn, Subject=email_sub, Message=email_body
		)
		return sns_status["ResponseMetadata"]["HTTPStatusCode"]
	except Exception as e:
		logger.info(f"sns_publish function failed with follwoing error..... {e} ")
		raise e

#Email body contents
def generate_email_body(alert_flag):
	try:
		alert_flag = alert_flag.upper()
		curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
		failure_email_body = config.failure_email_body
		success_email_body = config.success_email_body
		if alert_flag == "SUCCESS":
			email_body = success_email_body.format(
				job_name=job_name, run_date=curnt_time_msg, environment=environment
			)
		else:
			email_body = failure_email_body.format(
				job_name=job_name,
				run_date=curnt_time_msg,
				environment=environment,
				error=error,
				log_group=log_file_name,
				log_stream=etl_batch_id,
			)

		email_sub = f"{environment}:{alert_flag}:EDP_AXIS_{curnt_time_msg}"

		return [email_sub, email_body]

	except Exception as e:
		logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
		raise e


def timestamp_generator(format):
	try:
		eastern_timeZone = dateutil.tz.gettz("US/Eastern")
		result = datetime.now(tz=eastern_timeZone).strftime(format)

		return result

	except Exception as e:
		raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_db_table = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

try:
	redshift_properties = spark._jvm.java.util.Properties()
	redshift_properties.setProperty("url", redshift_jdbc_url)
	redshift_properties.setProperty("dbtable", redshift_db_table)
	redshift_properties.setProperty("user", redshift_user)
	redshift_properties.setProperty("password", redshift_password)
	redshift_properties.setProperty("TempDir", redshift_temp_dir)
	redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
	redshift_properties.setProperty("connectionName", redshift_connection_name)
	connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
	
	batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
	batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	
	Global_Source_System_Name = "Salesforce_NEERCRM_Source_Product"
	
	sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
			   from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'sfdc_neercrm_project_raw') custom"""
	redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
	auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")

	insert_audit = f"""INSERT INTO vendor_customer_opportunities_raw.edp_axis_batch_control_log(batch_id 	,batch_start_dttm 	,batch_status ,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone ,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH2:MI:SS:MS\'))"""
	statement = connection.createStatement()
	statement.executeUpdate(insert_audit)
	statement.close()
	
	
	query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_project_raw"""
	statement = connection.createStatement()
	statement.executeUpdate(query)
	statement.close()
	
	staging_path = s3_staging_config+"/output/"+filename+"/staging/"
	row2 = spark.read.option("multiline","True").json(staging_path)
	
	row2.printSchema()
	
	'''row2 = row2.withColumnRenamed(row2.columns[0],'CreatedDate')\
		.withColumnRenamed(row2.columns[1],'RecordTypeID')\
		.withColumnRenamed(row2.columns[2],'LastModifiedDate')\
		.withColumnRenamed(row2.columns[3],'NCRM_Broker_FeeMM__c')\
		.withColumnRenamed(row2.columns[4],'NCRM_Deferral_Impact__c')\
		.withColumnRenamed(row2.columns[5],'NCRM_NPV__c')\
		.withColumnRenamed(row2.columns[6],'NCRM_NEER_IRR__c')\
		.withColumnRenamed(row2.columns[7],'NCRM_Price__c')\
		.withColumnRenamed(row2.columns[8],'NCRM_State__c')\
		.withColumnRenamed(row2.columns[9],'NCRM_Term__c')\
		.withColumnRenamed(row2.columns[10],'NCRM_Volume__c')\
		.withColumnRenamed(row2.columns[11],'NCRM_CapEx_EPC_MM__c')\
		.withColumnRenamed(row2.columns[12],'NCRM_InterconnectionMM__c')\
		.withColumnRenamed(row2.columns[13],'NCRM_Merchant_Term__c')\
		.withColumnRenamed(row2.columns[14],'NCRM_OpEx__c')\
		.withColumnRenamed(row2.columns[15],'NCRM_Other_Capital_Costs__c')\
		.withColumnRenamed(row2.columns[16],'NCRM_System_Lease_Escalation__c')\
		.withColumnRenamed(row2.columns[17],'NCRM_System_Lease_Rate__c')\
		.withColumnRenamed(row2.columns[18],'NCRM_Size_MWac__c')\
		.withColumnRenamed(row2.columns[19],'NCRM_Size_MWdc__c')\
		.withColumnRenamed(row2.columns[20],'NCRM_Solar_Yield_kwh_kwp__c')\
		.withColumnRenamed(row2.columns[21],'NCRM_Storage_Duration_hrs__c')\
		.withColumnRenamed(row2.columns[22],'NCRM_Volume_Chargers__c')\
		.withColumnRenamed(row2.columns[23],'NCRM_Year1_Production_Mwh__c')\
		.withColumnRenamed(row2.columns[24],'NCRM_Site_Lease_Escalation__c')\
		.withColumnRenamed(row2.columns[25],'NCRM_Site_Lease_Rate_acre__c')\
		.withColumnRenamed(row2.columns[26],'NCRM_Site_Lease_Term_yrs__c')\
		.withColumnRenamed(row2.columns[27],'NCRM_Tariff_Term_YR__c')\
		.withColumnRenamed(row2.columns[28],'NCRM_ROE__c')\
		.withColumnRenamed(row2.columns[29],'NCRM_TE_IRR__c')\
		.withColumnRenamed(row2.columns[30],'NCRM_WACC__c')\
		.withColumnRenamed(row2.columns[31],'NCRM_Escalation__c')\
		.withColumnRenamed(row2.columns[32],'NCRM_System_Type__c')\
		.withColumnRenamed(row2.columns[33],'NCRM_Opportunity__c')\
		.withColumnRenamed(row2.columns[34],'NCRM_Est_ITC_COD_Date__c')\
		.withColumnRenamed(row2.columns[35],'NCRM_Product__c')\
		.withColumnRenamed(row2.columns[36],'NCRM_Project_Type__c')\
		.withColumnRenamed(row2.columns[37],'NCRM_Deal_Structure__c')\
		.withColumnRenamed(row2.columns[38],'NCRM_Project_Name__c')\
		.withColumnRenamed(row2.columns[40],'NCRM_Price_Unit__c')\
		.withColumnRenamed(row2.columns[41],'NCRM_Project_Results__c')\
		.withColumnRenamed(row2.columns[42],'NAME')\
		.withColumnRenamed(row2.columns[43],'ID')'''
		
	row2 = row2.withColumn("batch_id",lit(batch_id))\
			   .withColumn("source_system",lit(source_system))\
			   .withColumn("created_by",lit(created_by))\
			   .withColumn("modified_by",lit(modified_by))\
			   .withColumn("owner",lit(owner))
			   
	print("row2.count() ....")           
	print(row2.count())
		
	query = f"""(SELECT system_id,
			account_id,
			name,
			created_date,
			last_modified_date,
			status,
			lead,
			owner,
			owner_id,
			ownerid_name,
			site_city,
			businessdevelopment_id,
			estcod_date,
			businessdevelopment_name,
			businessgroup_name,
			business_group,
			system_type,
			statecode_name,
			greenfield_matype,
			stageage_calculated,
			dgstage3_date,
			cioriginator_id,
			cioriginator_name,
			dg_region,
			dgstage5_date,
			stage_number,
			batch_id,
			source_system,
			created_by,
			created_dttm,
			modified_by,
			modified_dttm FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw)"""
			
	OnSubjobOk34 = spark.read.jdbc(redshift_jdbc_url, query, properties=redshift_properties)
	
	print("OnSubjobOk34.count()---> ")
	print(OnSubjobOk34.count())
	# Conforming fields names to the component layout
	OnSubjobOk34 = OnSubjobOk34.withColumnRenamed(OnSubjobOk34.columns[0],'system_id')\
		.withColumnRenamed(OnSubjobOk34.columns[1],'account_id')\
		.withColumnRenamed(OnSubjobOk34.columns[2],'name')\
		.withColumnRenamed(OnSubjobOk34.columns[3],'created_date')\
		.withColumnRenamed(OnSubjobOk34.columns[4],'last_modified_date')\
		.withColumnRenamed(OnSubjobOk34.columns[5],'status')\
		.withColumnRenamed(OnSubjobOk34.columns[6],'lead')\
		.withColumnRenamed(OnSubjobOk34.columns[7],'owner')\
		.withColumnRenamed(OnSubjobOk34.columns[8],'owner_id')\
		.withColumnRenamed(OnSubjobOk34.columns[9],'ownerid_name')\
		.withColumnRenamed(OnSubjobOk34.columns[10],'site_city')\
		.withColumnRenamed(OnSubjobOk34.columns[11],'businessdevelopment_id')\
		.withColumnRenamed(OnSubjobOk34.columns[12],'estcod_date')\
		.withColumnRenamed(OnSubjobOk34.columns[13],'businessdevelopment_name')\
		.withColumnRenamed(OnSubjobOk34.columns[14],'businessgroup_name')\
		.withColumnRenamed(OnSubjobOk34.columns[15],'business_group')\
		.withColumnRenamed(OnSubjobOk34.columns[16],'system_type')\
		.withColumnRenamed(OnSubjobOk34.columns[17],'statecode_name')\
		.withColumnRenamed(OnSubjobOk34.columns[18],'greenfield_matype')\
		.withColumnRenamed(OnSubjobOk34.columns[19],'stageage_calculated')\
		.withColumnRenamed(OnSubjobOk34.columns[20],'dgstage3_date')\
		.withColumnRenamed(OnSubjobOk34.columns[21],'cioriginator_id')\
		.withColumnRenamed(OnSubjobOk34.columns[22],'cioriginator_name')\
		.withColumnRenamed(OnSubjobOk34.columns[23],'dg_region')\
		.withColumnRenamed(OnSubjobOk34.columns[24],'dgstage5_date')\
		.withColumnRenamed(OnSubjobOk34.columns[25],'stage_number')\
		.withColumnRenamed(OnSubjobOk34.columns[26],'batch_id')\
		.withColumnRenamed(OnSubjobOk34.columns[27],'source_system')\
		.withColumnRenamed(OnSubjobOk34.columns[28],'created_by')\
		.withColumnRenamed(OnSubjobOk34.columns[29],'created_dttm')\
		.withColumnRenamed(OnSubjobOk34.columns[30],'modified_by')\
		.withColumnRenamed(OnSubjobOk34.columns[31],'modified_dttm')
		
		
	query1 = f"""(SELECT system_id,
			account_id,
			name,
			created_date,
			last_modified_date,
			status,
			lead,
			owner,
			owner_id,
			ownerid_name,
			site_city,
			businessdevelopment_id,
			estcod_date,
			businessdevelopment_name,
			businessgroup_name,
			business_group,
			system_type,
			statecode_name,
			greenfield_matype,
			stageage_calculated,
			dgstage3_date,
			cioriginator_id,
			cioriginator_name,
			dg_region,
			dgstage5_date,
			stage_number,
			batch_id,
			source_system,
			created_by,
			created_dttm,
			modified_by,
			modified_dttm FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw)"""
			
	row1 = spark.read.jdbc(redshift_jdbc_url, query1, properties=redshift_properties)
	
	# Conforming fields names to the component layout
	row1 = row1.withColumnRenamed(row1.columns[0],'system_id')\
		.withColumnRenamed(row1.columns[1],'account_id')\
		.withColumnRenamed(row1.columns[2],'name')\
		.withColumnRenamed(row1.columns[3],'created_date')\
		.withColumnRenamed(row1.columns[4],'last_modified_date')\
		.withColumnRenamed(row1.columns[5],'status')\
		.withColumnRenamed(row1.columns[6],'lead')\
		.withColumnRenamed(row1.columns[7],'owner')\
		.withColumnRenamed(row1.columns[8],'owner_id')\
		.withColumnRenamed(row1.columns[9],'ownerid_name')\
		.withColumnRenamed(row1.columns[10],'site_city')\
		.withColumnRenamed(row1.columns[11],'businessdevelopment_id')\
		.withColumnRenamed(row1.columns[12],'estcod_date')\
		.withColumnRenamed(row1.columns[13],'businessdevelopment_name')\
		.withColumnRenamed(row1.columns[14],'businessgroup_name')\
		.withColumnRenamed(row1.columns[15],'business_group')\
		.withColumnRenamed(row1.columns[16],'system_type')\
		.withColumnRenamed(row1.columns[17],'statecode_name')\
		.withColumnRenamed(row1.columns[18],'greenfield_matype')\
		.withColumnRenamed(row1.columns[19],'stageage_calculated')\
		.withColumnRenamed(row1.columns[20],'dgstage3_date')\
		.withColumnRenamed(row1.columns[21],'cioriginator_id')\
		.withColumnRenamed(row1.columns[22],'cioriginator_name')\
		.withColumnRenamed(row1.columns[23],'dg_region')\
		.withColumnRenamed(row1.columns[24],'dgstage5_date')\
		.withColumnRenamed(row1.columns[25],'stage_number')\
		.withColumnRenamed(row1.columns[26],'batch_id')\
		.withColumnRenamed(row1.columns[27],'source_system')\
		.withColumnRenamed(row1.columns[28],'created_by')\
		.withColumnRenamed(row1.columns[29],'created_dttm')\
		.withColumnRenamed(row1.columns[30],'modified_by')\
		.withColumnRenamed(row1.columns[31],'modified_dttm')

	print("row2 printSchema()-->")
	row2.printSchema()
	print("row1.count() ....")           
	print(row1.count())
	tMap_1_joined = row1.join(row2, (row1.system_id == row2.NCRM_Opportunity__c), 'inner')
	
	
	print("tMap_1_joined.count() ....")           
	print(tMap_1_joined.count())
	
	insert = tMap_1_joined.select(
	trim(expr("substr(NCRM_Project_Name__c,1,36)")).alias('project_id'),
	row2.RecordTypeId.alias('recordtypeid'),
	trim(expr("substr(NCRM_Opportunity__c,1,36)")).alias('opportunity_id'),
	trim(expr("substr(ID,1,36)")).alias('product_id'),
	trim(expr("substr(NCRM_Product__c,1,530)")).alias('technology'),
	trim(expr("substr(NCRM_Product__c,1,530)")).alias('technology_1'),
	trim(expr("substr(NCRM_Product__c,1,530)")).alias('technology_2'),
	trim(expr("substr(NCRM_Product__c,1,530)")).alias('technology_3'),
	trim(expr("substr(NCRM_Product__c,1,530)")).alias('technology_4'),
	(when((row2.NCRM_Product__c.contains(lit("CHP"))) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("") )| (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None).otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_chp_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None) .otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_evchargers_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None) .otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_evfleetvehicles_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")) ,(when((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" ")) , None).otherwise((row2.NCRM_CapEx_EPC_MM__c)).cast(DecimalType()))).otherwise(None)).alias('capex_fuelcell_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None).otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_h2electrolyzer_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) 
		| (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None)
			.otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_mainspring_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None).otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_solar_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("On-site Storage")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("") )| (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None) .otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_storage_epc_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("WaterHub")) ,(when(((row2.NCRM_CapEx_EPC_MM__c == None) | (row2.NCRM_CapEx_EPC_MM__c == lit("")) | (row2.NCRM_CapEx_EPC_MM__c == lit(" "))) , None) .otherwise((row2.NCRM_CapEx_EPC_MM__c).cast(DecimalType())))).otherwise(None)).alias('capex_sustainablewater_epc_mm'),
		
	(when((row2.NCRM_Total_CapEx__c == None) | (row2.NCRM_Total_CapEx__c == lit("")) | (row2.NCRM_Total_CapEx__c == lit(" ")) , None).otherwise(row2.NCRM_Total_CapEx__c)).alias('totalcapex_mm'),
		
	(when(row2.NCRM_Product__c.contains(lit("CHP")) ,(when(((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" "))) , None).otherwise((row2.NCRM_Volume__c)).cast(DecimalType()))).otherwise(None)).alias('chpcapacity_mw'),
		
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when(((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" "))) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('evchargerscapacity_mw'),
	
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")) ,(when(((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" "))) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('fuelcell_capacity_mw'),
	
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when(((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" "))) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('mainspring_capacity_mw'),
		
	(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))).alias('solarcapacity2_mw'),
		
	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('solarcapacity_mw'),
		
	(when((row2.NCRM_Size_MWac__c == None) | (row2.NCRM_Size_MWac__c == lit("")) | (row2.NCRM_Size_MWac__c == lit(" ")) , None).otherwise(row2.NCRM_Size_MWac__c)).alias('solarsize_mwac'),
		
	(when((row2.NCRM_Size_MWdc__c == None) | (row2.NCRM_Size_MWdc__c == lit("")) | (row2.NCRM_Size_MWdc__c == lit(" ")) , None).otherwise((row2.NCRM_Size_MWdc__c).cast(DecimalType(18,2)))).alias('solarsize_mwdc'),
		
	(when((row2.NCRM_Year1_Production_Mwh__c == None) | (row2.NCRM_Year1_Production_Mwh__c == lit("")) | (row2.NCRM_Year1_Production_Mwh__c == lit(" ")) , None).otherwise((row2.NCRM_Year1_Production_Mwh__c).cast(DecimalType()))).alias('solaryear1_production_mwh'),
		
	(when((row2.NCRM_Product__c.contains(lit("On-site Storage"))) ,((when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))))).otherwise(None)).alias('storage_capacity'),
		
	(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit(""))| (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))).alias('storagecapacity2_mw'),
		
	(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))).alias('storageenergy_mw'),
		
	(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))).alias('windcapacity2_mw'),
		
	(when((row2.NCRM_Other_Capital_Costs__c == None) | (row2.NCRM_Other_Capital_Costs__c == lit("")) | (row2.NCRM_Other_Capital_Costs__c == lit(" ")) , None).otherwise((row2.NCRM_Other_Capital_Costs__c).cast(DecimalType()))).alias('othercapitalcosts_mm'),
		
	(when((row2.NCRM_InterconnectionMM__c == None) | (row2.NCRM_InterconnectionMM__c == lit("")) | (row2.NCRM_InterconnectionMM__c == lit(" ")) , None).otherwise(row2.NCRM_InterconnectionMM__c)).alias('interconnection_mm'),
	trim(expr("substr(NCRM_State__c,1,530)")).alias('statecode_name'),
	trim(expr("substr(NCRM_Project_Results__c,1,530)")).alias('statuscode_name'),
	(when((row2.CreatedDate == ""), None).otherwise(date_format(col("CreatedDate"), "yyyy-MM-dd HH:mm:ss.SSSZ"))).alias('created_on'),
		
	(when((row2.NCRM_Tariff_Term_YR__c == None) | (row2.NCRM_Tariff_Term_YR__c == lit("")) | (row2.NCRM_Tariff_Term_YR__c == lit(" ")) , None).otherwise((row2.NCRM_Tariff_Term_YR__c).cast(DecimalType()))).alias('solarincentive_termyrs'),
	row1.stage_number.alias('stage_number'),
	trim(expr("substr(NCRM_System_Type__c,1,160)")).alias('solarsystem_type'),
	(when(row2.NCRM_Product__c.contains(lit("WaterHub")) ,(when((row2.NCRM_Volume__c == None) | 
	(row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None)).otherwise((row2.NCRM_Volume__c).cast(DecimalType()))).otherwise(None)).alias('sustainable_watercapacity_mmgalyr'),
		
	(when((row2.NCRM_Solar_Yield_kwh_kwp__c == None) | (row2.NCRM_Solar_Yield_kwh_kwp__c == lit("")) | (row2.NCRM_Solar_Yield_kwh_kwp__c == lit(" ")) , None).otherwise((row2.NCRM_Solar_Yield_kwh_kwp__c).cast(DecimalType()))).alias('solaryield_kwh_kwp'),
		
	(when((row2.NCRM_Storage_Duration_hrs__c == None) | (row2.NCRM_Storage_Duration_hrs__c == lit("")) | (row2.NCRM_Storage_Duration_hrs__c == lit(" ")) , None).otherwise((row2.NCRM_Storage_Duration_hrs__c).cast(DecimalType()))).alias('storage_durationhours'),
		
	(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise(row2.NCRM_Price__c)).alias('water_ratekgal'),
		
	(when((row2.NCRM_Volume_Chargers__c == None) | (row2.NCRM_Volume_Chargers__c == lit("")) |(row2.NCRM_Volume_Chargers__c == lit(" ")) , None).otherwise((row2.NCRM_Volume_Chargers__c).cast(DecimalType()))).alias('numberof_evchargers'),
		
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None).otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('numberof_evfleetvehicles'),
		
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")) ,(when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None) .otherwise((row2.NCRM_Volume__c).cast(DecimalType())))).otherwise(None)).alias('h2electrolyzer_capacitykg_h2day'),
		
	(when((row2.NCRM_Broker_FeeMM__c == None) | (row2.NCRM_Broker_FeeMM__c == lit("") )| (row2.NCRM_Broker_FeeMM__c == lit(" ")) , None).otherwise((row2.NCRM_Broker_FeeMM__c).cast(DecimalType()))).alias('development_feemm'),
		
	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_solaryr'),
		
	(when(row2.NCRM_Product__c.contains(lit("On-site Storage")) ,(when((row2.NCRM_OpEx__c == None )| (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_storageyr'),
		
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_mainspringyr'),
		
	(when(row2.NCRM_Product__c.contains(lit("CHP")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_chpepcyr'),
	(when(row2.NCRM_Product__c.contains(lit("WaterHub")) ,(when((row2.NCRM_OpEx__c == None )|(row2.NCRM_OpEx__c == lit("") )| (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_sustainablewateryr'),
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_evchargersyr'),
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_evfleetvehiclesyr'),
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")) ,(when((row2.NCRM_OpEx__c == None )| (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_h2electrolyzeryr'),
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")) ,(when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType())))).otherwise(None)).alias('opex_fuelcellyr'),
	(when((row2.NCRM_Site_Lease_Rate_acre__c == None) | (row2.NCRM_Site_Lease_Rate_acre__c == lit("")) |( row2.NCRM_Site_Lease_Rate_acre__c == lit(" ")) , None).otherwise((row2.NCRM_Site_Lease_Rate_acre__c).cast(DecimalType()))).alias('sitelease_rateacre'),
		
	(when((row2.NCRM_Site_Lease_Escalation__c == None) | (row2.NCRM_Site_Lease_Escalation__c == lit("")) | (row2.NCRM_Site_Lease_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Site_Lease_Escalation__c).cast(DecimalType()))).alias('sitelease_escalation'),
		
	(when((row2.NCRM_Site_Lease_Term_yrs__c == None )| (row2.NCRM_Site_Lease_Term_yrs__c == lit("")) | (row2.NCRM_Site_Lease_Term_yrs__c == lit(" ")) , None) .otherwise((row2.NCRM_Site_Lease_Term_yrs__c).cast(DecimalType()))).alias('sitelease_termyrs'),

	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('solar_ppatermyrs'),

	(when(row2.NCRM_Product__c.contains(lit("On-site Storage")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('storagecapacity_paymenttermyrs'),
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('mainspring_contracttermyrs'),
	(when(row2.NCRM_Product__c.contains(lit("CHP")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('chp_contracttermyrs'),
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))) .otherwise(None)).alias('evchargers_contracttermyrs'),
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('evfleetfinance_contracttermyrs'),
		
	(when(row2.NCRM_Product__c.contains(lit("WaterHub")) ,(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias('sustainablewater_contracttermyrs'),
		
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")),(when((row2.NCRM_Term__c.isNull())| (row2.NCRM_Term__c == "")| (row2.NCRM_Term__c == " "),None).otherwise(row2.NCRM_Term__c.cast(DecimalType())))).otherwise(None)).alias("h2electrolyzer_contracttermyrs"),
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")),(when((row2.NCRM_Term__c == None)| (row2.NCRM_Term__c == lit(""))| (row2.NCRM_Term__c == lit("")),None).otherwise((row2.NCRM_Term__c).cast(DecimalType())))).otherwise(None)).alias("fuelcell_contracttermyrs"),
		
	(when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType()))).alias('systemlease_termyrs'),
	(when((row2.NCRM_Merchant_Term__c == None) | (row2.NCRM_Merchant_Term__c == lit("")) |(row2.NCRM_Merchant_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Merchant_Term__c).cast(DecimalType()))).alias('merchant_termyrs'),
		
	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Escalation__c).cast(DecimalType())))).otherwise(None)).alias('solarppa_escalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("On-site Storage")) ,(when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Escalation__c).cast(DecimalType())))).otherwise(None)).alias('storagecapacity_paymentescalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))).otherwise(None)).alias('mainspring_escalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Escalation__c).cast(DecimalType())))).otherwise(None)).alias('evchargers_escalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Escalation__c).cast(DecimalType())))).otherwise(None)).alias('evfleet_financeescalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('h2electrolyzer_escalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")) ,(when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None) .otherwise((row2.NCRM_Escalation__c).cast(DecimalType())))).otherwise(None)).alias('fuelcell_escalator'),
		
	(when((row2.NCRM_System_Lease_Escalation__c == None)| (row2.NCRM_System_Lease_Escalation__c == lit("")) | (row2.NCRM_System_Lease_Escalation__c == lit(" ")) , None) .otherwise((row2.NCRM_System_Lease_Escalation__c).cast(DecimalType()))).alias('systemlease_escalator'),
		
	(when(row2.NCRM_Product__c.contains(lit("Community Solar")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('solarppa_ratemwh'),
		
	(when(row2.NCRM_Product__c.contains(lit("On-site Storage")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('storagecapacity_paymentratekwmo'),
		
	(when(row2.NCRM_Product__c.contains(lit("Mainspring")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('mainspring_contractratemwh'),
		
	(when(row2.NCRM_Product__c.contains(lit("CHP")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('chpepc_contractratemwh'),
		
	(when(row2.NCRM_Product__c.contains(lit("WaterHub")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('sustainablewater_contractratekgal'),
		
	(when(row2.NCRM_Product__c.contains(lit("H2 Electrolyzer")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))).otherwise(None)).alias('h2electrolyzer_contractratekgh2'),
		
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")),expr("substr(NCRM_Price_Unit__c, 0, 530)")).otherwise(None)).alias('evchargers_contractunits'),
		
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")),expr("substr(NCRM_Price_Unit__c, 0, 530)")).otherwise(None)).alias('evfleetfinance_contractunits'),
	(when(row2.NCRM_Product__c.contains(lit("BEV Chargers")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('evchargers_contractrate'),
		
	(when(row2.NCRM_Product__c.contains(lit("EV Fleet")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('evfleet_financecontractrate'),
		
	(when(row2.NCRM_Product__c.contains(lit("Fuel Cell")) ,(when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c).cast(DecimalType())))) .otherwise(None)).alias('fuelcell_contractrate_mwh'),
		
	(when((row2.NCRM_System_Lease_Rate__c == None) | (row2.NCRM_System_Lease_Rate__c == lit("")) | (row2.NCRM_System_Lease_Rate__c == lit(" ")) , None).otherwise((row2.NCRM_System_Lease_Rate__c).cast(DecimalType()))).alias('systemlease_rateyr'),
		
	(when((row2.NCRM_NEER_IRR__c == None) | (row2.NCRM_NEER_IRR__c == lit("")) | (row2.NCRM_NEER_IRR__c == lit(" ")) , None).otherwise(row2.NCRM_NEER_IRR__c)).alias('neerirr'),
		
	(when((row2.NCRM_TE_IRR__c == None) | (row2.NCRM_TE_IRR__c == lit("")) | (row2.NCRM_TE_IRR__c == lit(" ")) , None) .otherwise(row2.NCRM_TE_IRR__c)).alias('teirr'),
		
	(when((row2.NCRM_ROE__c == None) | (row2.NCRM_ROE__c == lit("")) | (row2.NCRM_ROE__c == lit(" ")) , None) .otherwise(row2.NCRM_ROE__c)).alias('roe_5050'),
		
	(when((row2.NCRM_NPV__c == None) | (row2.NCRM_NPV__c == lit("") )| (row2.NCRM_NPV__c == lit(" ")) , None) .otherwise(row2.NCRM_NPV__c)).alias('npvmm'),
		
	(when((row2.NCRM_WACC__c == None) | (row2.NCRM_WACC__c == lit("")) | (row2.NCRM_WACC__c == lit(" ")) , None) .otherwise(row2.NCRM_WACC__c)).alias('wacc'),
		
	(when((row2.NCRM_Deferral_Impact__c == None) | (row2.NCRM_Deferral_Impact__c == lit("")) | (row2.NCRM_Deferral_Impact__c == lit(" ")) , None) .otherwise((row2.NCRM_Deferral_Impact__c).cast(DecimalType()))).alias('deferral_impact'),
		
	(when((row2.NCRM_ROE__c == None) | (row2.NCRM_ROE__c == lit("")) | (row2.NCRM_ROE__c == lit(" ")) , None) .otherwise(row2.NCRM_ROE__c)).alias('roe_percentage'),
		
	row2.batch_id.alias('batch_id'),
	row2.source_system.alias('source_system'),
	row2.created_by.alias('created_by'),
	date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('created_dttm'),
	row2.modified_by.alias('modified_by'),
	date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('modified_dttm')
	
	)
	print("Insert capex_chp_epc_mm data")
	insert.select('project_id').filter(col("project_id") == 'a1h5Y00000zm0MJQAY').show()
	
	query3 = f"""(SELECT Name,
			NCRM_Site_City__c,
			OwnerId,
			batch_id,
			project_id,
			source_system,
			created_by,
			created_dttm,
			modified_by,
			modified_dttm FROM vendor_customer_opportunities_raw.sfdc_neercrm_project_lookup_raw)"""
	
	row3 = spark.read.jdbc(redshift_jdbc_url, query3, properties=redshift_properties)
	
	print("row3 project id")
	row3.select('project_id').filter(col("project_id") == 'a1h5Y00000zm0MJQAY').show()
	row3 = row3.withColumnRenamed(row3.columns[0],'Name')\
		.withColumnRenamed(row3.columns[1],'NCRM_Site_City__c')\
		.withColumnRenamed(row3.columns[2],'OwnerId')\
		.withColumnRenamed(row3.columns[3],'batch_id')\
		.withColumnRenamed(row3.columns[4],'project_id')\
		.withColumnRenamed(row3.columns[5],'source_system')\
		.withColumnRenamed(row3.columns[6],'created_by')\
		.withColumnRenamed(row3.columns[7],'created_dttm')\
		.withColumnRenamed(row3.columns[8],'modified_by')\
		.withColumnRenamed(row3.columns[9],'modified_dttm')

	print("before dropping duplicates ")
	
	row3 = row3.dropDuplicates(["project_id"])
	print("row3.count() =====")
	print(row3.count())
	print("after dropping duplicates")
	
	tMap_2_joined = insert.join(row3, (insert.project_id == row3.project_id),'left_outer')
	
	print("tMap_2_joined****")
	
	print("tMap_2_joined.count() ....")           
	print(tMap_2_joined.count())
	
	final_insert = tMap_2_joined.select(
		row3.project_id.alias('project_id'),
		insert.recordtypeid.alias('recordtypeid'),
		insert.opportunity_id.alias('opportunity_id'),
		insert.product_id.alias('product_id'),
		trim(expr("substr(Name,1,250)")).alias('project_name'),
		insert.technology.alias('technology'),
		insert.technology_1.alias('technology_1'),
		insert.technology_2.alias('technology_2'),
		insert.technology_3.alias('technology_3'),
		insert.technology_4.alias('technology_4'),
		insert.capex_chp_epc_mm.alias('capex_chp_epc_mm'),
		insert.capex_evchargers_epc_mm.alias('capex_evchargers_epc_mm'),
		insert.capex_evfleetvehicles_mm.alias('capex_evfleetvehicles_mm'),
		insert.capex_fuelcell_epc_mm.alias('capex_fuelcell_epc_mm'),
		insert.capex_h2electrolyzer_epc_mm.alias('capex_h2electrolyzer_epc_mm'),
		insert.capex_mainspring_epc_mm.alias('capex_mainspring_epc_mm'),
		insert.capex_solar_epc_mm.alias('capex_solar_epc_mm'),
		insert.capex_storage_epc_mm.alias('capex_storage_epc_mm'),
		insert.capex_sustainablewater_epc_mm.alias('capex_sustainablewater_epc_mm'),
		insert.totalcapex_mm.alias('totalcapex_mm'),
		insert.chpcapacity_mw.alias('chpcapacity_mw'),
		insert.evchargerscapacity_mw.alias('evchargerscapacity_mw'),
		insert.fuelcell_capacity_mw.alias('fuelcell_capacity_mw'),
		insert.mainspring_capacity_mw.alias('mainspring_capacity_mw'),
		insert.solarcapacity2_mw.alias('solarcapacity2_mw'),
		insert.solarcapacity_mw.alias('solarcapacity_mw'),
		insert.solarsize_mwac.alias('solarsize_mwac'),
		insert.solarsize_mwdc.alias('solarsize_mwdc'),
		insert.solaryear1_production_mwh.alias('solaryear1_production_mwh'),
		insert.storage_capacity.alias('storage_capacity'),
		insert.storagecapacity2_mw.alias('storagecapacity2_mw'),
		insert.storageenergy_mw.alias('storageenergy_mw'),
		insert.windcapacity2_mw.alias('windcapacity2_mw'),
		insert.othercapitalcosts_mm.alias('othercapitalcosts_mm'),
		insert.interconnection_mm.alias('interconnection_mm'),
		row3.OwnerId.alias('owner_id'),
		insert.statecode_name.alias('statecode_name'),
		insert.statuscode_name.alias('statuscode_name'),
		insert.created_on.alias('created_on'),
		insert.solarincentive_termyrs.alias('solarincentive_termyrs'),
		insert.stage_number.alias('stage_number'),
		insert.solarsystem_type.alias('solarsystem_type'),
		insert.sustainable_watercapacity_mmgalyr.alias('sustainable_watercapacity_mmgalyr'),
		insert.solaryield_kwh_kwp.alias('solaryield_kwh_kwp'),
		insert.storage_durationhours.alias('storage_durationhours'),
		insert.water_ratekgal.alias('water_ratekgal'),
		insert.numberof_evchargers.alias('numberof_evchargers'),
		insert.numberof_evfleetvehicles.alias('numberof_evfleetvehicles'),
		insert.h2electrolyzer_capacitykg_h2day.alias('h2electrolyzer_capacitykg_h2day'),
		insert.development_feemm.alias('development_feemm'),
		insert.opex_solaryr.alias('opex_solaryr'),
		insert.opex_storageyr.alias('opex_storageyr'),
		insert.opex_mainspringyr.alias('opex_mainspringyr'),
		insert.opex_chpepcyr.alias('opex_chpepcyr'),
		insert.opex_sustainablewateryr.alias('opex_sustainablewateryr'),
		insert.opex_evchargersyr.alias('opex_evchargersyr'),
		insert.opex_evfleetvehiclesyr.alias('opex_evfleetvehiclesyr'),
		insert.opex_h2electrolyzeryr.alias('opex_h2electrolyzeryr'),
		insert.opex_fuelcellyr.alias('opex_fuelcellyr'),
		insert.sitelease_rateacre.alias('sitelease_rateacre'),
		insert.sitelease_escalation.alias('sitelease_escalation'),
		insert.sitelease_termyrs.alias('sitelease_termyrs'),
		insert.solar_ppatermyrs.alias('solar_ppatermyrs'),
		insert.storagecapacity_paymenttermyrs.alias('storagecapacity_paymenttermyrs'),
		insert.mainspring_contracttermyrs.alias('mainspring_contracttermyrs'),
		insert.chp_contracttermyrs.alias('chp_contracttermyrs'),
		insert.evchargers_contracttermyrs.alias('evchargers_contracttermyrs'),
		insert.evfleetfinance_contracttermyrs.alias('evfleetfinance_contracttermyrs'),
		insert.sustainablewater_contracttermyrs.alias('sustainablewater_contracttermyrs'),
		insert.h2electrolyzer_contracttermyrs.alias('h2electrolyzer_contracttermyrs'),
		insert.fuelcell_contracttermyrs.alias('fuelcell_contracttermyrs'),
		insert.systemlease_termyrs.alias('systemlease_termyrs'),
		insert.merchant_termyrs.alias('merchant_termyrs'),
		insert.solarppa_escalator.alias('solarppa_escalator'),
		insert.storagecapacity_paymentescalator.alias('storagecapacity_paymentescalator'),
		insert.mainspring_escalator.alias('mainspring_escalator'),
		insert.evchargers_escalator.alias('evchargers_escalator'),
		insert.evfleet_financeescalator.alias('evfleet_financeescalator'),
		insert.h2electrolyzer_escalator.alias('h2electrolyzer_escalator'),
		insert.fuelcell_escalator.alias('fuelcell_escalator'),
		insert.systemlease_escalator.alias('systemlease_escalator'),
		insert.solarppa_ratemwh.alias('solarppa_ratemwh'),
		insert.storagecapacity_paymentratekwmo.alias('storagecapacity_paymentratekwmo'),
		insert.mainspring_contractratemwh.alias('mainspring_contractratemwh'),
		insert.chpepc_contractratemwh.alias('chpepc_contractratemwh'),
		insert.sustainablewater_contractratekgal.alias('sustainablewater_contractratekgal'),
		insert.h2electrolyzer_contractratekgh2.alias('h2electrolyzer_contractratekgh2'),
		insert.evchargers_contractunits.alias('evchargers_contractunits'),
		insert.evfleetfinance_contractunits.alias('evfleetfinance_contractunits'),
		insert.evchargers_contractrate.alias('evchargers_contractrate'),
		insert.evfleet_financecontractrate.alias('evfleet_financecontractrate'),
		insert.fuelcell_contractrate_mwh.alias('fuelcell_contractrate_mwh'),
		insert.systemlease_rateyr.alias('systemlease_rateyr'),
		insert.neerirr.alias('neerirr'),
		insert.teirr.alias('teirr'),
		insert.roe_5050.alias('roe_5050'),
		insert.npvmm.alias('npvmm'),
		insert.wacc.alias('wacc'),
		insert.deferral_impact.alias('deferral_impact'),
		insert.roe_percentage.alias('roe_percentage'),
		insert.batch_id.alias('batch_id'),
		insert.source_system.alias('source_system'),
		insert.created_by.alias('created_by'),
		insert.created_dttm.alias('created_dttm'),
		insert.modified_by.alias('modified_by'),
		insert.modified_dttm.alias('modified_dttm')
	)
	
	print("final_insert **")
	
	print("final_insert.count() ....")           
	final_insert.count()

	OnComponentOk5 = final_insert.select(
		final_insert.project_id.alias('project_id'),
		final_insert.opportunity_id.alias('opportunity_id'),
		final_insert.product_id.alias('product_id'),
		final_insert.project_name.alias('project_name'),
		final_insert.technology.alias('technology'),
		final_insert.technology_1.alias('technology_1'),
		final_insert.technology_2.alias('technology_2'),
		final_insert.technology_3.alias('technology_3'),
		final_insert.technology_4.alias('technology_4'),
		final_insert.capex_chp_epc_mm.alias('capex_chp_epc_mm'),
		final_insert.capex_evchargers_epc_mm.alias('capex_evchargers_epc_mm'),
		final_insert.capex_evfleetvehicles_mm.alias('capex_evfleetvehicles_mm'),
		final_insert.capex_fuelcell_epc_mm.alias('capex_fuelcell_epc_mm'),
		final_insert.capex_h2electrolyzer_epc_mm.alias('capex_h2electrolyzer_epc_mm'),
		final_insert.capex_mainspring_epc_mm.alias('capex_mainspring_epc_mm'),
		final_insert.capex_solar_epc_mm.alias('capex_solar_epc_mm'),
		final_insert.capex_storage_epc_mm.alias('capex_storage_epc_mm'),
		final_insert.capex_sustainablewater_epc_mm.alias('capex_sustainablewater_epc_mm'),
		final_insert.totalcapex_mm.alias('totalcapex_mm'),
		final_insert.chpcapacity_mw.alias('chpcapacity_mw'),
		final_insert.evchargerscapacity_mw.alias('evchargerscapacity_mw'),
		final_insert.fuelcell_capacity_mw.alias('fuelcell_capacity_mw'),
		final_insert.mainspring_capacity_mw.alias('mainspring_capacity_mw'),
		final_insert.solarcapacity2_mw.alias('solarcapacity2_mw'),
		final_insert.solarcapacity_mw.alias('solarcapacity_mw'),
		final_insert.solarsize_mwac.alias('solarsize_mwac'),
		final_insert.solarsize_mwdc.alias('solarsize_mwdc'),
		final_insert.solaryear1_production_mwh.alias('solaryear1_production_mwh'),
		final_insert.storage_capacity.alias('storage_capacity'),
		final_insert.storagecapacity2_mw.alias('storagecapacity2_mw'),
		final_insert.storageenergy_mw.alias('storageenergy_mw'),
		final_insert.windcapacity2_mw.alias('windcapacity2_mw'),
		final_insert.othercapitalcosts_mm.alias('othercapitalcosts_mm'),
		final_insert.interconnection_mm.alias('interconnection_mm'),
		final_insert.owner_id.alias('owner_id'),
		final_insert.statecode_name.alias('statecode_name'),
		final_insert.statuscode_name.alias('statuscode_name'),
		final_insert.created_on.alias('created_on'),
		final_insert.solarincentive_termyrs.alias('solarincentive_termyrs'),
		final_insert.stage_number.alias('stage_number'),
		final_insert.solarsystem_type.alias('solarsystem_type'),
		final_insert.sustainable_watercapacity_mmgalyr.alias('sustainable_watercapacity_mmgalyr'),
		final_insert.solaryield_kwh_kwp.alias('solaryield_kwh_kwp'),
		final_insert.storage_durationhours.alias('storage_durationhours'),
		final_insert.water_ratekgal.alias('water_ratekgal'),
		final_insert.numberof_evchargers.alias('numberof_evchargers'),
		final_insert.numberof_evfleetvehicles.alias('numberof_evfleetvehicles'),
		final_insert.h2electrolyzer_capacitykg_h2day.alias('h2electrolyzer_capacitykg_h2day'),
		final_insert.development_feemm.alias('development_feemm'),
		final_insert.opex_solaryr.alias('opex_solaryr'),
		final_insert.opex_storageyr.alias('opex_storageyr'),
		final_insert.opex_mainspringyr.alias('opex_mainspringyr'),
		final_insert.opex_chpepcyr.alias('opex_chpepcyr'),
		final_insert.opex_sustainablewateryr.alias('opex_sustainablewateryr'),
		final_insert.opex_evchargersyr.alias('opex_evchargersyr'),
		final_insert.opex_evfleetvehiclesyr.alias('opex_evfleetvehiclesyr'),
		final_insert.opex_h2electrolyzeryr.alias('opex_h2electrolyzeryr'),
		final_insert.opex_fuelcellyr.alias('opex_fuelcellyr'),
		final_insert.sitelease_rateacre.alias('sitelease_rateacre'),
		final_insert.sitelease_escalation.alias('sitelease_escalation'),
		final_insert.sitelease_termyrs.alias('sitelease_termyrs'),
		final_insert.solar_ppatermyrs.alias('solar_ppatermyrs'),
		final_insert.storagecapacity_paymenttermyrs.alias('storagecapacity_paymenttermyrs'),
		final_insert.mainspring_contracttermyrs.alias('mainspring_contracttermyrs'),
		final_insert.chp_contracttermyrs.alias('chp_contracttermyrs'),
		final_insert.evchargers_contracttermyrs.alias('evchargers_contracttermyrs'),
		final_insert.evfleetfinance_contracttermyrs.alias('evfleetfinance_contracttermyrs'),
		final_insert.sustainablewater_contracttermyrs.alias('sustainablewater_contracttermyrs'),
		final_insert.h2electrolyzer_contracttermyrs.alias('h2electrolyzer_contracttermyrs'),
		final_insert.fuelcell_contracttermyrs.alias('fuelcell_contracttermyrs'),
		final_insert.systemlease_termyrs.alias('systemlease_termyrs'),
		final_insert.merchant_termyrs.alias('merchant_termyrs'),
		final_insert.solarppa_escalator.alias('solarppa_escalator'),
		final_insert.storagecapacity_paymentescalator.alias('storagecapacity_paymentescalator'),
		final_insert.mainspring_escalator.alias('mainspring_escalator'),
		final_insert.evchargers_escalator.alias('evchargers_escalator'),
		final_insert.evfleet_financeescalator.alias('evfleet_financeescalator'),
		final_insert.h2electrolyzer_escalator.alias('h2electrolyzer_escalator'),
		final_insert.fuelcell_escalator.alias('fuelcell_escalator'),
		final_insert.systemlease_escalator.alias('systemlease_escalator'),
		final_insert.solarppa_ratemwh.alias('solarppa_ratemwh'),
		final_insert.storagecapacity_paymentratekwmo.alias('storagecapacity_paymentratekwmo'),
		final_insert.mainspring_contractratemwh.alias('mainspring_contractratemwh'),
		final_insert.chpepc_contractratemwh.alias('chpepc_contractratemwh'),
		final_insert.sustainablewater_contractratekgal.alias('sustainablewater_contractratekgal'),
		final_insert.h2electrolyzer_contractratekgh2.alias('h2electrolyzer_contractratekgh2'),
		final_insert.evchargers_contractunits.alias('evchargers_contractunits'),
		final_insert.evfleetfinance_contractunits.alias('evfleetfinance_contractunits'),
		final_insert.evchargers_contractrate.alias('evchargers_contractrate'),
		final_insert.evfleet_financecontractrate.alias('evfleet_financecontractrate'),
		final_insert.fuelcell_contractrate_mwh.alias('fuelcell_contractrate_mwh'),
		final_insert.systemlease_rateyr.alias('systemlease_rateyr'),
		final_insert.neerirr.alias('neerirr'),
		final_insert.teirr.alias('teirr'),
		final_insert.roe_5050.alias('roe_5050'),
		final_insert.npvmm.alias('npvmm'),
		final_insert.wacc.alias('wacc'),
		final_insert.deferral_impact.alias('deferral_impact'),
		final_insert.roe_percentage.alias('roe_percentage'),
		final_insert.batch_id.alias('batch_id'),
		final_insert.source_system.alias('source_system'),
		final_insert.created_by.alias('created_by'),
		final_insert.created_dttm.alias('created_dttm'),
		final_insert.modified_by.alias('modified_by'),
		final_insert.modified_dttm.alias('modified_dttm'),
		final_insert.recordtypeid.alias('recordtypeid')
	)
	
	print("OnComponentOk5 ***")
	OnComponentOk5.select('project_id').filter(col("project_id") == 'a1h5Y00000zm0MJQAY').show()
	staging_path = s3_staging_config+"/output/"+filename+"/staging/"
	staging_file = staging_path+ "stg_file/"
	OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite")
	
	copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_project_raw (project_id, opportunity_id, product_id, project_name, technology, technology_1, technology_2, technology_3, technology_4, capex_chp_epc_mm, capex_evchargers_epc_mm, capex_evfleetvehicles_mm, capex_fuelcell_epc_mm, capex_h2electrolyzer_epc_mm, capex_mainspring_epc_mm, capex_solar_epc_mm, capex_storage_epc_mm, capex_sustainablewater_epc_mm, totalcapex_mm, chpcapacity_mw, evchargerscapacity_mw, fuelcell_capacity_mw, mainspring_capacity_mw, solarcapacity2_mw, solarcapacity_mw, solarsize_mwac, solarsize_mwdc, solaryear1_production_mwh, storage_capacity, storagecapacity2_mw, storageenergy_mw, windcapacity2_mw, othercapitalcosts_mm, interconnection_mm, owner_id, statecode_name, statuscode_name, created_on, solarincentive_termyrs, stage_number, solarsystem_type, sustainable_watercapacity_mmgalyr, solaryield_kwh_kwp, storage_durationhours, water_ratekgal, numberof_evchargers, numberof_evfleetvehicles, h2electrolyzer_capacitykg_h2day, development_feemm, opex_solaryr, opex_storageyr, opex_mainspringyr, opex_chpepcyr, opex_sustainablewateryr, opex_evchargersyr, opex_evfleetvehiclesyr, opex_h2electrolyzeryr, opex_fuelcellyr, sitelease_rateacre, sitelease_escalation, sitelease_termyrs, solar_ppatermyrs, storagecapacity_paymenttermyrs, mainspring_contracttermyrs, chp_contracttermyrs, evchargers_contracttermyrs, evfleetfinance_contracttermyrs, sustainablewater_contracttermyrs, h2electrolyzer_contracttermyrs, fuelcell_contracttermyrs, systemlease_termyrs, merchant_termyrs, solarppa_escalator, storagecapacity_paymentescalator, mainspring_escalator, evchargers_escalator, evfleet_financeescalator, h2electrolyzer_escalator, fuelcell_escalator, systemlease_escalator, solarppa_ratemwh, storagecapacity_paymentratekwmo, mainspring_contractratemwh, chpepc_contractratemwh, sustainablewater_contractratekgal, h2electrolyzer_contractratekgh2, evchargers_contractunits, evfleetfinance_contractunits, evchargers_contractrate, evfleet_financecontractrate, fuelcell_contractrate_mwh, systemlease_rateyr, neerirr, teirr, roe_5050, npvmm, wacc, deferral_impact, roe_percentage, batch_id, source_system, created_by, created_dttm, modified_by, modified_dttm, recordtypeid) FROM 
	'{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100"""  
	
	statement = connection.createStatement()
	statement.executeUpdate(copy_query1)
	statement.close()
	
	sql_statement = f"""UPDATE vendor_customer_opportunities_raw.sfdc_neercrm_project_raw
	SET project_id = stg_sfdc_neercrm_project_raw.project_id
	,opportunity_id = stg_sfdc_neercrm_project_raw.opportunity_id
	,product_id = stg_sfdc_neercrm_project_raw.product_id
	,project_name = stg_sfdc_neercrm_project_raw.project_name
	,technology = stg_sfdc_neercrm_project_raw.technology
	,technology_1 = stg_sfdc_neercrm_project_raw.technology_1
	,technology_2 = stg_sfdc_neercrm_project_raw.technology_2
	,technology_3 = stg_sfdc_neercrm_project_raw.technology_3
	,technology_4 = stg_sfdc_neercrm_project_raw.technology_4
	,capex_chp_epc_mm = stg_sfdc_neercrm_project_raw.capex_chp_epc_mm
	,capex_evchargers_epc_mm = stg_sfdc_neercrm_project_raw.capex_evchargers_epc_mm
	,capex_evfleetvehicles_mm = stg_sfdc_neercrm_project_raw.capex_evfleetvehicles_mm
	,capex_h2electrolyzer_epc_mm = stg_sfdc_neercrm_project_raw.capex_h2electrolyzer_epc_mm
	,capex_mainspring_epc_mm = stg_sfdc_neercrm_project_raw.capex_mainspring_epc_mm
	,capex_solar_epc_mm = stg_sfdc_neercrm_project_raw.capex_solar_epc_mm
	,capex_storage_epc_mm = stg_sfdc_neercrm_project_raw.capex_storage_epc_mm
	,capex_sustainablewater_epc_mm = stg_sfdc_neercrm_project_raw.capex_sustainablewater_epc_mm
	,totalcapex_mm = stg_sfdc_neercrm_project_raw.totalcapex_mm
	,chpcapacity_mw = stg_sfdc_neercrm_project_raw.chpcapacity_mw
	,evchargerscapacity_mw = stg_sfdc_neercrm_project_raw.evchargerscapacity_mw
	,fuelcell_capacity_mw = stg_sfdc_neercrm_project_raw.fuelcell_capacity_mw
	,mainspring_capacity_mw = stg_sfdc_neercrm_project_raw.mainspring_capacity_mw
	,solarcapacity2_mw = stg_sfdc_neercrm_project_raw.solarcapacity2_mw
	,solarcapacity_mw = stg_sfdc_neercrm_project_raw.solarcapacity_mw
	,solarsize_mwac = stg_sfdc_neercrm_project_raw.solarsize_mwac
	,solarsize_mwdc = stg_sfdc_neercrm_project_raw.solarsize_mwdc
	,solaryear1_production_mwh = stg_sfdc_neercrm_project_raw.solaryear1_production_mwh
	,storage_capacity = stg_sfdc_neercrm_project_raw.storage_capacity
	,storagecapacity2_mw = stg_sfdc_neercrm_project_raw.storagecapacity2_mw
	,storageenergy_mw = stg_sfdc_neercrm_project_raw.storageenergy_mw
	,windcapacity2_mw = stg_sfdc_neercrm_project_raw.windcapacity2_mw
	,othercapitalcosts_mm = stg_sfdc_neercrm_project_raw.othercapitalcosts_mm
	,interconnection_mm = stg_sfdc_neercrm_project_raw.interconnection_mm
	,owner_id = stg_sfdc_neercrm_project_raw.owner_id
	,statecode_name = stg_sfdc_neercrm_project_raw.statecode_name
	,statuscode_name = stg_sfdc_neercrm_project_raw.statuscode_name
	,created_on = stg_sfdc_neercrm_project_raw.created_on
	,solarincentive_termyrs = stg_sfdc_neercrm_project_raw.solarincentive_termyrs
	,stage_number = stg_sfdc_neercrm_project_raw.stage_number
	,solarsystem_type = stg_sfdc_neercrm_project_raw.solarsystem_type
	,sustainable_watercapacity_mmgalyr = stg_sfdc_neercrm_project_raw.sustainable_watercapacity_mmgalyr
	,solaryield_kwh_kwp = stg_sfdc_neercrm_project_raw.solaryield_kwh_kwp
	,storage_durationhours = stg_sfdc_neercrm_project_raw.storage_durationhours
	,water_ratekgal = stg_sfdc_neercrm_project_raw.water_ratekgal
	,numberof_evchargers = stg_sfdc_neercrm_project_raw.numberof_evchargers
	,numberof_evfleetvehicles = stg_sfdc_neercrm_project_raw.numberof_evfleetvehicles
	,h2electrolyzer_capacitykg_h2day = stg_sfdc_neercrm_project_raw.h2electrolyzer_capacitykg_h2day
	,development_feemm = stg_sfdc_neercrm_project_raw.development_feemm
	,opex_solaryr = stg_sfdc_neercrm_project_raw.opex_solaryr
	,opex_storageyr = stg_sfdc_neercrm_project_raw.opex_storageyr
	,opex_mainspringyr = stg_sfdc_neercrm_project_raw.opex_mainspringyr
	,opex_chpepcyr = stg_sfdc_neercrm_project_raw.opex_chpepcyr
	,opex_sustainablewateryr = stg_sfdc_neercrm_project_raw.opex_sustainablewateryr
	,opex_evchargersyr = stg_sfdc_neercrm_project_raw.opex_evchargersyr
	,opex_evfleetvehiclesyr = stg_sfdc_neercrm_project_raw.opex_evfleetvehiclesyr
	,opex_h2electrolyzeryr = stg_sfdc_neercrm_project_raw.opex_h2electrolyzeryr
	,opex_fuelcellyr = stg_sfdc_neercrm_project_raw.opex_fuelcellyr
	,sitelease_rateacre = stg_sfdc_neercrm_project_raw.sitelease_rateacre
	,sitelease_escalation = stg_sfdc_neercrm_project_raw.sitelease_escalation
	,sitelease_termyrs = stg_sfdc_neercrm_project_raw.sitelease_termyrs
	,solar_ppatermyrs = stg_sfdc_neercrm_project_raw.solar_ppatermyrs
	,storagecapacity_paymenttermyrs = stg_sfdc_neercrm_project_raw.storagecapacity_paymenttermyrs
	,mainspring_contracttermyrs = stg_sfdc_neercrm_project_raw.mainspring_contracttermyrs
	,chp_contracttermyrs = stg_sfdc_neercrm_project_raw.chp_contracttermyrs
	,evchargers_contracttermyrs = stg_sfdc_neercrm_project_raw.evchargers_contracttermyrs
	,evfleetfinance_contracttermyrs = stg_sfdc_neercrm_project_raw.evfleetfinance_contracttermyrs
	,sustainablewater_contracttermyrs = stg_sfdc_neercrm_project_raw.sustainablewater_contracttermyrs
	,h2electrolyzer_contracttermyrs = stg_sfdc_neercrm_project_raw.h2electrolyzer_contracttermyrs
	,fuelcell_contracttermyrs = stg_sfdc_neercrm_project_raw.fuelcell_contracttermyrs
	,systemlease_termyrs = stg_sfdc_neercrm_project_raw.systemlease_termyrs
	,merchant_termyrs = stg_sfdc_neercrm_project_raw.merchant_termyrs
	,solarppa_escalator = stg_sfdc_neercrm_project_raw.solarppa_escalator
	,storagecapacity_paymentescalator = stg_sfdc_neercrm_project_raw.storagecapacity_paymentescalator
	,mainspring_escalator = stg_sfdc_neercrm_project_raw.mainspring_escalator
	,evchargers_escalator = stg_sfdc_neercrm_project_raw.evchargers_escalator
	,evfleet_financeescalator = stg_sfdc_neercrm_project_raw.evfleet_financeescalator
	,h2electrolyzer_escalator = stg_sfdc_neercrm_project_raw.h2electrolyzer_escalator
	,fuelcell_escalator = stg_sfdc_neercrm_project_raw.fuelcell_escalator
	,systemlease_escalator = stg_sfdc_neercrm_project_raw.systemlease_escalator
	,solarppa_ratemwh = stg_sfdc_neercrm_project_raw.solarppa_ratemwh
	,storagecapacity_paymentratekwmo = stg_sfdc_neercrm_project_raw.storagecapacity_paymentratekwmo
	,mainspring_contractratemwh = stg_sfdc_neercrm_project_raw.mainspring_contractratemwh
	,chpepc_contractratemwh = stg_sfdc_neercrm_project_raw.chpepc_contractratemwh
	,sustainablewater_contractratekgal = stg_sfdc_neercrm_project_raw.sustainablewater_contractratekgal
	,h2electrolyzer_contractratekgh2 = stg_sfdc_neercrm_project_raw.h2electrolyzer_contractratekgh2
	,evchargers_contractunits = stg_sfdc_neercrm_project_raw.evchargers_contractunits
	,evfleetfinance_contractunits = stg_sfdc_neercrm_project_raw.evfleetfinance_contractunits
	,evchargers_contractrate = stg_sfdc_neercrm_project_raw.evchargers_contractrate
	,evfleet_financecontractrate = stg_sfdc_neercrm_project_raw.evfleet_financecontractrate
	,fuelcell_contractrate_mwh = stg_sfdc_neercrm_project_raw.fuelcell_contractrate_mwh
	,systemlease_rateyr = stg_sfdc_neercrm_project_raw.systemlease_rateyr
	,neerirr = stg_sfdc_neercrm_project_raw.neerirr
	,teirr = stg_sfdc_neercrm_project_raw.teirr
	,roe_5050 = stg_sfdc_neercrm_project_raw.roe_5050
	,npvmm = stg_sfdc_neercrm_project_raw.npvmm
	,wacc = stg_sfdc_neercrm_project_raw.wacc
	,deferral_impact = stg_sfdc_neercrm_project_raw.deferral_impact
	,roe_percentage = stg_sfdc_neercrm_project_raw.roe_percentage
	,batch_id = stg_sfdc_neercrm_project_raw.batch_id
	,source_system = stg_sfdc_neercrm_project_raw.source_system
	,created_by = stg_sfdc_neercrm_project_raw.created_by
	,created_dttm = stg_sfdc_neercrm_project_raw.created_dttm
	,modified_by = stg_sfdc_neercrm_project_raw.modified_by
	,modified_dttm = stg_sfdc_neercrm_project_raw.modified_dttm
	,recordtypeid=stg_sfdc_neercrm_project_raw.recordtypeid
	FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_project_raw
	WHERE sfdc_neercrm_project_raw.opportunity_id = stg_sfdc_neercrm_project_raw.opportunity_id 
	AND sfdc_neercrm_project_raw.product_id = stg_sfdc_neercrm_project_raw.product_id"""
	
	statement = connection.createStatement()
	statement.executeUpdate(sql_statement)
	statement.close()
	
	sql_statement1 = f"""INSERT INTO vendor_customer_opportunities_raw.sfdc_neercrm_project_raw
	SELECT stg_sfdc_neercrm_project_raw.*
	FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_project_raw
	LEFT JOIN vendor_customer_opportunities_raw.sfdc_neercrm_project_raw
	ON sfdc_neercrm_project_raw.opportunity_id = stg_sfdc_neercrm_project_raw.opportunity_id 
	AND sfdc_neercrm_project_raw.product_id = stg_sfdc_neercrm_project_raw.product_id 
	WHERE sfdc_neercrm_project_raw.opportunity_id  IS NULL
	AND sfdc_neercrm_project_raw.product_id  IS NULL"""

	statement = connection.createStatement()
	statement.executeUpdate(sql_statement1)
	statement.close()
	
	count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_project_raw)"""
	
	redshift_spark_df = spark.read.jdbc(
		redshift_jdbc_url, count_query, properties=redshift_properties)
	count_final = redshift_spark_df.count()
	
	job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
	batch_status = 'Batch Successful'
	
	update_audit = f"""Update vendor_customer_opportunities_raw.edp_axis_batch_control_log set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='{batch_status}', records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """
	
	statement = connection.createStatement()
	statement.executeUpdate(update_audit)
	statement.close()
	
	sql_statement2 = f"""(INSERT INTO vendor_customer_opportunities_raw.neercrm_project_snapshot
	SELECT 
	COALESCE(project_id,'')                             
	,opportunity_id                                
	,project_name                                  
	,technology                                    
	,technology_1                                  
	,technology_2                                  
	,technology_3                                  
	,technology_4                                  
	,capex_chp_epc_mm                              
	,capex_evchargers_epc_mm                       
	,capex_evfleetvehicles_mm                      
	,capex_fuelcell_epc_mm                         
	,capex_h2electrolyzer_epc_mm                   
	,capex_mainspring_epc_mm                       
	,capex_solar_epc_mm                            
	,capex_storage_epc_mm                          
	,capex_sustainablewater_epc_mm                 
	,totalcapex_mm                                 
	,chpcapacity_mw                                
	,evchargerscapacity_mw                         
	,fuelcell_capacity_mw                          
	,mainspring_capacity_mw                        
	,solarcapacity2_mw                             
	,solarcapacity_mw                              
	,solarsize_mwac                                
	,solarsize_mwdc                                
	,solaryear1_production_mwh                     
	,storage_capacity                               
	,storagecapacity2_mw                           
	,storageenergy_mw                              
	,windcapacity2_mw                              
	,othercapitalcosts_mm                          
	,interconnection_mm
	,owner_id
	,statecode_name
	,statuscode_name
	,created_on 
	,solarincentive_termyrs 
	,stage_number 
	,solarsystem_type 
	,sustainable_watercapacity_mmgalyr 
	,solaryield_kwh_kwp 
	,storage_durationhours 
	,water_ratekgal 
	,numberof_evchargers 
	,numberof_evfleetvehicles 
	,h2electrolyzer_capacitykg_h2day 
	,development_feemm 
	,opex_solaryr 
	,opex_storageyr 
	,opex_mainspringyr 
	,opex_chpepcyr 
	,opex_sustainablewateryr 
	,opex_evchargersyr 
	,opex_evfleetvehiclesyr 
	,opex_h2electrolyzeryr 
	,opex_fuelcellyr 
	,sitelease_rateacre 
	,sitelease_escalation 
	,sitelease_termyrs 
	,solar_ppatermyrs 
	,storagecapacity_paymenttermyrs 
	,mainspring_contracttermyrs 
	,chp_contracttermyrs 
	,evchargers_contracttermyrs 
	,evfleetfinance_contracttermyrs 
	,sustainablewater_contracttermyrs 
	,h2electrolyzer_contracttermyrs 
	,fuelcell_contracttermyrs 
	,systemlease_termyrs 
	,merchant_termyrs 
	,solarppa_escalator 
	,storagecapacity_paymentescalator 
	,mainspring_escalator 
	,evchargers_escalator 
	,evfleet_financeescalator 
	,h2electrolyzer_escalator 
	,fuelcell_escalator 
	,systemlease_escalator 
	,solarppa_ratemwh 
	,storagecapacity_paymentratekwmo 
	,mainspring_contractratemwh 
	,chpepc_contractratemwh 
	,sustainablewater_contractratekgal 
	,h2electrolyzer_contractratekgh2 
	,evchargers_contractunits 
	,evfleetfinance_contractunits 
	,evchargers_contractrate 
	,evfleet_financecontractrate 
	,fuelcell_contractrate_mwh 
	,systemlease_rateyr 
	,neerirr 
	,teirr 
	,roe_5050 
	,npvmm 
	,wacc 
	,deferral_impact 
	,roe_percentage 
	,batch_id                                      
	,source_system                                 
	,created_by                                    
	,created_dttm                                  
	,modified_by                                   
	,modified_dttm                                                              
	,current_timestamp as snapshot_dt,
	recordtypeid
	FROM vendor_customer_opportunities_raw.sfdc_neercrm_project_raw)"""
	
	statement1 = connection.createStatement()
	statement1.close()
	
	#On successful export of data to redshift, generating success email content.
	email_content = generate_email_body("success")
	email_sub = email_content[0]
	email_body = email_content[1]
	cloudwatch.log_to_stream("Publishing SNS email")
	# Calling SNS publish function to publish email to end-subscribers
	status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
	if status_code == 200:
		cloudwatch.log_to_stream("Success Email sent successfully")
	else:
		cloudwatch.log_to_stream(
			f"Success Email not sent, with error_code = {status_code}"
		)
	logger.info("Script executed successfully......  check data in redshift")

	cloudwatch.log_to_stream(
		"Writing  data to redshift has been successfully done.."
	)
	job.commit()
except Exception as e:
	logger.info(f"Job failed with following error ......{e}")
	cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
	error = str(e).replace("'", '"')
	email_content = generate_email_body("failure")
	email_sub = email_content[0]
	email_body = email_content[1]
	status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
	if status_code == 200:
		cloudwatch.log_to_stream("Failure Email sent successfully")
	else:
		cloudwatch.log_to_stream(
			f"Failure Email not sent, with error_code = {status_code}"
		)
	error_message = f"Job failed with following error: {str(e)}"
	logger.info(error_message)
	cloudwatch.log_to_stream(error_message)
	sns_publish(
		sns_arn,
		"Glue Job Failure",
		f"{job_name} failed with error: {str(e)}"
	)
	raise e
