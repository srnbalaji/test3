import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim, expr, col, udf, when, lit
from pyspark.sql.types import StringType, DateType
from pyspark.sql.functions import trim
from pyspark.sql import functions as F


args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]


environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")
redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_NEERCRM_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_db_table = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

try:
    redshift_properties = spark._jvm.java.util.Properties()
    redshift_properties.setProperty("url", redshift_jdbc_url)
    redshift_properties.setProperty("dbtable", redshift_db_table)
    redshift_properties.setProperty("user", redshift_user)
    redshift_properties.setProperty("password", redshift_password)
    redshift_properties.setProperty("TempDir", redshift_temp_dir)
    redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
    redshift_properties.setProperty("connectionName", redshift_connection_name)
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    
    #batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]

    var_Global_Source_System_Owner = 'Salesforce_NEERCRM_Owner'
    
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'sfdc_neercrm_account_raw') custom"""
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
    print("last load date ",redshift_last_load_dt)
    '''insert_audit = f"""INSERT INTO vendor_customer_opportunities_raw.edp_axis_batch_control_log(batch_id 	,batch_start_dttm 	,batch_status ,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone ,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH2:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()'''
    
    query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_activity_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    row1 = spark.read.option("multiline","True").json(staging_path)
    
    '''row1 = row1.withColumnRenamed(row1.columns[0],'WhatId')\
    	.withColumnRenamed(row1.columns[1],'Subject')\
    	.withColumnRenamed(row1.columns[2],'Description')\
    	.withColumnRenamed(row1.columns[3],'CreatedDate')\
    	.withColumnRenamed(row1.columns[4],'CreatedById')\
    	.withColumnRenamed(row1.columns[5],'LastModifiedDate')\
    	.withColumnRenamed(row1.columns[6],'MSCRM_Activity_ID__c')\
    	.withColumnRenamed(row1.columns[7],'Id')'''
    
    row1 = row1.withColumn("batch_id",lit(batch_id))\
                .withColumn("source_system",lit(source_system))\
                .withColumn("created_by",lit(created_by))\
                .withColumn("modified_by",lit(modified_by))\
                .withColumn("created_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("modified_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))
    
    row1 = row1.withColumn("createdbyid",F.regexp_replace(col('CreatedById'),'\{|\}', ''))\
    .withColumn("subject",F.upper(trim(col("Subject"))))\
    .withColumn("Description", F.regexp_replace(col("Description"), "", ''))\
    .withColumn("Subject1", F.regexp_replace(col("Subject"),"",""))
    
    # Define the dataframe
    insert = row1.select(trim(expr("substr(Id,1,530)")).alias('system_id'),
            trim(expr("substr(WhatId,1,36)")).alias('account_id'),
            expr("substr(subject1,1,530)").alias('name'),
            trim(expr("substr(Description,1,64000)")).alias('description'),
            expr("substr(createdbyid,0,36)").alias('lead'),
            expr("substr(WhatId,1,36)").alias('what_id'),
            lit(var_Global_Source_System_Owner).alias('owner'),
            lit("NULL").alias('type'),
            (when(col("CreatedDate") == lit(""), lit(None)).otherwise(date_format(col("CreatedDate"), "yyyy-MM-dd HH:mm:ss.SSSZ"))).alias('activity_date'),
            row1.batch_id.alias('batch_id'),
            row1.source_system.alias('source_system'),
            row1.created_by.alias('created_by'),
            row1.created_dttm.alias('created_dttm'),
            row1.modified_by.alias('modified_by'),
            row1.modified_dttm.alias('modified_dttm'))
    
    OnComponentOk5 = insert.select(
    	insert.system_id.alias('system_id'),
    	insert.account_id.alias('account_id'),
    	insert.name.alias('name'),
    	insert.description.alias('description'),
    	insert.lead.alias('lead'),
    	insert.what_id.alias('what_id'),
    	insert.owner.alias('owner'),
    	insert.type.alias('type'),
    	insert.activity_date.alias('activity_date'),
    	insert.batch_id.alias('batch_id'),
    	insert.source_system.alias('source_system'),
    	insert.created_by.alias('created_by'),
    	insert.created_dttm.alias('created_dttm'),
    	insert.modified_by.alias('modified_by'),
    	insert.modified_dttm.alias('modified_dttm'))
    #OnComponentOk5.show()

    #print("test data follows...")
    #OnComponentOk5.filter(OnComponentOk5.system_id=="00T5Y00009OhL56UAF").select("name").show(truncate=False)
    #print(OnComponentOk5.filter(OnComponentOk5.system_id=="00T5Y00009OhL56UAF").select("name"))
    
    
    
    #staging_file = staging_path+ "stg_file/"
    #OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite").option("quote","\"")
    #OnComponentOk5.write.option("sep", "|").option("header", "true").mode("overwrite").option("quote", "\"").csv(path=staging_file)
    #staging_file = staging_path+ "stg_json_file/"
    #OnComponentOk5.write.json(staging_file, mode="overwrite")

    #staging_file = staging_path+ "stg_file/"
    staging_file = staging_path+ "stg_json_file/"
    OnComponentOk5.write.json(staging_file, mode="overwrite")
    #OnComponentOk5.write.csv(path=staging_file, sep='|', quote='"', escape='\\', header=True, mode="overwrite")
    

    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_activity_raw (system_id,account_id,name,description,lead,what_id,owner,type,activity_date,batch_id,source_system,created_by,created_dttm,modified_by,modified_dttm)   
        FROM '{staging_file}' iam_role '{iam_role}' FORMAT AS JSON 'auto' TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""
#    	FROM '{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' emptyasnull blanksasnull IGNOREHEADER 1 MAXERROR 1000"""

	
	#FROM '{staging_file}' iam_role '{iam_role}' FORMAT AS JSON 'auto' TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""

#        FROM '{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100"""   

    statement = connection.createStatement()
    cloudwatch.log_to_stream(f"copy_query1 : {copy_query1}")
    statement.executeUpdate(copy_query1)
    statement.close()
    
    count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_activity_raw)"""
    
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    
    print(" COPY query count --> ",count_final)
    
    
    trg_tb_query = f"""(Select table_name, column_name, ordinal_position from information_schema.columns
            where table_schema =lower( '{target_db_schema}') AND table_name=lower('{target_db_table}'))custom"""

    trg_tb = spark.read.jdbc(
        redshift_jdbc_url, trg_tb_query, properties=redshift_properties
    )
    
    trg_tb.write.csv(path=staging_path + "/trg_tb", sep=",", header=True, mode="overwrite")
    
    target_schem_df = spark.read.csv(path=staging_path + "/trg_tb", header=True, inferSchema=True)

    trg_clnm = target_schem_df.filter(target_schem_df['ordinal_position'] == 1)
    
    target_key_column = trg_clnm.select("column_name").first().column_name

    trg_clms_list = target_schem_df.select(collect_list("column_name")).first()[0]

    stg_tb_query = f"""(Select table_name, column_name, ordinal_position from information_schema.columns
            where table_schema =lower('{staging_table_schema}') AND TABLE_NAME=lower('{staging_table_name}'))custom"""

    stg_tb = spark.read.jdbc(
        redshift_jdbc_url, stg_tb_query, properties=redshift_properties
    )
    
    stg_tb.write.csv(path=staging_path + "/stg_tb", sep=",", header=True, mode="overwrite")
    
    stg_schem_df = spark.read.csv(path=staging_path + "/stg_tb", header=True, inferSchema=True)

    stg_clnm = stg_schem_df.filter(stg_schem_df['ordinal_position'] == 1)
    
    stg_key_column = stg_clnm.select("column_name").first().column_name

    stg_clms_list = stg_schem_df.select(collect_list("column_name")).first()[0]
    
    job_curr_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S.%f')[:-3]

    def perform_update_to_target_table(target_db_schema,target_db_table,target_key_column,staging_table_schema,staging_table_name,stg_key_column,stg_clms_list,trg_clms_list,redshift_properties):
        try:
            connection = spark._jvm.java.sql.DriverManager.getConnection(
                redshift_jdbc_url, redshift_properties
            )
            statement = connection.createStatement()
        
            cloudwatch.log_to_stream("About to run the delete query..")
            #  Execute DELETE statement
            delete_sql = f"""
                DELETE FROM {target_db_schema}.{target_db_table}
                USING {staging_table_schema}.{staging_table_name}
                WHERE {target_db_table}.{target_key_column} = {staging_table_name}.{stg_key_column}; 
            """
            statement.executeUpdate(delete_sql)
        
            connection.close()
        
            cloudwatch.log_to_stream("executed the delete statement..")
        
            connection1 = spark._jvm.java.sql.DriverManager.getConnection(
                redshift_jdbc_url, redshift_properties
            )
        
            statement1 = connection1.createStatement()

            # Generate INSERT SQL dynamically with handling column mismatch
            insert_sql = f"""
                INSERT INTO {target_db_schema}.{target_db_table} ({','.join(trg_clms_list)})
                SELECT  
            """
            for col in trg_clms_list:
                if col == "etl_insrt_dttm" or col == "etl_upd_dttm":
                    insert_sql += f"""'{job_curr_dttm}' AS {col},"""
                elif col == "etl_insrt_usr_id" or col == "etl_upd_usr_id":
                    insert_sql += "'PMI_Opportunity_Group' AS " + col + ","
                else:
                    insert_sql += col + ","

            insert_sql = insert_sql.rstrip(",")  # Remove trailing comma
            insert_sql += f"\n FROM {staging_table_schema}.{staging_table_name};"
        
            cloudwatch.log_to_stream(insert_sql)
            statement1.executeUpdate(insert_sql)

            # Close connection
            statement1.close()
            connection1.close()

        except Exception as e:
            print("An error occurred:", str(e))


    redshift_properties.setProperty("dbtable", redshift_db_table)
    perform_update_to_target_table(
        target_db_schema,
        target_db_table,
        target_key_column,
        staging_table_schema,
        staging_table_name,
        stg_key_column,
        stg_clms_list,
        trg_clms_list,
        redshift_properties
    )

    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_status = 'Batch Successful'
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
      
    # On successful export of maximo data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
    logger.info("Script executed successfully......  check data in redshift")

    cloudwatch.log_to_stream("Writing  data to redshift has been successfully done..")
    job.commit()
except Exception as e:
    logger.info(f"Job failed with following error ......{e}")
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', batch_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
    error_message = f"Job failed with following error: {str(e)}"
    logger.info(error_message)
    cloudwatch.log_to_stream(error_message)
    sns_publish(sns_arn,"Glue Job Failure",f"{job_name} failed with error: {str(e)}")
    raise e
