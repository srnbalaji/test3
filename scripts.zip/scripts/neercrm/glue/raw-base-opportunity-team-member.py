import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_NEERCRM_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_dbtable = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

redshift_properties = spark._jvm.java.util.Properties()
redshift_properties.setProperty("url", redshift_jdbc_url)
redshift_properties.setProperty("dbtable", redshift_dbtable)
redshift_properties.setProperty("user", redshift_user)
redshift_properties.setProperty("password", redshift_password)
redshift_properties.setProperty("TempDir", redshift_temp_dir)
redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
redshift_properties.setProperty("connectionName", redshift_connection_name)

try:
    
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    
    #batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    
    Output_Count = 0
    
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'sfdc_neercrm_opportunity_team_member_raw') custom"""
               
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
	
    '''insert_audit = f"""INSERT INTO vendor_customer_opportunities_raw.edp_axis_batch_control_log(batch_id 	,batch_start_dttm 	,batch_status 	,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone 	,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()'''
    
    
    query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_team_member_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    query1 = f"""DELETE FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_team_member_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query1)
    statement.close()
    
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    row1 = spark.read.option("multiline","True").json(staging_path)
    print("row1 count -->",row1.count())
    '''row1 = row1.withColumnRenamed(row1.columns[0],'OpportunityId')\
    	.withColumnRenamed(row1.columns[1],'TeamMemberRole')\
    	.withColumnRenamed(row1.columns[2],'LastModifiedDate')\
    	.withColumnRenamed(row1.columns[3],'NCRM_User_Id__c')\
    	.withColumnRenamed(row1.columns[4],'Name')'''

    insert = row1.withColumn("Business_Manager_ID", when ( row1.TeamMemberRole == lit("Business Manager") , row1.NCRM_User_Id__c )) \
    .withColumn("Business_Manager_Name", when ( row1.TeamMemberRole == lit("Business Manager") , row1.Name )) \
    .withColumn("Originator_ID", when ( row1.TeamMemberRole == lit("Originator") , row1.NCRM_User_Id__c )) \
    .withColumn("Originator_Name", when ( row1.TeamMemberRole == lit("Originator") , row1.Name )) \
    .select(trim(expr("substr(OpportunityId,1,18)")).alias('OpportunityId'),
    	trim(expr("substr(Business_Manager_ID,1,40)")).alias('businessdevelopment_id'),
    	col("Business_Manager_Name").alias('businessdevelopment_name'),
    	trim(expr("substr(Originator_ID,1,40)")).alias('cioriginator_id'),
    	col("Originator_Name").alias('cioriginator_name')
    	)
    print("Insert data into dataframe :")
    
    print("row1 count -->",insert.count())

    row2 = insert.groupBy("OpportunityId").agg(
    	first('businessdevelopment_id').alias("businessdevelopment_id"),
    	first('businessdevelopment_name').alias("businessdevelopment_name"),
    	first('cioriginator_name').alias("cioriginator_name"),
    	first('cioriginator_id').alias("cioriginator_id"),
    	count('OpportunityId').alias("Count"))
    	
    print(" row2 data .....")
    row2.select('Count').show()
    print("row1 count -->",row2.count())

    row2 = row2.withColumn("batch_id",lit(batch_id))\
                .withColumn("source_system",lit(source_system))\
                .withColumn("created_by",lit(created_by))\
                .withColumn("modified_by",lit(modified_by))\
                .withColumn("created_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("modified_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))

    Final = row2.withColumn("var1",  Output_Count + row2.Count).select(
    	row2.OpportunityId.alias('OpportunityId'),
    	row2.businessdevelopment_id.alias('businessdevelopment_id'),
    	row2.businessdevelopment_name.alias('businessdevelopment_name'),
    	row2.cioriginator_id.alias('cioriginator_id'),
    	row2.cioriginator_name.alias('cioriginator_name'),
    	row2.batch_id.alias('batch_id'),
    	row2.source_system.alias('source_system'),
    	row2.created_by.alias('created_by'),
    	row2.created_dttm.alias('created_dttm'),
    	row2.modified_by.alias('modified_by'),
		row2.modified_dttm.alias('modified_dttm')
    )
    
    print("Final count -->",Final.count())

    OnComponentOk5 = Final.select(
    	Final.OpportunityId.alias('OpportunityId'),
    	Final.businessdevelopment_id.alias('businessdevelopment_id'),
    	Final.businessdevelopment_name.alias('businessdevelopment_name'),
    	Final.cioriginator_id.alias('cioriginator_id'),
    	Final.cioriginator_name.alias('cioriginator_name'),
    	Final.batch_id.alias('batch_id'),
    	Final.source_system.alias('source_system'),
    	Final.created_by.alias('created_by'),
    	Final.created_dttm.alias('created_dttm'),
    	Final.modified_by.alias('modified_by'),
    	Final.modified_dttm.alias('modified_dttm')
    )
    
    print("OnComponentOk5 count -->",OnComponentOk5.count())
    staging_file = staging_path+ "stg_file/"
    OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite")
    
    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_team_member_raw FROM 
    '{staging_file}' iam_role '{iam_role}' 
    FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100"""   
    statement = connection.createStatement()
    statement.executeUpdate(copy_query1)
    statement.close()
    
    count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_team_member_raw)"""
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    insert_query = f"""INSERT INTO vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_team_member_raw
    SELECT stg_sfdc_neercrm_opportunity_team_member_raw.*
    FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_team_member_raw"""   
    statement = connection.createStatement()
    statement.executeUpdate(insert_query)
    statement.close()
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_status = 'Batch Successful'
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    # On successful export of maximo data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Success Email not sent, with error_code = {status_code}"
        )
    logger.info("Script executed successfully......  check data in redshift")

    cloudwatch.log_to_stream(
        "Writing  data to redshift has been successfully done.."
    )
    job.commit()
except Exception as e:
    logger.info(f"Job failed with following error ......{e}")
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', batch_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Failure Email not sent, with error_code = {status_code}"
        )
    error_message = f"Job failed with following error: {str(e)}"
    logger.info(error_message)
    cloudwatch.log_to_stream(error_message)
    sns_publish(
        sns_arn,
        "Glue Job Failure",
        f"{job_name} failed with error: {str(e)}"
    )
    raise e