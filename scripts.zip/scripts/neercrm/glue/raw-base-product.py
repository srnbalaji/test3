import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit,trim, to_utc_timestamp
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_dbtable = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"
redshift_properties = spark._jvm.java.util.Properties()
redshift_properties.setProperty("url", redshift_jdbc_url)
redshift_properties.setProperty("dbtable", redshift_dbtable)
redshift_properties.setProperty("user", redshift_user)
redshift_properties.setProperty("password", redshift_password)
redshift_properties.setProperty("TempDir", redshift_temp_dir)
redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
redshift_properties.setProperty("connectionName", redshift_connection_name)

try:
    
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    
    #batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'sfdc_neercrm_product_raw') custom"""
    
    
	
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
    
    '''insert_audit = f"""INSERT INTO vendor_customer_opportunities_raw.edp_axis_batch_control_log(batch_id 	,batch_start_dttm 	,batch_status 	,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone 	,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()'''
    
    
    query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_product_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    query1 = f"""DELETE FROM vendor_customer_opportunities_raw.sfdc_neercrm_product_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query1)
    statement.close()
    
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    cloudwatch.log_to_stream(f" source s3 path is : {staging_path}")
    row1 = spark.read.option("multiline","True").json(staging_path)
    
    '''row1 = row1.withColumnRenamed(row1.columns[0],'CreatedDate')\
    	.withColumnRenamed(row1.columns[1],'RecordTypeID')\
    	.withColumnRenamed(row1.columns[2],'LastModifiedDate')\
    	.withColumnRenamed(row1.columns[3],'NCRM_Broker_FeeMM__c')\
    	.withColumnRenamed(row1.columns[4],'NCRM_Deferral_Impact__c')\
    	.withColumnRenamed(row1.columns[5],'NCRM_NPV__c')\
    	.withColumnRenamed(row1.columns[6],'NCRM_NEER_IRR__c')\
    	.withColumnRenamed(row1.columns[7],'NCRM_Price__c')\
    	.withColumnRenamed(row1.columns[8],'NCRM_State__c')\
    	.withColumnRenamed(row1.columns[9],'NCRM_Term__c')\
    	.withColumnRenamed(row1.columns[10],'NCRM_Volume__c')\
    	.withColumnRenamed(row1.columns[11],'NCRM_CapEx_EPC_MM__c')\
    	.withColumnRenamed(row1.columns[12],'NCRM_InterconnectionMM__c')\
    	.withColumnRenamed(row1.columns[13],'NCRM_Merchant_Term__c')\
    	.withColumnRenamed(row1.columns[14],'NCRM_OpEx__c')\
    	.withColumnRenamed(row1.columns[15],'NCRM_Other_Capital_Costs__c')\
    	.withColumnRenamed(row1.columns[16],'NCRM_System_Lease_Escalation__c')\
    	.withColumnRenamed(row1.columns[17],'NCRM_System_Lease_Rate__c')\
    	.withColumnRenamed(row1.columns[18],'NCRM_Size_MWac__c')\
    	.withColumnRenamed(row1.columns[19],'NCRM_Size_MWdc__c')\
    	.withColumnRenamed(row1.columns[20],'NCRM_Solar_Yield_kwh_kwp__c')\
    	.withColumnRenamed(row1.columns[21],'NCRM_Storage_Duration_hrs__c')\
    	.withColumnRenamed(row1.columns[22],'NCRM_Volume_Chargers__c')\
    	.withColumnRenamed(row1.columns[23],'NCRM_Year1_Production_Mwh__c')\
    	.withColumnRenamed(row1.columns[24],'NCRM_Site_Lease_Escalation__c')\
    	.withColumnRenamed(row1.columns[25],'NCRM_Site_Lease_Rate_acre__c')\
    	.withColumnRenamed(row1.columns[26],'NCRM_Site_Lease_Term_yrs__c')\
    	.withColumnRenamed(row1.columns[27],'NCRM_Tariff_Term_YR__c')\
    	.withColumnRenamed(row1.columns[29],'NCRM_ROE__c')\
    	.withColumnRenamed(row1.columns[30],'NCRM_TE_IRR__c')\
    	.withColumnRenamed(row1.columns[31],'NCRM_WACC__c')\
    	.withColumnRenamed(row1.columns[32],'NCRM_Escalation__c')\
    	.withColumnRenamed(row1.columns[33],'NCRM_System_Type__c')\
    	.withColumnRenamed(row1.columns[34],'NCRM_Opportunity__c')\
    	.withColumnRenamed(row1.columns[35],'NCRM_Est_ITC_COD_Date__c')\
    	.withColumnRenamed(row1.columns[36],'NCRM_Product__c')\
    	.withColumnRenamed(row1.columns[37],'NCRM_Project_Type__c')\
    	.withColumnRenamed(row1.columns[38],'NCRM_Deal_Structure__c')\
    	.withColumnRenamed(row1.columns[39],'NCRM_Project_Name__c')\
    	.withColumnRenamed(row1.columns[40],'NCRM_Total_CapEx__c')\
    	.withColumnRenamed(row1.columns[41],'NCRM_Price_Unit__c')\
    	.withColumnRenamed(row1.columns[42],'NCRM_Project_Results__c')\
    	.withColumnRenamed(row1.columns[43],'NAME')\
    	.withColumnRenamed(row1.columns[44],'ID')'''

    row2 = row1.withColumn("batch_id",lit(batch_id))\
                .withColumn("source_system",lit(source_system))\
                .withColumn("created_by",lit(created_by))\
                .withColumn("modified_by",lit(modified_by))\
                .withColumn("ncrm_volume_unit__c",lit(' '))\
                .withColumn("created_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("modified_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("NCRM_Product__c", F.regexp_replace(col("NCRM_Product__c"), '[^a-zA-Z0-9,.-]', ' '))
    
    row2.select("NCRM_Price__c","NCRM_WACC__c").where(col("NCRM_Price__c").isNotNull()).where(col("NCRM_WACC__c").isNotNull()).show()
    
    insert = row2.select(trim(expr("substr(NCRM_Project_Name__c,1,32)")).alias('NCRM_Project_Name__c'),
    	trim(expr("substr(NCRM_Opportunity__c,1,72)")).alias('NCRM_Opportunity__c'),
    	col("RecordTypeID").alias('RecordTypeID'),
		trim(expr("substr(NCRM_Product__c,1,530)")).alias('NCRM_Product__c'),
    	trim(expr("substr(ID,1,36)")).alias('product_id'),
    	trim(expr("substr(NAME,1,530)")).alias('product_name'),
    	row2.ncrm_volume_unit__c.alias('ncrm_volume_unit__c'),
    	when(
        ((col("NCRM_CapEx_EPC_MM__c").isNull()) | (col("NCRM_CapEx_EPC_MM__c") == "") | (col("NCRM_CapEx_EPC_MM__c") == " ")),
        None
         ).otherwise(col("NCRM_CapEx_EPC_MM__c").cast(DecimalType(18,2))).alias('NCRM_CapEx_EPC_MM__c'),
    	when((row2.NCRM_Total_CapEx__c == None) | (row2.NCRM_Total_CapEx__c == lit("")) | (row2.NCRM_Total_CapEx__c == lit(" ")) , None).otherwise((row2.NCRM_Total_CapEx__c).cast(DecimalType(18,2))).alias('ncrm_total_capex__c'),
    	when((row2.NCRM_Volume__c == None) | (row2.NCRM_Volume__c == lit("")) | (row2.NCRM_Volume__c == lit(" ")) , None) .otherwise((row2.NCRM_Volume__c)).alias('NCRM_Volume__c'),
    	when((row2.NCRM_Size_MWac__c == None) | (row2.NCRM_Size_MWac__c == lit("")) | (row2.NCRM_Size_MWac__c == lit(" ")) , None) .otherwise((row2.NCRM_Size_MWac__c).cast(DecimalType(18,2))).alias('NCRM_size_mwac__c'),
    	when((row2.NCRM_Size_MWdc__c == None) | (row2.NCRM_Size_MWdc__c == lit("")) | (row2.NCRM_Size_MWdc__c == lit(" ")) , None) .otherwise((row2.NCRM_Size_MWdc__c).cast(DecimalType(18,2))).alias('NCRM_size_mwdc__c'),
    	when((row2.NCRM_Year1_Production_Mwh__c == None) | (row2.NCRM_Year1_Production_Mwh__c == lit("")) | (row2.NCRM_Year1_Production_Mwh__c == lit(" ")) , None) .otherwise((row2.NCRM_Year1_Production_Mwh__c).cast(DecimalType(18,2))).alias('NCRM_year1_production_mwh__c'),
    	when((row2.NCRM_Other_Capital_Costs__c == None) | (row2.NCRM_Other_Capital_Costs__c == lit("")) | (row2.NCRM_Other_Capital_Costs__c == lit(" ")) , None) .otherwise((row2.NCRM_Other_Capital_Costs__c).cast(DecimalType(18,2))).alias('NCRM_other_capital_costs__c'),
    	when((row2.NCRM_InterconnectionMM__c == None) | (row2.NCRM_InterconnectionMM__c == lit("")) | (row2.NCRM_InterconnectionMM__c == lit(" ")) , None) .otherwise((row2.NCRM_InterconnectionMM__c).cast(DecimalType(18,2))).alias('NCRM_InterconnectionMM__c'),
		trim(expr("substr(NCRM_State__c,1,530)")).alias('NCRM_State__c'),
    	(when(col("CreatedDate") == lit(""), lit(None)).otherwise(date_format(col("CreatedDate"), "yyyy-MM-dd HH:mm:ss.SSSZ"))).alias('CreatedDate'),
    	#row2.CreatedDate.alias('CreatedDate'),
    	when((row2.NCRM_Tariff_Term_YR__c == None) | (row2.NCRM_Tariff_Term_YR__c == lit("")) | (row2.NCRM_Tariff_Term_YR__c == lit(" ")) , None) .otherwise((row2.NCRM_Tariff_Term_YR__c).cast(DecimalType(16,2))).alias('NCRM_Tariff_Term_YR__c'),
		trim(expr("substr(NCRM_System_Type__c,1,530)")).alias('NCRM_system_type__c'),
    	when((row2.NCRM_Solar_Yield_kwh_kwp__c == None) | (row2.NCRM_Solar_Yield_kwh_kwp__c == lit("")) | (row2.NCRM_Solar_Yield_kwh_kwp__c == lit(" ")) , None).otherwise((row2.NCRM_Solar_Yield_kwh_kwp__c).cast(DecimalType(18,2))).alias('NCRM_solar_yield_kwh_kwp__c'),
        when((row2.NCRM_Storage_Duration_hrs__c == None) | (row2.NCRM_Storage_Duration_hrs__c == lit("")) | (row2.NCRM_Storage_Duration_hrs__c == lit(" ")) , None).otherwise((row2.NCRM_Storage_Duration_hrs__c).cast(DecimalType(18,2))).alias('NCRM_storage_duration_hrs__c'),
        when((row2.NCRM_Price__c == None) | (row2.NCRM_Price__c == lit("")) | (row2.NCRM_Price__c == lit(" ")) , None).otherwise((row2.NCRM_Price__c)).alias('NCRM_Price__c'),
        trim(expr("substr(NCRM_Price_Unit__c,1,530)")).alias('NCRM_Price_Unit__c'),
        when((row2.NCRM_Volume_Chargers__c == None) | (row2.NCRM_Volume_Chargers__c == lit("")) | (row2.NCRM_Volume_Chargers__c == lit(" ")) , None).otherwise((row2.NCRM_Volume_Chargers__c).cast(DecimalType(18,2))).alias('NCRM_Volume_Chargers__c'),
        when((row2.NCRM_Broker_FeeMM__c == None) | (row2.NCRM_Broker_FeeMM__c == lit("")) | (row2.NCRM_Broker_FeeMM__c == lit(" ")) , None).otherwise((row2.NCRM_Broker_FeeMM__c).cast(DecimalType(18,2))).alias('NCRM_Broker_FeeMM__c'),
        when((row2.NCRM_OpEx__c == None) | (row2.NCRM_OpEx__c == lit("")) | (row2.NCRM_OpEx__c == lit(" ")) , None).otherwise((row2.NCRM_OpEx__c).cast(DecimalType(18,2))).alias('NCRM_OpEx__c'),
        when((row2.NCRM_Site_Lease_Rate_acre__c == None) | (row2.NCRM_Site_Lease_Rate_acre__c == lit("")) | (row2.NCRM_Site_Lease_Rate_acre__c == lit(" ")) , None).otherwise((row2.NCRM_Site_Lease_Rate_acre__c).cast(DecimalType(18,2))).alias('NCRM_site_lease_rate_acre__c'),
        when((row2.NCRM_Site_Lease_Escalation__c == None) | (row2.NCRM_Site_Lease_Escalation__c == lit("")) | (row2.NCRM_Site_Lease_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Site_Lease_Escalation__c).cast(DecimalType(18,2))).alias('NCRM_site_lease_escalation__c'),
        when((row2.NCRM_Site_Lease_Term_yrs__c == None) | (row2.NCRM_Site_Lease_Term_yrs__c == lit("")) | (row2.NCRM_Site_Lease_Term_yrs__c == lit(" ")) , None).otherwise((row2.NCRM_Site_Lease_Term_yrs__c).cast(DecimalType(16,2))).alias('NCRM_site_lease_term_yrs__c'),
        when((row2.NCRM_Term__c == None) | (row2.NCRM_Term__c == lit("")) | (row2.NCRM_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Term__c).cast(DecimalType(16,2))).alias('NCRM_Term__c'),
        when((row2.NCRM_Merchant_Term__c == None) | (row2.NCRM_Merchant_Term__c == lit("")) | (row2.NCRM_Merchant_Term__c == lit(" ")) , None).otherwise((row2.NCRM_Merchant_Term__c).cast(DecimalType(16,2))).alias('NCRM_Merchant_Term__c'),
        when((row2.NCRM_Escalation__c == None) | (row2.NCRM_Escalation__c == lit("")) | (row2.NCRM_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_Escalation__c).cast(DecimalType(18,2))).alias('NCRM_Escalation__c'),
        when((row2.NCRM_System_Lease_Escalation__c == None) | (row2.NCRM_System_Lease_Escalation__c == lit("")) | (row2.NCRM_System_Lease_Escalation__c == lit(" ")) , None).otherwise((row2.NCRM_System_Lease_Escalation__c).cast(DecimalType(18,2))).alias('NCRM_System_Lease_Escalation__c'),
        when((row2.NCRM_System_Lease_Rate__c == None) | (row2.NCRM_System_Lease_Rate__c == lit("")) | (row2.NCRM_System_Lease_Rate__c == lit(" ")),None).otherwise((row2.NCRM_System_Lease_Rate__c).cast(DecimalType(18,2))).alias('NCRM_System_Lease_Rate__c'),
        when((row2.NCRM_NEER_IRR__c == None) | (row2.NCRM_NEER_IRR__c == lit("")) | (row2.NCRM_NEER_IRR__c == lit(" ")) , None).otherwise((row2.NCRM_NEER_IRR__c)).alias('NCRM_NEER_IRR__c'),
        when((row2.NCRM_TE_IRR__c == None) | (row2.NCRM_TE_IRR__c == lit("")) | (row2.NCRM_TE_IRR__c == lit(" ")) , None).otherwise((row2.NCRM_TE_IRR__c).cast(DecimalType(18,2))).alias('NCRM_TE_IRR__c'),
        when((row2.NCRM_ROE__c == None) | (row2.NCRM_ROE__c == lit("")) | (row2.NCRM_ROE__c == lit(" ")) , None).otherwise((row2.NCRM_ROE__c).cast(DecimalType(18,2))).alias('NCRM_ROE__c'),
        when((row2.NCRM_NPV__c == None) | (row2.NCRM_NPV__c == lit("")) | (row2.NCRM_NPV__c == lit(" ")) , None).otherwise((row2.NCRM_NPV__c).cast(DecimalType(18,2))).alias('NCRM_NPV__c'),
        when((row2.NCRM_WACC__c == None) | (row2.NCRM_WACC__c == lit("")) | (row2.NCRM_WACC__c == lit(" ")) , None).otherwise((row2.NCRM_WACC__c)).alias('NCRM_wacc__c'),
        when((row2.NCRM_Deferral_Impact__c == None) | (row2.NCRM_Deferral_Impact__c == lit("")) | (row2.NCRM_Deferral_Impact__c == lit(" ")) , None).otherwise((row2.NCRM_Deferral_Impact__c).cast(DecimalType(18,2))).alias('NCRM_Deferral_Impact__c'),
        date_format(to_timestamp(F.when(F.col("NCRM_Est_ITC_COD_Date__c") == " ",None).otherwise(when(F.length(F.col("NCRM_Est_ITC_COD_Date__c")) > 10, row2.NCRM_Est_ITC_COD_Date__c.cast('timestamp')).otherwise(row2.NCRM_Est_ITC_COD_Date__c.cast('timestamp'))),'yyyy-MM-dd HH:mm:ss.SSS Z'),'yyyy-MM-dd HH:mm:ss.SSS Z').alias('NCRM_Est_ITC_COD_Date__c'),
        trim(expr("substr(NCRM_Deal_Structure__c,1,530)")).alias('NCRM_Deal_Structure__c'),
        trim(expr("substr(NCRM_Project_Type__c,1,530)")).alias('NCRM_Project_Type__c'),
        row2.batch_id.alias('batch_id'),
        row2.source_system.alias('source_system'),
        row2.created_by.alias('created_by'),
        row2.created_dttm.alias('created_dttm'),
        row2.modified_by.alias('modified_by'),
        row2.modified_dttm.alias('modified_dttm')
        )
    insert.withColumn("CreatedDate", F.from_utc_timestamp(F.col("CreatedDate"),"EST"))
    print('insert--->')
    insert.select('NCRM_Price__c').where(col("NCRM_Price__c").isNotNull()).show()
    
    OnComponentOk5 = insert.select(
    	insert.NCRM_Project_Name__c.alias('NCRM_Project_Name__c'),
		insert.NCRM_Opportunity__c.alias('NCRM_Opportunity__c'),
		insert.NCRM_Product__c.alias('NCRM_Product__c'),
		insert.product_id.alias('product_id'),
		insert.product_name.alias('product_name'),
		insert.NCRM_CapEx_EPC_MM__c.alias('NCRM_CapEx_EPC_MM__c'),
		insert.ncrm_total_capex__c.alias('ncrm_total_capex__c'),
		insert.NCRM_Volume__c.alias('ncrm_volume__c'),
		insert.ncrm_volume_unit__c.alias('ncrm_volume_unit__c'),
    	insert.NCRM_size_mwac__c.alias('NCRM_size_mwac__c'),
    	insert.NCRM_size_mwdc__c.alias('NCRM_size_mwdc__c'),
    	insert.NCRM_year1_production_mwh__c.alias('NCRM_year1_production_mwh__c'),
    	insert.NCRM_other_capital_costs__c.alias('NCRM_other_capital_costs__c'),
    	insert.NCRM_InterconnectionMM__c.alias('NCRM_InterconnectionMM__c'),
    	insert.NCRM_State__c.alias('NCRM_State__c'),
    	insert.CreatedDate.alias('CreatedDate'),
    	insert.NCRM_Tariff_Term_YR__c.alias('NCRM_Tariff_Term_YR__c'),
    	insert.NCRM_system_type__c.alias('NCRM_system_type__c'),
    	insert.NCRM_solar_yield_kwh_kwp__c.alias('NCRM_solar_yield_kwh_kwp__c'),
    	insert.NCRM_storage_duration_hrs__c.alias('NCRM_storage_duration_hrs__c'),
    	insert.NCRM_Price__c.alias('NCRM_Price__c'),
    	insert.NCRM_Price_Unit__c.alias('NCRM_Price_Unit__c'),
    	insert.NCRM_Volume_Chargers__c.alias('NCRM_Volume_Chargers__c'),
    	insert.NCRM_Broker_FeeMM__c.alias('NCRM_Broker_FeeMM__c'),
    	insert.NCRM_OpEx__c.alias('NCRM_OpEx__c'),
    	insert.NCRM_site_lease_rate_acre__c.alias('NCRM_site_lease_rate_acre__c'),
    	insert.NCRM_site_lease_escalation__c.alias('NCRM_site_lease_escalation__c'),
    	insert.NCRM_site_lease_term_yrs__c.alias('NCRM_site_lease_term_yrs__c'),
    	insert.NCRM_Term__c.alias('NCRM_Term__c'),
    	insert.NCRM_Merchant_Term__c.alias('NCRM_Merchant_Term__c'),
    	insert.NCRM_Escalation__c.alias('NCRM_Escalation__c'),
    	insert.NCRM_System_Lease_Escalation__c.alias('NCRM_System_Lease_Escalation__c'),
    	insert.NCRM_System_Lease_Rate__c.alias('NCRM_System_Lease_Rate__c'),
    	insert.NCRM_NEER_IRR__c.alias('NCRM_NEER_IRR__c'),
    	insert.NCRM_TE_IRR__c.alias('NCRM_TE_IRR__c'),
    	insert.NCRM_ROE__c.alias('NCRM_ROE__c'),
    	insert.NCRM_NPV__c.alias('NCRM_NPV__c'),
    	insert.NCRM_wacc__c.alias('NCRM_wacc__c'),
    	insert.NCRM_Deferral_Impact__c.alias('NCRM_Deferral_Impact__c'),
    	insert.NCRM_Est_ITC_COD_Date__c.alias('NCRM_Est_ITC_COD_Date__c'),
    	insert.NCRM_Deal_Structure__c.alias('NCRM_Deal_Structure__c'),
    	insert.NCRM_Project_Type__c.alias('NCRM_Project_Type__c'),
    	insert.batch_id.alias('batch_id'),
    	insert.source_system.alias('source_system'),
    	insert.created_by.alias('created_by'),
    	insert.created_dttm.alias('created_dttm'),
    	insert.modified_by.alias('modified_by'),
    	insert.modified_dttm.alias('modified_dttm'),
		insert.RecordTypeID.alias('RecordTypeID')
    )
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    staging_file = staging_path+ "stg_file/"
    OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite")
    
#    staging_file = staging_path+ "stg_json_file/"
#    OnComponentOk5.write.json(staging_file, mode="overwrite")
    
    
#    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_product_raw (ncrm_project_name__c, ncrm_opportunity__c, ncrm_product__c, product_id, product_name, ncrm_capex_epc_mm__c, ncrm_total_capex__c, ncrm_volume__c, ncrm_volume_unit__c, ncrm_size_mwac__c, ncrm_size_mwdc__c, ncrm_year1_production_mwh__c, ncrm_other_capital_costs__c, ncrm_interconnectionmm__c, ncrm_state__c, createddate, ncrm_tariff_term_yr__c, ncrm_system_type__c, ncrm_solar_yield_kwh_kwp__c, ncrm_storage_duration_hrs__c, ncrm_price__c, ncrm_price_unit__c, ncrm_volume_chargers__c, ncrm_broker_feemm__c, ncrm_opex__c, ncrm_site_lease_rate_acre__c, ncrm_site_lease_escalation__c, ncrm_site_lease_term_yrs__c, ncrm_term__c, ncrm_merchant_term__c, ncrm_escalation__c, ncrm_system_lease_escalation__c, ncrm_system_lease_rate__c, ncrm_neer_irr__c, ncrm_te_irr__c, ncrm_roe__c, ncrm_npv__c, ncrm_wacc__c, ncrm_deferral_impact__c,  ncrm_est_itc_cod_date__c, ncrm_deal_structure__c, ncrm_project_type__c, batch_id, source_system, created_by, created_dttm, modified_by, modified_dttm, recordtypeid) FROM 
#    '{staging_file}' iam_role '{iam_role}' FORMAT AS JSON 'auto' TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""   

    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_product_raw (ncrm_project_name__c, ncrm_opportunity__c, ncrm_product__c, product_id, product_name, ncrm_capex_epc_mm__c, ncrm_total_capex__c, ncrm_volume__c, ncrm_volume_unit__c, ncrm_size_mwac__c, ncrm_size_mwdc__c, ncrm_year1_production_mwh__c, ncrm_other_capital_costs__c, ncrm_interconnectionmm__c, ncrm_state__c, createddate, ncrm_tariff_term_yr__c, ncrm_system_type__c, ncrm_solar_yield_kwh_kwp__c, ncrm_storage_duration_hrs__c, ncrm_price__c, ncrm_price_unit__c, ncrm_volume_chargers__c, ncrm_broker_feemm__c, ncrm_opex__c, ncrm_site_lease_rate_acre__c, ncrm_site_lease_escalation__c, ncrm_site_lease_term_yrs__c, ncrm_term__c, ncrm_merchant_term__c, ncrm_escalation__c, ncrm_system_lease_escalation__c, ncrm_system_lease_rate__c, ncrm_neer_irr__c, ncrm_te_irr__c, ncrm_roe__c, ncrm_npv__c, ncrm_wacc__c, ncrm_deferral_impact__c,  ncrm_est_itc_cod_date__c, ncrm_deal_structure__c, ncrm_project_type__c, batch_id, source_system, created_by, created_dttm, modified_by, modified_dttm, recordtypeid) FROM 
    '{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100""" 
	
    statement = connection.createStatement()
    cloudwatch.log_to_stream(f"copy_query1: {copy_query1}")
    statement.executeUpdate(copy_query1)
    statement.close()
    
    count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_product_raw)"""
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    insert_query = f"""INSERT INTO vendor_customer_opportunities_raw.sfdc_neercrm_product_raw (ncrm_project_name__c,ncrm_opportunity__c,ncrm_product__c,product_id,product_name,ncrm_capex_epc_mm__c,ncrm_total_capex__c,ncrm_volume__c,ncrm_size_mwac__c,ncrm_size_mwdc__c,ncrm_year1_production_mwh__c,ncrm_other_capital_costs__c,ncrm_interconnectionmm__c,ncrm_state__c,createddate,ncrm_tariff_term_yr__c,ncrm_system_type__c,ncrm_solar_yield_kwh_kwp__c,ncrm_storage_duration_hrs__c,ncrm_price__c,ncrm_price_unit__c,ncrm_volume_chargers__c,ncrm_broker_feemm__c,ncrm_opex__c,ncrm_site_lease_rate_acre__c,ncrm_site_lease_escalation__c,ncrm_site_lease_term_yrs__c,ncrm_term__c,ncrm_merchant_term__c,ncrm_escalation__c,ncrm_system_lease_escalation__c,ncrm_system_lease_rate__c,ncrm_neer_irr__c,ncrm_te_irr__c,ncrm_roe__c,ncrm_npv__c,ncrm_wacc__c,ncrm_deferral_impact__c,ncrm_est_itc_cod_date__c,ncrm_deal_structure__c,ncrm_project_type__c,batch_id,source_system,created_by,created_dttm,modified_by,modified_dttm,recordtypeid) select ncrm_project_name__c,ncrm_opportunity__c,ncrm_product__c,product_id,product_name,ncrm_capex_epc_mm__c,ncrm_total_capex__c,ncrm_volume__c,ncrm_size_mwac__c,ncrm_size_mwdc__c,ncrm_year1_production_mwh__c,ncrm_other_capital_costs__c,ncrm_interconnectionmm__c,ncrm_state__c,createddate,ncrm_tariff_term_yr__c,ncrm_system_type__c,ncrm_solar_yield_kwh_kwp__c,ncrm_storage_duration_hrs__c,ncrm_price__c,ncrm_price_unit__c,ncrm_volume_chargers__c,ncrm_broker_feemm__c,ncrm_opex__c,ncrm_site_lease_rate_acre__c,ncrm_site_lease_escalation__c,ncrm_site_lease_term_yrs__c,ncrm_term__c,ncrm_merchant_term__c,ncrm_escalation__c,ncrm_system_lease_escalation__c,ncrm_system_lease_rate__c,ncrm_neer_irr__c,ncrm_te_irr__c,ncrm_roe__c,ncrm_npv__c,ncrm_wacc__c,ncrm_deferral_impact__c,ncrm_est_itc_cod_date__c,ncrm_deal_structure__c,ncrm_project_type__c,batch_id,source_system,created_by,created_dttm,modified_by,modified_dttm,recordtypeid from vendor_customer_opportunities_staging.stg_sfdc_neercrm_product_raw"""   
    statement = connection.createStatement()
    statement.executeUpdate(insert_query)
    statement.close()
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_status = 'Batch Successful'
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    # On successful export of data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Success Email not sent, with error_code = {status_code}"
        )
    logger.info("Script executed successfully......  check data in redshift")

    cloudwatch.log_to_stream(
        "Writing  data to redshift has been successfully done.."
    )
    job.commit()
except Exception as e:
    logger.info(f"Job failed with following error ......{e}")
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', batch_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Failure Email not sent, with error_code = {status_code}"
        )
    error_message = f"Job failed with following error: {str(e)}"
    logger.info(error_message)
    cloudwatch.log_to_stream(error_message)
    sns_publish(
        sns_arn,
        "Glue Job Failure",
        f"{job_name} failed with error: {str(e)}"
    )
    raise e
