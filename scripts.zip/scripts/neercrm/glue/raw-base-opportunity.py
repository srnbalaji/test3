import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim,expr
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
#args = getResolvedOptions(sys.argv,["environment","job_name","extra_params"])

extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
#batch_id=202501060524128525
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]


# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_NEERCRM_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_db_table = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

redshift_properties = spark._jvm.java.util.Properties()
redshift_properties.setProperty("url", redshift_jdbc_url)
redshift_properties.setProperty("dbtable", redshift_db_table)
redshift_properties.setProperty("user", redshift_user)
redshift_properties.setProperty("password", redshift_password)
redshift_properties.setProperty("TempDir", redshift_temp_dir)
redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
redshift_properties.setProperty("connectionName", redshift_connection_name)

try:
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    
    #batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    
    Global_Source_System_Name = "Salesforce_NEERCRM_Source_Opportunity"
    owner = "Salesforce_NEERCRM_Owner"
    
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'sfdc_neercrm_opportunity_raw') custom"""
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")

    '''insert_audit = f"""INSERT INTO vendor_customer_opportunities_raw.edp_axis_batch_control_log(batch_id 	,batch_start_dttm 	,batch_status ,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone ,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH2:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()'''
    
    
    query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    query1 = f"""(select OpportunityId,
            businessdevelopment_id,
    		businessdevelopment_name,
    		cioriginator_id,
    		cioriginator_name,
    		batch_id,
    		source_system,
    		created_by,
    		created_dttm,
    		modified_by,
    		modified_dttm
    FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_team_member_raw)"""
    
    team_member_df = spark.read.jdbc(redshift_jdbc_url, query1, properties=redshift_properties)
    
    # Conforming fields names to the component layout
    team_member_df = team_member_df.withColumnRenamed(team_member_df.columns[0],'OpportunityId')\
    	.withColumnRenamed(team_member_df.columns[1],'businessdevelopment_id')\
    	.withColumnRenamed(team_member_df.columns[2],'businessdevelopment_name')\
    	.withColumnRenamed(team_member_df.columns[3],'cioriginator_id')\
    	.withColumnRenamed(team_member_df.columns[4],'cioriginator_name')\
    	.withColumnRenamed(team_member_df.columns[5],'batch_id')\
    	.withColumnRenamed(team_member_df.columns[6],'source_system')\
    	.withColumnRenamed(team_member_df.columns[7],'created_by')\
    	.withColumnRenamed(team_member_df.columns[8],'created_dttm')\
    	.withColumnRenamed(team_member_df.columns[9],'modified_by')\
    	.withColumnRenamed(team_member_df.columns[10],'modified_dttm')
    
    print("team_member_df ====>")
    team_member_df.printSchema()
    
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    opportunity_raw_df = spark.read.option("multiline","True").json(staging_path)
    
    print("Before droping opportunity_raw_df ====>")           
    opportunity_raw_df.printSchema()
    opportunity_raw_df = opportunity_raw_df.drop('attributes')
    opportunity_raw_df.show(10)
    print("after droping attribute opportunity_raw_df ====>")          
    opportunity_raw_df.printSchema()
       
    print("opportunity_raw_df ====>")           
    opportunity_raw_df.printSchema()
    #opportunity_raw_df.show(10)
    opportunity_raw_df1 = opportunity_raw_df.withColumn("batch_id",lit(batch_id))\
               .withColumn("source_system",lit(source_system))\
               .withColumn("created_by",lit(created_by))\
               .withColumn("modified_by",lit(modified_by))\
               .withColumn("owner",lit(owner))\
               .withColumn("contact_identifier",lit(contact_identifier))\
               .withColumn("user_slid",lit("None"))\
               .withColumn("created_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
               .withColumn("modified_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
               .withColumn('system_id', substring(regexp_replace(regexp_replace('Id', '\\{', ''), '\\}', ''), 1, 36))\
               .withColumn('account_id', substring(regexp_replace(regexp_replace('AccountId', '\\{', ''), '\\}', ''), 1, 36))\
               .withColumn('lead', substring(regexp_replace(regexp_replace('OwnerId', '\\{', ''), '\\}', ''), 1, 72))\
                .withColumn('owner_id', substring(regexp_replace(regexp_replace('CreatedById', '\\{', ''), '\\}', ''), 1, 72))\
                .withColumn('ownerid_name', substring(regexp_replace(regexp_replace('CreatedById', '\\{', ''), '\\}', ''), 1, 72))
    
    print("opportunity_raw_df1 ====>")           
    opportunity_raw_df1.printSchema()
    #opportunity_raw_df1.show(10)  
    
    query2 = f"""(select product.ncrm_project_name__c,
    project_lkp.ncrm_site_city__c
    ,product.ncrm_opportunity__c
	,product.ncrm_product__c
	,product.ncrm_capex_epc_mm__c
	,product.ncrm_total_capex__c
	,product.ncrm_volume__c
	,product.ncrm_size_mwac__c
	,product.ncrm_size_mwdc__c
	,product.ncrm_year1_production_mwh__c
	,product.ncrm_other_capital_costs__c
	,product.ncrm_interconnectionmm__c
	,product.ncrm_state__c
	,product.createddate
	,product.ncrm_tariff_term_yr__c
	,product.ncrm_system_type__c
	,product.ncrm_solar_yield_kwh_kwp__c
	,product.ncrm_storage_duration_hrs__c
	,product.ncrm_price__c
	,product.ncrm_price_unit__c
	,product.ncrm_volume_chargers__c
	,product.ncrm_broker_feemm__c
	,product.ncrm_opex__c
	,product.ncrm_site_lease_rate_acre__c
	,product.ncrm_site_lease_escalation__c
	,product.ncrm_site_lease_term_yrs__c
	,product.ncrm_term__c
	,product.ncrm_merchant_term__c
	,product.ncrm_escalation__c
	,product.ncrm_system_lease_escalation__c
	,product.ncrm_system_lease_rate__c
	,product.ncrm_neer_irr__c
	,product.ncrm_te_irr__c
	,product.ncrm_roe__c
	,product.ncrm_npv__c
	,product.ncrm_wacc__c
	,product.ncrm_deferral_impact__c
	,product.ncrm_day1_itc_net_income__c
	,product.ncrm_est_itc_cod_date__c
	,product.ncrm_deal_structure__c
	,product.ncrm_project_type__c
	,product.batch_id
	,product.source_system
	,product.created_by
	,product.created_dttm 
	,product.modified_by
	,product.modified_dttm from vendor_customer_opportunities_raw.sfdc_neercrm_product_raw product
    inner join vendor_customer_opportunities_raw.sfdc_neercrm_project_lookup_raw project_lkp
    on product.ncrm_project_name__c = project_lkp.project_id)"""
    
    product_raw_df = spark.read.jdbc(redshift_jdbc_url, query2, properties=redshift_properties)
    
    product_raw_df = product_raw_df.withColumnRenamed(product_raw_df.columns[0],'NCRM_Project_Name__c')\
    	.withColumnRenamed(product_raw_df.columns[1],'ncrm_site_city__c')\
    	.withColumnRenamed(product_raw_df.columns[2],'NCRM_Opportunity__c')\
    	.withColumnRenamed(product_raw_df.columns[3],'NCRM_Product__c')\
    	.withColumnRenamed(product_raw_df.columns[4],'NCRM_CapEx_EPC_MM__c')\
    	.withColumnRenamed(product_raw_df.columns[5],'NCRM_Total_CapEx__c')\
    	.withColumnRenamed(product_raw_df.columns[6],'NCRM_Volume__c')\
    	.withColumnRenamed(product_raw_df.columns[7],'NCRM_size_mwac__c')\
    	.withColumnRenamed(product_raw_df.columns[8],'NCRM_size_mwdc__c')\
    	.withColumnRenamed(product_raw_df.columns[9],'NCRM_year1_production_mwh__c')\
    	.withColumnRenamed(product_raw_df.columns[10],'NCRM_other_capital_costs__c')\
    	.withColumnRenamed(product_raw_df.columns[11],'NCRM_InterconnectionMM__c')\
    	.withColumnRenamed(product_raw_df.columns[12],'NCRM_State__c')\
    	.withColumnRenamed(product_raw_df.columns[13],'CreatedDate')\
    	.withColumnRenamed(product_raw_df.columns[14],'NCRM_Tariff_Term_YR__c')\
    	.withColumnRenamed(product_raw_df.columns[15],'NCRM_system_type__c')\
    	.withColumnRenamed(product_raw_df.columns[16],'NCRM_solar_yield_kwh_kwp__c')\
    	.withColumnRenamed(product_raw_df.columns[17],'NCRM_storage_duration_hrs__c')\
    	.withColumnRenamed(product_raw_df.columns[18],'NCRM_Price__c')\
    	.withColumnRenamed(product_raw_df.columns[19],'NCRM_Price_Unit__c')\
    	.withColumnRenamed(product_raw_df.columns[20],'NCRM_Volume_Chargers__c')\
    	.withColumnRenamed(product_raw_df.columns[21],'NCRM_Broker_FeeMM__c')\
    	.withColumnRenamed(product_raw_df.columns[22],'NCRM_OpEx__c')\
    	.withColumnRenamed(product_raw_df.columns[23],'NCRM_site_lease_rate_acre__c')\
    	.withColumnRenamed(product_raw_df.columns[24],'NCRM_site_lease_escalation__c')\
    	.withColumnRenamed(product_raw_df.columns[25],'NCRM_site_lease_term_yrs__c')\
    	.withColumnRenamed(product_raw_df.columns[26],'NCRM_Term__c')\
    	.withColumnRenamed(product_raw_df.columns[27],'NCRM_Merchant_Term__c')\
    	.withColumnRenamed(product_raw_df.columns[28],'NCRM_Escalation__c')\
    	.withColumnRenamed(product_raw_df.columns[29],'NCRM_System_Lease_Escalation__c')\
    	.withColumnRenamed(product_raw_df.columns[30],'NCRM_System_Lease_Rate__c')\
    	.withColumnRenamed(product_raw_df.columns[31],'NCRM_NEER_IRR__c')\
    	.withColumnRenamed(product_raw_df.columns[32],'NCRM_TE_IRR__c')\
    	.withColumnRenamed(product_raw_df.columns[33],'NCRM_ROE__c')\
    	.withColumnRenamed(product_raw_df.columns[34],'NCRM_NPV__c')\
    	.withColumnRenamed(product_raw_df.columns[35],'NCRM_wacc__c')\
    	.withColumnRenamed(product_raw_df.columns[36],'NCRM_Deferral_Impact__c')\
    	.withColumnRenamed(product_raw_df.columns[37],'NCRM_Day1_ITC_Net_Income__c')\
    	.withColumnRenamed(product_raw_df.columns[38],'NCRM_Est_ITC_COD_Date__c')\
    	.withColumnRenamed(product_raw_df.columns[39],'NCRM_Deal_Structure__c')\
    	.withColumnRenamed(product_raw_df.columns[40],'NCRM_Project_Type__c')\
    	.withColumnRenamed(product_raw_df.columns[41],'batch_id')\
    	.withColumnRenamed(product_raw_df.columns[42],'source_system')\
    	.withColumnRenamed(product_raw_df.columns[43],'created_by')\
    	.withColumnRenamed(product_raw_df.columns[44],'created_dttm')\
    	.withColumnRenamed(product_raw_df.columns[45],'modified_by')\
    	.withColumnRenamed(product_raw_df.columns[46],'modified_dttm')
    print("product_raw_df ====>") 	
    product_raw_df.printSchema()
    
    product_raw_df = product_raw_df.withColumn('NCRM_Est_ITC_COD_Date__c',date_format(to_timestamp("NCRM_Est_ITC_COD_Date__c", "yyyy-MM-dd HH:mm:ss.SSS Z"),"yyyy-MM-dd HH:mm:ss.SSS Z"))
    
    
    
    
    query3 = f"""(SELECT NCRM_Opportunity__c,
    		dgstage3_date,
    		dg_region,
    		dgstage5_date,
    		batch_id,
    		source_system,
    		created_by,
    		created_dttm,
    		modified_by,
    		modified_dttm FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_details_raw)"""
            
    opportunities_raw_df = spark.read.jdbc(redshift_jdbc_url, query3, properties=redshift_properties) 
         
         
    opportunities_raw_df = opportunities_raw_df.withColumnRenamed(opportunities_raw_df.columns[0],'NCRM_Opportunity__c')\
                    .withColumnRenamed(opportunities_raw_df.columns[1],'dgstage3_date')\
                    .withColumnRenamed(opportunities_raw_df.columns[2],'dg_region')\
                    .withColumnRenamed(opportunities_raw_df.columns[3],'dgstage5_date')\
                    .withColumnRenamed(opportunities_raw_df.columns[4],'batch_id')\
                    .withColumnRenamed(opportunities_raw_df.columns[5],'source_system')\
                    .withColumnRenamed(opportunities_raw_df.columns[6],'created_by')\
                    .withColumnRenamed(opportunities_raw_df.columns[7],'created_dttm')\
                    .withColumnRenamed(opportunities_raw_df.columns[8],'modified_by')\
                    .withColumnRenamed(opportunities_raw_df.columns[9],'modified_dttm')
                    
    #opportunities_raw_df = opportunities_raw_df.withColumn("dgstage3_date", date_format(to_timestamp('dgstage3_date', "yyyy-MM-dd'T'HH:mm:ss.SSS'z'"), "yyyy-MM-dd HH:mm:ss.SSS"))
    
    print ("Test Data3")
    #opportunities_raw_df.withColumn("dgstage3_date").show(truncate=False)

    
    team_member_df = team_member_df.dropDuplicates(['OpportunityId'])

    #Match model detected for node: opportunities_raw_df
    product_raw_df = product_raw_df.dropDuplicates(['NCRM_Opportunity__c'])

    #Match model detected for node: product_raw_df
    opportunities_raw_df1 = opportunities_raw_df.dropDuplicates(['NCRM_Opportunity__c'])
    
    tMap_1_joined = opportunity_raw_df1.join(product_raw_df, (opportunity_raw_df1.Id == product_raw_df.NCRM_Opportunity__c), 'left_outer').join(opportunities_raw_df1, (opportunity_raw_df1.Id == opportunities_raw_df1.NCRM_Opportunity__c), 'left_outer').join(team_member_df, (opportunity_raw_df1.Id == team_member_df.OpportunityId), 'left_outer').withColumn("var_stage_number", opportunity_raw_df1.NCRM_Stage_Status__c )
    
    # End of join for tMap_1_joined
    insert = tMap_1_joined.select(
        opportunity_raw_df1.system_id.alias('system_id'),
        opportunity_raw_df1.account_id.alias('account_id'),
        opportunity_raw_df1.RecordTypeId.alias('recordtypeid'),
    	trim(expr("substr(Name,1,240)")).alias('name'),
    	(when(opportunity_raw_df1.CreatedDate == lit(""), lit(None)).otherwise(date_format(opportunity_raw_df1.CreatedDate, "yyyy-MM-dd HH:mm:ss.SSSZ"))).alias('CreatedDate'),
        (when(opportunity_raw_df1.LastModifiedDate == lit(""), lit(None)).otherwise(date_format(opportunity_raw_df1.LastModifiedDate, "yyyy-MM-dd HH:mm:ss.SSSZ"))).alias('LastModifiedDate'),
    	trim(expr("substr(NCRM_Status_Reason__c,1, 550 )")).alias('status'),
    	opportunity_raw_df1.lead.alias('lead'),
    	opportunity_raw_df1.owner.alias('owner'),
    	opportunity_raw_df1.owner_id.alias('owner_id'),
    	opportunity_raw_df1.ownerid_name.alias('ownerid_name'),
    	product_raw_df.ncrm_site_city__c.alias('site_city'),
    	team_member_df.businessdevelopment_id.alias('businessdevelopment_id'),
    	product_raw_df.NCRM_Est_ITC_COD_Date__c.alias('estcod_date'),
    	team_member_df.businessdevelopment_name.alias('businessdevelopment_name'),
    	trim(expr("substr(NCRM_Business_Group__c,1,2600)")).alias('businessgroup_name'),
    	trim(expr("substr(NCRM_Business_Group__c,1,2600)")).alias('business_group'),
    	product_raw_df.NCRM_Deal_Structure__c.alias('system_type'),
    	product_raw_df.NCRM_State__c.alias('statecode_name'),
    	product_raw_df.NCRM_Project_Type__c.alias('greenfield_matype'),
    	trim(expr("substr(NCRM_Stage_Age__c,1,30)")).alias('stageage_calculated'),
    	opportunities_raw_df1.dgstage3_date.alias('dgstage3_date'),
    	team_member_df.cioriginator_id.alias('cioriginator_id'),
    	team_member_df.cioriginator_name.alias('cioriginator_name'),
    	opportunities_raw_df1.dg_region.alias('dg_region'),
    	opportunities_raw_df1.dgstage5_date.alias('dgstage5_date'),
    	(when((col("var_stage_number") == None) | (expr("substr(var_stage_number,1,1)").rlike("^[a-zA-Z]+$")) | (expr("substr(var_stage_number,1,1)").isin(["", " ", "N", "n"])), None).otherwise(expr("substr(var_stage_number,1,1)"))).alias('stage_number'),
#    	(when((col("var_stage_number") == None) | (col("var_stage_number").isin(["", " ", "N", "n"])), None).otherwise(col("var_stage_number").cast(DecimalType(16,2)))).alias('stage_number'),
    	opportunities_raw_df1.batch_id.alias('batch_id'),
    	opportunities_raw_df1.source_system.alias('source_system'),
    	opportunity_raw_df1.created_by.alias('created_by'),
    	date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('created_dttm'),
    	opportunity_raw_df1.modified_by.alias('modified_by'),
    	date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('modified_dttm')
    )

    OnComponentOk5 = insert.select(
    	insert.system_id.alias('system_id'),
    	insert.account_id.alias('account_id'),
    	insert.name.alias('name'),
    	insert.CreatedDate.alias('created_date'),
    	insert.LastModifiedDate.alias('last_modified_date'),
    	insert.status.alias('status'),
    	insert.lead.alias('lead'),
    	insert.owner.alias('owner'),
    	insert.owner_id.alias('owner_id'),
    	insert.ownerid_name.alias('ownerid_name'),
    	insert.site_city.alias('site_city'),
    	insert.businessdevelopment_id.alias('businessdevelopment_id'),
    	insert.estcod_date.alias('estcod_date'),
    	insert.businessdevelopment_name.alias('businessdevelopment_name'),
    	insert.businessgroup_name.alias('businessgroup_name'),
    	insert.business_group.alias('business_group'),
    	insert.system_type.alias('system_type'),
    	insert.statecode_name.alias('statecode_name'),
    	insert.greenfield_matype.alias('greenfield_matype'),
    	insert.stageage_calculated.alias('stageage_calculated'),
    	insert.dgstage3_date.alias('dgstage3_date'),
    	insert.cioriginator_id.alias('cioriginator_id'),
    	insert.cioriginator_name.alias('cioriginator_name'),
    	insert.dg_region.alias('dg_region'),
    	insert.dgstage5_date.alias('dgstage5_date'),
    	insert.stage_number.alias('stage_number'),
    	insert.batch_id.alias('batch_id'),
    	insert.source_system.alias('source_system'),
    	insert.created_by.alias('created_by'),
    	insert.created_dttm.alias('created_dttm'),
    	insert.modified_by.alias('modified_by'),
    	insert.modified_dttm.alias('modified_dttm'),
    	insert.recordtypeid.alias('recordtypeid')
    )
    staging_file = staging_path+ "stg_file/"
    OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite",quote="\"",escape="\"")
	
    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_raw FROM 
	'{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100 TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""  
	
	
    statement = connection.createStatement()
    print ("copy query")
    print (copy_query1)
    statement.executeUpdate(copy_query1)
    statement.close()
    
    count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_raw)"""
    
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    sql_query1 = f"""UPDATE vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw
    SET account_id = stg_sfdc_neercrm_opportunity_raw.account_id
    ,name = stg_sfdc_neercrm_opportunity_raw.name
    ,created_date = stg_sfdc_neercrm_opportunity_raw.created_date
    ,last_modified_date = stg_sfdc_neercrm_opportunity_raw.last_modified_date
    ,status = stg_sfdc_neercrm_opportunity_raw.status
    ,lead = stg_sfdc_neercrm_opportunity_raw.lead
    ,owner = stg_sfdc_neercrm_opportunity_raw.owner
    ,owner_id = stg_sfdc_neercrm_opportunity_raw.owner_id
    ,ownerid_name = stg_sfdc_neercrm_opportunity_raw.ownerid_name
    ,site_city = stg_sfdc_neercrm_opportunity_raw.site_city
    ,businessdevelopment_id = stg_sfdc_neercrm_opportunity_raw.businessdevelopment_id
    ,estcod_date = stg_sfdc_neercrm_opportunity_raw.estcod_date
    ,businessdevelopment_name = stg_sfdc_neercrm_opportunity_raw.businessdevelopment_name
    ,businessgroup_name = stg_sfdc_neercrm_opportunity_raw.businessgroup_name
    ,business_group = stg_sfdc_neercrm_opportunity_raw.business_group
    ,system_type = stg_sfdc_neercrm_opportunity_raw.system_type
    ,statecode_name = stg_sfdc_neercrm_opportunity_raw.statecode_name
    ,greenfield_matype = stg_sfdc_neercrm_opportunity_raw.greenfield_matype
    ,stageage_calculated = stg_sfdc_neercrm_opportunity_raw.stageage_calculated
    ,dgstage3_date = stg_sfdc_neercrm_opportunity_raw.dgstage3_date
    ,cioriginator_id = stg_sfdc_neercrm_opportunity_raw.cioriginator_id
    ,cioriginator_name = stg_sfdc_neercrm_opportunity_raw.cioriginator_name
    ,dg_region = stg_sfdc_neercrm_opportunity_raw.dg_region
    ,dgstage5_date = stg_sfdc_neercrm_opportunity_raw.dgstage5_date
    ,stage_number = stg_sfdc_neercrm_opportunity_raw.stage_number
    ,batch_id = stg_sfdc_neercrm_opportunity_raw.batch_id
    ,source_system = stg_sfdc_neercrm_opportunity_raw.source_system
    ,created_by = stg_sfdc_neercrm_opportunity_raw.created_by
    ,created_dttm = stg_sfdc_neercrm_opportunity_raw.created_dttm
    ,modified_by = stg_sfdc_neercrm_opportunity_raw.modified_by
    ,modified_dttm = stg_sfdc_neercrm_opportunity_raw.modified_dttm
    FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_raw
    WHERE sfdc_neercrm_opportunity_raw.system_id = stg_sfdc_neercrm_opportunity_raw.system_id"""
    
    statement = connection.createStatement()
    statement.executeUpdate(sql_query1)
    statement.close()
    
    sql_query2 = f"""INSERT INTO vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw
    SELECT stg_sfdc_neercrm_opportunity_raw.*
    FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_raw
    LEFT JOIN vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw
    ON stg_sfdc_neercrm_opportunity_raw.system_id = sfdc_neercrm_opportunity_raw.system_id
    WHERE sfdc_neercrm_opportunity_raw.system_id IS NULL"""
    
    statement = connection.createStatement()
    statement.executeUpdate(sql_query2)
    statement.close()
	
    insert_query = f"""INSERT INTO vendor_customer_opportunities_raw.neercrm_opportunity_snapshot(
    SELECT 
    system_id                      
    ,account_id                    
    ,name                          
    ,created_date                  
    ,last_modified_date            
    ,status                        
    ,lead                          
    ,owner                       
    ,owner_id                      
    ,ownerid_name                  
    ,site_city                     
    ,businessdevelopment_id        
    ,estcod_date                   
    ,businessdevelopment_name      
    ,businessgroup_name            
    ,business_group                
    ,system_type                   
    ,statecode_name                
    ,greenfield_matype             
    ,stageage_calculated           
    ,dgstage3_date                 
    ,cioriginator_id               
    ,cioriginator_name             
    ,dg_region                     
    ,dgstage5_date                 
    ,batch_id                      
    ,source_system                 
    ,created_by                    
    ,created_dttm                  
    ,modified_by                   
    ,modified_dttm                                               
    ,current_timestamp as snapshot_dt,
    recordtypeid
    FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_raw)"""
    
    statement = connection.createStatement()
    statement.executeUpdate(insert_query)
    statement.close()
    
    
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_status = 'Batch Successful'
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """
    
    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    #On successful export of maximo data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Success Email not sent, with error_code = {status_code}"
        )
    logger.info("Script executed successfully......  check data in redshift")

    cloudwatch.log_to_stream(
        "Writing  data to redshift has been successfully done.."
    )
    job.commit()
except Exception as e:
    logger.info(f"Job failed with following error ......{e}")
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', batch_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Failure Email not sent, with error_code = {status_code}"
        )
    error_message = f"Job failed with following error: {str(e)}"
    logger.info(error_message)
    cloudwatch.log_to_stream(error_message)
    sns_publish(
        sns_arn,
        "Glue Job Failure",
        f"{job_name} failed with error: {str(e)}"
    )
    raise e
