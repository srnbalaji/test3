import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim
from pyspark.sql import functions as F
from pyspark.sql.functions import to_timestamp, to_utc_timestamp
from pyspark.sql.functions import col

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
#args = getResolvedOptions(sys.argv,["environment","job_name","extra_params"])
extra_params_obj = config.EXTRA_PARAMS_NEERC_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
#batch_id=202501041236454253
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
filename = extra_params_obj.get("filename")
target_table_name = extra_params_obj.get("target_table_name")
landing_zone = extra_params_obj.get("landing_zone")
owner = extra_params_obj.get("owner")
contact_identifier = extra_params_obj.get("contact_identifier")
target_db_schema = extra_params_obj.get("target_db_schema")
target_db_table = extra_params_obj.get("target_db_table")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
log_group = config.LOG_FILES_Neercrm[environment]
sns_arn = config.sns_arn[environment]

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_NEERCRM_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = job_name + "_" + timestamp_generator("%Y%m%d%H%M%S")

cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")


#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_dbtable = config.fix_redshift_db_table(extra_params_obj.get("REDSHIFT_DB_TABLE"),environment)
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

redshift_properties = spark._jvm.java.util.Properties()
redshift_properties.setProperty("url", redshift_jdbc_url)
redshift_properties.setProperty("dbtable", redshift_dbtable)
redshift_properties.setProperty("user", redshift_user)
redshift_properties.setProperty("password", redshift_password)
redshift_properties.setProperty("TempDir", redshift_temp_dir)
redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
redshift_properties.setProperty("connectionName", redshift_connection_name)

try:
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    
    #batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
        
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'edp_axis_sfdc_neercrm_raw_base_opportunity_details') custom"""
               
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
        
    query = f"""DELETE FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_details_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    query1 = f"""DELETE FROM vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_details_raw"""
    statement = connection.createStatement()
    statement.executeUpdate(query1)
    statement.close()
    
    staging_path = s3_staging_config+"/output/"+filename+"/staging/"
    row1 = spark.read.option("multiline","True").json(staging_path)
    
    '''
    row1 = row1.withColumnRenamed(row1.columns[0],'NCRM_Opportunity__c')\
    	.withColumnRenamed(row1.columns[1],'NCRM_Team_Region__c')\
    	.withColumnRenamed(row1.columns[2],'NCRM_DG_Stage_3_Date__c')\
    	.withColumnRenamed(row1.columns[3],'NCRM_DG_Stage_5_Date__c')\
    	.withColumnRenamed(row1.columns[4],'LastModifiedDate')\
    	.withColumnRenamed(row1.columns[5],'Name')\
    	.withColumnRenamed(row1.columns[6],'CreatedDate')\
    	.withColumnRenamed(row1.columns[7],'RecordTypeId')\
    	.withColumnRenamed(row1.columns[8],'NCRM_CurrentYearGrossMarginProbAdjusted__c')\
    	.withColumnRenamed(row1.columns[9],'NCRM_CurrentYearGrossMarginProbFormula__c')\
    	.withColumnRenamed(row1.columns[10],'NCRM_Current_Year_Gross_Margin_Formula__c')\
    	.withColumnRenamed(row1.columns[11],'NCRM_Current_Year_Gross_Margin__c')\
    	.withColumnRenamed(row1.columns[12],'NCRM_Estimated_Close_date__c')\
    	.withColumnRenamed(row1.columns[13],'NCRM_Estimated_End_Date__c')\
    	.withColumnRenamed(row1.columns[14],'NCRM_Estimated_Start_Date__c')\
    	.withColumnRenamed(row1.columns[15],'NCRM_Estimated_Trade_Date__c')\
    	.withColumnRenamed(row1.columns[16],'NCRM_FutureYearGrossMarginProbAdjusted__c')\
    	.withColumnRenamed(row1.columns[17],'NCRM_FutureYearGrossMarginProbFormula__c')\
    	.withColumnRenamed(row1.columns[18],'NCRM_Future_Year_Gross_Margin_Formula__c')\
    	.withColumnRenamed(row1.columns[19],'NCRM_Future_Year_Gross_Margin__c')\
    	.withColumnRenamed(row1.columns[20],'NCRM_OriginatorEstimatedTotalFormula__c')\
    	.withColumnRenamed(row1.columns[21],'NCRM_OriginatorEstimatedTotalGrossMargin__c')\
    	.withColumnRenamed(row1.columns[22],'NCRM_Parent_Opportunity_Group__c')\
    	.withColumnRenamed(row1.columns[23],'NCRM_Power_Top_Prospect__c')\
    	.withColumnRenamed(row1.columns[24],'NCRM_State_of_Delivery_Point__c')\
    	.withColumnRenamed(row1.columns[25],'NCRM_Request_Structure_Team_Assistance__c')\
    	.withColumnRenamed(row1.columns[26],'NCRM_Structure_Next_Steps__c')\
    	.withColumnRenamed(row1.columns[27],'NCRM_TotalGrossMarginProbAdjusted__c')\
    	.withColumnRenamed(row1.columns[28],'NCRM_TotalGrossMarginProbFormula__c')\
    	.withColumnRenamed(row1.columns[29],'NCRM_Total_Gross_Margin_Calculation__c')\
    	.withColumnRenamed(row1.columns[30],'NCRM_Total_Gross_Margin_Formula__c')\
    	.withColumnRenamed(row1.columns[31],'NCRM_Trade_Date__c')\
    	.withColumnRenamed(row1.columns[32],'NCRM_Type__c')\
    	.withColumnRenamed(row1.columns[33],'NCRM_Deal_Valuation_Notes__c')\
    	.withColumnRenamed(row1.columns[34],'NCRM_State__c')\
    	.withColumnRenamed(row1.columns[35],'NCRM_Commodity__c')\
    	.withColumnRenamed(row1.columns[36],'NCRM_Actual_Start_Date__c')\
    	.withColumnRenamed(row1.columns[37],'NCRM_Actual_End_Date__c')\
    	.withColumnRenamed(row1.columns[38],'NCRM_Deal_Structure__c')\
    	.withColumnRenamed(row1.columns[39],'NCRM_Total_Trade_P_L_FF__c')\
    	.withColumnRenamed(row1.columns[40],'NCRM_Total_Minimum_Volume_Quantity__c')\
    	.withColumnRenamed(row1.columns[41],'NCRM_TotalMinimumVolumeQuantity_Formula__c')\
    	.withColumnRenamed(row1.columns[42],'NCRM_Volume_Quantity_Unit__c')\
    	.withColumnRenamed(row1.columns[43],'Id')
    '''
    row1 = row1.withColumn("batch_id",lit(batch_id))\
                .withColumn("source_system",lit(source_system))\
                .withColumn("created_by",lit(created_by))\
                .withColumn("modified_by",lit(modified_by))\
                .withColumn("created_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("modified_dttm", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))\
                .withColumn("dgstage5_date",lit(" "))\
                .withColumn("CreatedDate", date_format(col('CreatedDate'), "yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Estimated_End_Date__c", date_format(col('NCRM_Estimated_End_Date__c'),"yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Trade_Date__c", date_format(col('NCRM_Trade_Date__c'),"yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Estimated_Start_Date__c", date_format(col("NCRM_Estimated_Start_Date__c"), "yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Estimated_Trade_Date__c", date_format(col('NCRM_Estimated_Trade_Date__c'),'yyyy-MM-dd HH:mm:ss.SSSZ'))\
                .withColumn("NCRM_Actual_Start_Date__c", date_format(col('NCRM_Actual_Start_Date__c'),"yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Actual_End_Date__c", date_format(col('NCRM_Actual_End_Date__c'),"yyyy-MM-dd HH:mm:ss.SSSZ"))\
                .withColumn("NCRM_Estimated_Close_Date__c", date_format(col('NCRM_Estimated_Close_Date__c'),"yyyy-MM-dd HH:mm:ss.SSSZ"))\
                #.withColumn("NCRM_Deal_Valuation_Notes__c", F.regexp_replace(col("NCRM_Deal_Valuation_Notes__c"), '[^a-zA-Z0-9,.()/!@#$%^&*-_+:;<>?]', ' '))\
                #.withColumn("NCRM_Structure_Next_Steps__c", F.regexp_replace(col("NCRM_Structure_Next_Steps__c"), '[^a-zA-Z0-9,.()/!@#$%^&*-_+:;<>?]', ' '))\
                #.withColumn("Name", F.regexp_replace(col("Name"), '[^a-zA-Z0-9,.()/!@#$%^&*-_+:;<>?]', ' '))\
                
    print('row1 data ---->')
    row1.show()

#    print ("Test Data1")
#    row1.select("NCRM_DG_Stage_3_Date__c").show(truncate=False)

    insert = (row1
         .select(
             expr("substr(NCRM_Opportunity__c,1,18)").alias('NCRM_Opportunity__c'),
             F.when(row1.NCRM_DG_Stage_3_Date__c == F.lit(""), None)
             .otherwise(
                 F.when(F.length(row1.NCRM_DG_Stage_3_Date__c) > F.lit(10),
                        F.to_timestamp(row1.NCRM_DG_Stage_3_Date__c, "yyyy-MM-dd HH:mm:ss"))
                 .otherwise(F.date_format(row1.NCRM_DG_Stage_3_Date__c, "yyyy-MM-dd HH:mm:ss.SSSZ")))
             .alias('dgstage3_date'),
             expr("substr(NCRM_Team_Region__c,1,530)").alias('dg_region'),
             row1.dgstage5_date.alias('dgstage5_date'),
             row1.batch_id.alias('batch_id'),
             row1.source_system.alias('source_system'),
             row1.created_by.alias('created_by'),
             row1.created_dttm.alias('created_dttm'),
             row1.modified_by.alias('modified_by'),
             row1.modified_dttm.alias('modified_dttm'),
             expr("substr(Name,1,530)").alias('name'),
             row1.CreatedDate.alias('created_date'),
             row1.RecordTypeId.alias('record_type_id'),
             row1.NCRM_CurrentYearGrossMarginProbAdjusted__c.alias('ncrm_current_year_gross_margin_probadjusted__c'),
             row1.NCRM_CurrentYearGrossMarginProbFormula__c.alias('ncrm_current_year_gross_margin_probformula__c'),
             row1.NCRM_Current_Year_Gross_Margin_Formula__c.alias('ncrm_current_year_gross_margin_formula__c'),
             row1.NCRM_Current_Year_Gross_Margin__c.alias('ncrm_current_year_gross_margin__c'),
             row1.NCRM_Estimated_Close_Date__c.alias('ncrm_estimated_close_date__c'),
             row1.NCRM_Estimated_End_Date__c.alias('ncrm_estimated_end_date__c'),
             row1.NCRM_Estimated_Start_Date__c.alias('ncrm_estimated_start_date__c'),
             row1.NCRM_Estimated_Trade_Date__c.alias('ncrm_estimated_trade_date__c'),
             row1.NCRM_FutureYearGrossMarginProbAdjusted__c.alias('ncrm_future_year_gross_margin_probadjusted__c'),
             row1.NCRM_FutureYearGrossMarginProbFormula__c.alias('ncrm_future_year_gross_margin_probformula__c'),
             row1.NCRM_Future_Year_Gross_Margin_Formula__c.alias('ncrm_future_year_gross_margin_formula__c'),
             row1.NCRM_Future_Year_Gross_Margin__c.alias('ncrm_future_year_gross_margin__c'),
             row1.NCRM_OriginatorEstimatedTotalFormula__c.alias('ncrm_originator_estimated_total_formula__c'),
             row1.NCRM_OriginatorEstimatedTotalGrossMargin__c.alias('ncrm_originator_estimated_total_gross_margin__c'),
             row1.NCRM_Parent_Opportunity_Group__c.alias('ncrm_parent_opportunity_group__c'),
             row1.NCRM_Power_Top_Prospect__c.alias('ncrm_power_top_prospect__c'),
             row1.NCRM_State_of_Delivery_Point__c.alias('ncrm_state_of_delivery_point__c'),
             row1.NCRM_Request_Structure_Team_Assistance__c.alias('ncrm_request_structure_team_assistance__c'),
             expr("substr(NCRM_Structure_Next_Steps__c,1,131072)").alias('ncrm_structure_next_steps__c'),
             row1.NCRM_TotalGrossMarginProbAdjusted__c.alias('ncrm_total_gross_margin_probadjusted__c'),
             row1.NCRM_TotalGrossMarginProbFormula__c.alias('ncrm_total_gross_margin_probformula__c'),
             row1.NCRM_Total_Gross_Margin_Calculation__c.alias('ncrm_total_gross_margin_calculation__c'),
             row1.NCRM_Total_Gross_Margin_Formula__c.alias('ncrm_total_gross_margin_formula__c'),
             row1.NCRM_Trade_Date__c.alias('ncrm_trade_date__c'),
             row1.NCRM_Type__c.alias('ncrm_type__c'),
             expr("substr(NCRM_Deal_Valuation_Notes__c,1,131072)").alias('ncrm_deal_valuation_notes__c'),
             row1.NCRM_State__c.alias('ncrm_state__c'),
             row1.NCRM_Commodity__c.alias('ncrm_commodity__c'),
             row1.NCRM_Actual_Start_Date__c.alias('NCRM_Actual_Start_Date__c'),
             row1.NCRM_Actual_End_Date__c.alias('NCRM_Actual_End_Date__c'),
             row1.NCRM_Deal_Structure__c.alias('NCRM_Deal_Structure__c'),
             row1.NCRM_Total_Trade_P_L_FF__c.alias('NCRM_Total_Trade_P_L_FF__c'),
             row1.NCRM_Total_Minimum_Volume_Quantity__c.alias('NCRM_Total_Minimum_Volume_Quantity__c'),
             row1.NCRM_TotalMinimumVolumeQuantity_Formula__c.alias('NCRM_TotalMinimumVolumeQuantity_Formula__c'),
             row1.NCRM_Volume_Quantity_Unit__c.alias('NCRM_Volume_Quantity_Unit__c'),
             row1.Id.alias('Id')
         )
)

    insert1 = insert.withColumn("dgstage3_date", to_utc_timestamp(insert.dgstage3_date, 'America/New_York'))
    insert = insert1.withColumn("dgstage3_date", F.date_format(insert1.dgstage3_date, "yyyy-MM-dd HH:mm:ss.SSSZ"))\
    .withColumn("NCRM_Total_Trade_P_L_FF__c", round(insert1.NCRM_Total_Trade_P_L_FF__c, 2))

    
#    print ("Test Data3 utc")
#    insert.select("dgstage3_date").show(truncate=False)
    

    OnComponentOk5 = insert.select(
    	insert.NCRM_Opportunity__c.alias('NCRM_Opportunity__c'),
    	insert.dgstage3_date.alias('dgstage3_date'),
    	insert.dg_region.alias('dg_region'),
    	insert.dgstage5_date.alias('dgstage5_date'),
    	insert.batch_id.alias('batch_id'),
    	insert.source_system.alias('source_system'),
    	insert.created_by.alias('created_by'),
    	insert.created_dttm.alias('created_dttm'),
    	insert.modified_by.alias('modified_by'),
    	insert.modified_dttm.alias('modified_dttm'),
		insert.Id.alias('Id'),
		insert.created_date.alias('created_date'),
		insert.record_type_id.alias('record_type_id'),
		insert.ncrm_current_year_gross_margin_probadjusted__c.alias('ncrm_current_year_gross_margin_probadjusted__c'),
		insert.ncrm_current_year_gross_margin__c.alias('ncrm_current_year_gross_margin__c'),
		insert.ncrm_estimated_close_date__c.alias('ncrm_estimated_close_date__c'),
		insert.ncrm_estimated_end_date__c.alias('ncrm_estimated_end_date__c'),
    	insert.ncrm_estimated_start_date__c.alias('ncrm_estimated_start_date__c'),
    	insert.ncrm_estimated_trade_date__c.alias('ncrm_estimated_trade_date__c'),
		insert.ncrm_future_year_gross_margin_probadjusted__c.alias('ncrm_future_year_gross_margin_probadjusted__c'),
		insert.ncrm_future_year_gross_margin__c.alias('ncrm_future_year_gross_margin__c'),
		insert.ncrm_originator_estimated_total_gross_margin__c.alias('ncrm_originator_estimated_total_gross_margin__c'),
    	insert.ncrm_parent_opportunity_group__c.alias('ncrm_parent_opportunity_group__c'),
		insert.ncrm_power_top_prospect__c.alias('ncrm_power_top_prospect__c'),
    	insert.ncrm_state_of_delivery_point__c.alias('ncrm_state_of_delivery_point__c'),
    	insert.ncrm_request_structure_team_assistance__c.alias('ncrm_request_structure_team_assistance__c'),
		insert.ncrm_total_gross_margin_probadjusted__c.alias('ncrm_total_gross_margin_probadjusted__c'),
		insert.ncrm_total_gross_margin_calculation__c.alias('ncrm_total_gross_margin_calculation__c'),
		insert.ncrm_trade_date__c.alias('ncrm_trade_date__c'),
    	insert.ncrm_type__c.alias('ncrm_type__c'),
		insert.ncrm_state__c.alias('ncrm_state__c'),
		insert.ncrm_commodity__c.alias('ncrm_commodity__c'),		
    	insert.name.alias('name'),   	
    	insert.ncrm_current_year_gross_margin_probformula__c.alias('ncrm_current_year_gross_margin_probformula__c'),
    	insert.ncrm_current_year_gross_margin_formula__c.alias('ncrm_current_year_gross_margin_formula__c'),   	
    	insert.ncrm_future_year_gross_margin_probformula__c.alias('ncrm_future_year_gross_margin_probformula__c'),
    	insert.ncrm_future_year_gross_margin_formula__c.alias('ncrm_future_year_gross_margin_formula__c'),
    	insert.ncrm_originator_estimated_total_formula__c.alias('ncrm_originator_estimated_total_formula__c'),
    	insert.ncrm_total_gross_margin_probformula__c.alias('ncrm_total_gross_margin_probformula__c'),
    	insert.ncrm_total_gross_margin_formula__c.alias('ncrm_total_gross_margin_formula__c'),
		insert.NCRM_Actual_Start_Date__c.alias('NCRM_Actual_Start_Date__c'),
    	insert.NCRM_Actual_End_Date__c.alias('NCRM_Actual_End_Date__c'),
		insert.NCRM_Deal_Structure__c.alias('NCRM_Deal_Structure__c'),
    	insert.NCRM_Total_Trade_P_L_FF__c.alias('NCRM_Total_Trade_P_L_FF__c'),
		insert.NCRM_Total_Minimum_Volume_Quantity__c.alias('NCRM_Total_Minimum_Volume_Quantity__c'),
    	insert.NCRM_TotalMinimumVolumeQuantity_Formula__c.alias('NCRM_TotalMinimumVolumeQuantity_Formula__c'),
		insert.NCRM_Volume_Quantity_Unit__c.alias('NCRM_Volume_Quantity_Unit__c'),		
    	insert.ncrm_structure_next_steps__c.alias('ncrm_structure_next_steps__c'),
    	insert.ncrm_deal_valuation_notes__c.alias('ncrm_deal_valuation_notes__c')
    )
    
#    print ("Test Data3")
#    insert.select("dgstage3_date").show(truncate=False)
    
    staging_file = staging_path+ "stg_file/"
    OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite",quote='"', escape='"')
    
#    staging_file = staging_path+ "stg_json_file/"
#    OnComponentOk5.write.json(staging_file, mode="overwrite")

#    staging_file = staging_path+ "stg_parquet_file/"
#    OnComponentOk5.write.parquet(staging_file, mode="overwrite")

# Write DataFrame to Parquet format in S311s3_path = "s3a://your-bucket-name/path/to/users.parquet"12df.write.parquet(s3_path, mode="overwrite")
#    S311s3_path = "s3a://your-bucket-name/path/to/users.parquet"12df.write.parquet(s3_path, mode="overwrite")
#    COPY users2FROM 's3://your-bucket-name/path/to/users.parquet'3IAM_ROLE 'arn:aws:iam::your-account-id:role/your-redshift-role'4FORMAT AS PARQUET;

    copy_query1 = f"""COPY vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_details_raw FROM 
    '{staging_file}' iam_role '{iam_role}' 
    FORMAT CSV delimiter '|' QUOTE '"' ignoreheader 1 maxerror 100"""   
    #    FORMAT AS JSON 'auto' TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""


#    FORMAT AS JSON 'auto' TIMEFORMAT AS 'auto' EMPTYASNULL BLANKSASNULL"""


    statement = connection.createStatement()
    print ("copy query")
    print (copy_query1)
    statement.executeUpdate(copy_query1)
    statement.close()
    
    
    count_query = f"""(SELECT * FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_details_raw)"""
    
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    insert_query = f"""INSERT INTO vendor_customer_opportunities_raw.sfdc_neercrm_opportunity_details_raw SELECT ncrm_opportunity__c,dgstage3_date,dg_region,dgstage5_date,batch_id,source_system,created_by,created_dttm,modified_by,modified_dttm,created_date,record_type_id,ncrm_current_year_gross_margin_probadjusted__c,ncrm_current_year_gross_margin__c,ncrm_estimated_close_date__c,ncrm_estimated_end_date__c,ncrm_estimated_start_date__c,ncrm_estimated_trade_date__c,ncrm_future_year_gross_margin_probadjusted__c,ncrm_future_year_gross_margin__c,ncrm_originator_estimated_total_gross_margin__c,ncrm_parent_opportunity_group__c,ncrm_power_top_prospect__c,ncrm_state_of_delivery_point__c,ncrm_request_structure_team_assistance__c,ncrm_total_gross_margin_probadjusted__c,ncrm_total_gross_margin_calculation__c,ncrm_trade_date__c,ncrm_type__c,ncrm_state__c,ncrm_commodity__c,name,ncrm_current_year_gross_margin_probformula__c,ncrm_current_year_gross_margin_formula__c,ncrm_future_year_gross_margin_probformula__c,ncrm_future_year_gross_margin_formula__c,ncrm_originator_estimated_total_formula__c,ncrm_total_gross_margin_probformula__c,ncrm_total_gross_margin_formula__c,ncrm_actual_start_date__c,ncrm_actual_end_date__c,ncrm_deal_structure__c,ncrm_total_trade_p_l_ff__c,ncrm_total_minimum_volume_quantity__c,ncrm_totalminimumvolumequantity_formula__c,ncrm_volume_quantity_unit__c,ncrm_structure_next_steps__c,ncrm_deal_valuation_notes__c,id FROM vendor_customer_opportunities_staging.stg_sfdc_neercrm_opportunity_details_raw"""   
    statement = connection.createStatement()
    statement.executeUpdate(insert_query)
    statement.close()
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_status = 'Batch Successful'
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    # On successful export of data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Success Email not sent, with error_code = {status_code}"
        )
    logger.info("Script executed successfully......  check data in redshift")

    cloudwatch.log_to_stream(
        "Writing  data to redshift has been successfully done.."
    )
    job.commit()
except Exception as e:
    logger.info(f"Job failed with following error ......{e}")
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', batch_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(
            f"Failure Email not sent, with error_code = {status_code}"
        )
    error_message = f"Job failed with following error: {str(e)}"
    logger.info(error_message)
    cloudwatch.log_to_stream(error_message)
    sns_publish(
        sns_arn,
        "Glue Job Failure",
        f"{job_name} failed with error: {str(e)}"
    )
    raise e
