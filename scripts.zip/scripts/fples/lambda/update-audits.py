import json, time, re, os, sys
import boto3
import dateutil, time
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from redshiftutils.gmputils import connection as cn
from redshiftutils.gmputils import cloudwatch_logging as cwl

JOB_NAME        =""
RS_SECRET       =""
REGION_NAME     =""

params = { "pipeline_name": os.environ['pipeline_name'], "log_group_name": os.environ['log_group_name'] }

audit_schema = os.environ['audit_schema']
audit_table = os.environ['audit_table']
environment = os.environ['environment']
sns_arn = os.environ['sns_arn']

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        print(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag, job_name, environment, error):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = cn.timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name   :  {environment},
            Job Status  :  Failure ,
            Job Failure Reason  :  {error},
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda  
        """
        success_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name  :  {environment},
            Job Status  :  Success,
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda
        """
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_FPLES_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        print(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def lambda_handler(event, context):
    # TODO implement
    ##batch_start_dttm  = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
    payload     = event.get('Payload').get('payload')
    records_fetched =   payload.get('records_fetched')
    job_end_dttm = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3] 
    batch_id = payload.get('batch_id')
    etl_batch_id=payload.get('etl_batch_id')
    api_response_code = event.get('Payload').get('api_response_code')
    batch_start_dttm    = event.get('Payload').get('batch_start_dttm')
    job_name = payload.get("job_name")
    environment = payload.get("environment")
    error= payload.get("error")
    CLOUDWATCH = cwl.Handler( params, etl_batch_id)
    
    
    
    _secret = cn.get_secret(payload.get('rs_secret'), payload.get('region_name'),CLOUDWATCH )
    CLOUDWATCH.log_to_stream( ' secret received ')
    
    rs_conn = cn.get_redshift_conn(_secret, REGION_NAME)
    CLOUDWATCH.log_to_stream(' after getting RS connection ')
    cursor = rs_conn.cursor() 
    try:
        insert_stmt = cn.insert_audit(payload.get('batch_id'), payload.get('batch_start_dttm'), payload.get('batch_status'), 
            payload.get('load_type'), payload.get('last_load_dttm'), payload.get('project_name'), 
            payload.get('source_system') , payload.get('stage_name'),  
            payload.get('job_name'), payload.get('created_dttm'),
            payload.get('target_table'), payload.get('landing_zone'),records_fetched,
            payload.get('created_dttm'), job_end_dttm,audit_schema,audit_table)
        
        
        CLOUDWATCH.log_to_stream('Insert Statement  ' + insert_stmt  )
        cursor.execute(insert_stmt) 
        
        batch_status = ''
        batch_end_dttm  = cn.timestamp_generator('%Y-%m-%d %H:%M:%S.%f')[:-3]
        modified_dttm   = cn.timestamp_generator('%Y-%m-%d %H:%M:%S.%f')[:-3]

        
        if records_fetched == 0 and api_response_code == 200:
            batch_status = 'Batch Successful'
            CLOUDWATCH.log_to_stream(' update batch status executed successfully ')
            update_btch_status1 = f"update {audit_schema}.{audit_table} set batch_status = '{batch_status}', batch_end_dttm ='{batch_end_dttm}', modified_dttm ='{modified_dttm}', last_load_dttm =batch_start_dttm where batch_id = '{payload.get('batch_id')}';"
            CLOUDWATCH.log_to_stream(update_btch_status1)
            cursor.execute(update_btch_status1) 
        elif records_fetched != 0 and api_response_code == 200:
            batch_status = 'Batch Started'
            CLOUDWATCH.log_to_stream(' update batch status executed successfully ')
            update_btch_status1 = f"update {audit_schema}.{audit_table} set batch_status = '{batch_status}',  last_load_dttm =batch_start_dttm where batch_id = '{payload.get('batch_id')}';"
            CLOUDWATCH.log_to_stream(update_btch_status1)
            cursor.execute(update_btch_status1) 
        else:
            batch_status = 'Batch Failed'
            CLOUDWATCH.log_to_stream(' update batch status failure ')
            update_btch_status2 = f"update {audit_schema}.{audit_table} set batch_status = '{batch_status}', error_msg ='{error}' where batch_id = '{payload.get('batch_id')}' and job_name = '{payload.get('job_name')}' and batch_start_dttm = '{payload.get('batch_start_dttm')}' ;"
            CLOUDWATCH.log_to_stream(update_btch_status2)
            cursor.execute(update_btch_status2)
        
        cursor.close()
        rs_conn.commit()
        rs_conn.close()
        CLOUDWATCH.log_to_stream(' after closing the connection ')
        
        '''email_content = generate_email_body("success", job_name, environment, "")
        email_sub = email_content[0]
        email_body = email_content[1]
        CLOUDWATCH.log_to_stream("Publishing SNS email")
        # Calling SNS publish function to publish email to end-subscribers
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            CLOUDWATCH.log_to_stream("Success Email sent successfully")
        else:
            CLOUDWATCH.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
        CLOUDWATCH.log_to_stream("Script executed successfully......  check data in redshift")'''
        return {
        'statusCode'    : api_response_code,
        'records_fetched' : records_fetched,
        'payload'       : payload,
        'environment': event.get('Payload').get('environment'),
        'sns_message'   :  event.get('Payload').get('sns_message')
        }
    except Exception as e:
        payload = event.get("Payload")
        error = str(e).replace("'", '"')
        email_content = generate_email_body("failure", job_name, environment, error = str(e))
        email_sub = email_content[0]
        email_body = email_content[1]
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            print("Failure Email sent successfully")
        else:
            print(f"Failure Email not sent, with error_code = {status_code}")
        error_message = f"Job failed with following error: {str(e)}"
        print(error_message)
        print('exception raised ' + str(e))
        
    return {
        'statusCode': event.get('Payload', {}).get('api_response_code', 500),
        'records_fetched': event.get('Payload', {}).get('records_fetched', 0),
        'payload'       : payload,
        'environment': event.get('Payload').get('environment'),
        'sns_message'   :  event.get('Payload').get('sns_message')
    }
