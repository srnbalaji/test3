import sys, re
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim
from pyspark.sql import functions as F
from pyspark.sql.functions import col, struct, when, length, upper, trim, lit
import json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
from pyspark.sql.functions import when, lit, col, trim, to_timestamp

args = getResolvedOptions(sys.argv,["environment","job_name","extra_params","batch_id"])
extra_params_obj = config.EXTRA_PARAMS_FPLES_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
batch_id = args['batch_id']
file_name = extra_params_obj.get("file_name")
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name  = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
landing_zone = extra_params_obj.get("landing_zone")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
target_table_schema = extra_params_obj.get("target_table_schema")
target_table_name = extra_params_obj.get("target_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")

redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
sns_arn = config.sns_arn[environment]
log_group = config.LOG_FILES_Fples[environment]
staging_path = s3_staging_config+"/output/"+file_name+"/staging/"+file_name+".csv"

# job initialization
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

#logger initialization
logger = glueContext.get_logger()
# import psycopg2

#spark object creation
job = Job(glueContext)
job.init(job_name)


params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
}
log_file_name = params["log_group_name"]

#Declare SNS_Publisher
def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        logger.info(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

#Email body contents
def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error_message,
                log_group=log_file_name,
                log_stream=etl_batch_id,
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_FPLES_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        logger.info(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        eastern_timeZone = dateutil.tz.gettz("US/Eastern")
        result = datetime.now(tz=eastern_timeZone).strftime(format)

        return result

    except Exception as e:
        raise e

# Setup CloudWatch logging
etl_batch_id = f"{job_name}_" + timestamp_generator("%Y%m%d%H%M%S")
cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")

#batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]

#Email body contents

redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)
redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"

redshift_properties = spark._jvm.java.util.Properties()
redshift_properties.setProperty("url", redshift_jdbc_url)
redshift_properties.setProperty("user", redshift_user)
redshift_properties.setProperty("password", redshift_password)
redshift_properties.setProperty("redshiftTmpDir", redshift_temp_dir)
redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
redshift_properties.setProperty("connectionName", redshift_connection_name)

try:
    
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    sql_stmt = """(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
               from vendor_customer_opportunities_raw.edp_axis_batch_control_log where target_table_name = 'edp_axis_sfdc_neercrm_raw_base_opportunity_details') custom"""
               
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
    
    '''insert_audit = f"""INSERT INTO {audit_schema}.{audit_table}(batch_id 	,batch_start_dttm 	,batch_status 	,load_type,last_load_dttm,project_name 	,source_system 	,stage_name 	,job_name 	,job_start_dttm ,target_table_name 	,landing_zone 	,created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()'''
    
    query =  f"""DELETE FROM {staging_table_schema}.{staging_table_name}"""
    statement = connection.createStatement()
    statement.executeUpdate(query)
    statement.close()
    
    staging_path= s3_staging_config+"/output/fples_source_raw_user/staging/"
    
    custom_options = {
    "escape": "\\",
    "quote": "'"
    }
    
    row1 = spark.read.option("escape", custom_options["escape"]) \
    .option("quote", custom_options["quote"]) \
    .option("multiline","True").json(staging_path)
    row1.show()
    print(row1.count())
    
    '''row2 = row1.withColumnRenamed(row1.columns[0],'Id')\
    	.withColumnRenamed(row1.columns[1],'AccountId')\
    	.withColumnRenamed(row1.columns[2],'Email')\
    	.withColumnRenamed(row1.columns[3],'FirstName')\
    	.withColumnRenamed(row1.columns[4],'LastName')\
    	.withColumnRenamed(row1.columns[5],'Title')\
    	.withColumnRenamed(row1.columns[6],'Department')\
    	.withColumnRenamed(row1.columns[7],'MobilePhone')\
    	.withColumnRenamed(row1.columns[8],'LastModifiedDate')\
    	.withColumnRenamed(row1.columns[9],'FederationIdentifier')'''
    
    row1 = row1.drop('attributes')
    
    insert = row1.select(
        trim(expr("substr(Id,1,72)")).alias('system_id'),
        trim(expr("substr(AccountId,1,72)")).alias('account_id'),
        trim(expr("substr(Email,1,200)")).alias('email'),
        trim(expr("substr(FirstName,1,40)")).alias('first_name'),
        trim(expr("substr(LastName,1,60)")).alias('last_name'),
        trim(expr("substr(Title,1,80)")).alias('title'),
        trim(expr("substr(Department,1,160)")).alias('department'),
        trim(expr("substr(MobilePhone,1,40)")).alias('cell_phone'),
        (when(((col('FederationIdentifier').isNotNull()) & (length(col('FederationIdentifier')) == lit(7)) & (col('FederationIdentifier').substr(4, 1) == lit(0))), upper(trim(col('FederationIdentifier')))).otherwise(lit(None))).alias('user_slid'),
        (col('FederationIdentifier').substr(4, 1)).alias('fedIden'),
        lit('FPLES').alias('owner'),
        lit('Internal').alias('contact_identifier'),
        lit(batch_id).alias('batch_id'),
        lit('Salesforce-FPLES-User').alias('source_system'),
        lit('glue_dev').alias('created_by'),
        date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('created_dttm'),    
        lit('glue_dev').alias('modified_by'),
        date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS").alias('modified_dttm'))
    
    
    insert.show()
    OnComponentOk5 = insert.select(
    	insert.system_id.alias('system_id'),
    	insert.account_id.alias('account_id'),
    	insert.email.alias('email'),
    	insert.first_name.alias('first_name'),
    	insert.last_name.alias('last_name'),
    	insert.title.alias('title'),
    	insert.department.alias('department'),
    	insert.cell_phone.alias('cell_phone'),
    	insert.owner.alias('owner'),
    	insert.contact_identifier.alias('contact_identifier'),
    	insert.user_slid.alias('user_slid'),
    	insert.batch_id.alias('batch_id'),
    	insert.source_system.alias('source_system'),
    	insert.created_by.alias('created_by'),
    	insert.created_dttm.alias('created_dttm'),
    	insert.modified_by.alias('modified_by'),
    	insert.modified_dttm.alias('modified_dttm')
    )
    
    OnComponentOk5.show()
        
    staging_file = staging_path+ "stg_file/"
    OnComponentOk5.write.csv(path=staging_file, sep='|', header=True, mode="overwrite") 
    
    copy_query1 = f"""COPY {staging_table_schema}.{staging_table_name} FROM '{staging_path}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' IGNOREHEADER 1"""   
    statement = connection.createStatement()
    statement.executeUpdate(copy_query1)
    statement.close()
    
    count_query = f"""(SELECT * FROM {staging_table_schema}.{staging_table_name}) custom"""
    redshift_spark_df = spark.read.jdbc(redshift_jdbc_url,count_query,properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    update_query = f"""UPDATE {target_table_schema}.{target_table_name}
    SET system_id = stg_fples_contact_raw.system_id
    ,account_id = stg_fples_contact_raw.account_id
    ,email = stg_fples_contact_raw.email
    ,first_name = stg_fples_contact_raw.first_name
    ,last_name = stg_fples_contact_raw.last_name
    ,title = stg_fples_contact_raw.title
    ,department = stg_fples_contact_raw.department
    ,cell_phone = stg_fples_contact_raw.cell_phone
    ,owner = stg_fples_contact_raw.owner
    ,contact_identifier = stg_fples_contact_raw.contact_identifier
    ,user_slid= stg_fples_contact_raw.user_slid
    ,batch_id = stg_fples_contact_raw.batch_id
    ,source_system = stg_fples_contact_raw.source_system
    ,created_by = stg_fples_contact_raw.created_by
    ,created_dttm = stg_fples_contact_raw.created_dttm
    ,modified_by = stg_fples_contact_raw.modified_by
    ,modified_dttm = stg_fples_contact_raw.modified_dttm
    FROM vendor_customer_opportunities_raw.stg_fples_contact_raw
    WHERE fples_contact_raw.system_id = stg_fples_contact_raw.system_id"""
    
    statement = connection.createStatement()
    statement.executeUpdate(update_query)
    statement.close()
    
    insert_query = f"""INSERT INTO {target_table_schema}.{target_table_name}
    SELECT stg_fples_contact_raw.*
    FROM vendor_customer_opportunities_raw.stg_fples_contact_raw
    LEFT JOIN vendor_customer_opportunities_raw.fples_contact_raw
    ON stg_fples_contact_raw.system_id = fples_contact_raw.system_id
    WHERE fples_contact_raw.system_id IS NULL"""
    
    statement = connection.createStatement()
    statement.executeUpdate(insert_query)
    statement.close()
    
    #On successful export of maximo data to redshift, generating success email content.
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful',stage_name='{stage_name}',records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    # On successful export of maximo data to redshift, generating success email content.
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    # Calling SNS publish function to publish email to end-subscribers
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
    cloudwatch.log_to_stream("Writing  data to redshift has been successfully done..")
    job.commit()
except Exception as e:
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error_message = str(e).replace("'", '"')
    # Step 2: Remove escape characters
    error_message = re.sub(r'\\.', '', error_message)
    # Step 3: Trim the string to the first 2000 characters
    error_message = error_message[:2000]
    print(error_message)
    error_update_query = f"""Update {audit_schema}.{audit_table} set error_msg = '{error_message}', job_status='Job Failed' where batch_id = '{batch_id}' """
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
    statement = connection.createStatement()
    statement.executeUpdate(error_update_query)
    statement.close()
    connection.close()
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
    error_message = f"Job failed with following error: {str(e)}"
    cloudwatch.log_to_stream(error_message)
    sns_publish(sns_arn,"Glue Job Failure",f"{job_name} failed with error: {str(e)}")
    raise e