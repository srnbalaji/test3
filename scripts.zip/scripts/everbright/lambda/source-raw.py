import json
import urllib, requests
from urllib.parse import urlparse
import sys
import boto3
import dateutil
import time
import datetime
import os
from datetime import datetime
import io
from sfutils.gmputils import connection as cn
from sfutils.gmputils import cloudwatch_logging as cwl
from axisconfig.gmputils import sp_config_axis as config



FULL_LOAD       =   os.environ['FULL_LOAD']
DELTA_LOAD      =   os.environ['DELTA_LOAD']
full_url_end_point = ""
environment = os.environ['environment']
sns_arn = os.environ['sns_arn']

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        print(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag, job_name, environment, error):
    
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = cn.timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name   :  {environment},
            Job Status  :  Failure ,
            Job Failure Reason  :  {error},
            Lambda Name  :  Source-raw,
            Service  :  AWS - Lambda  
        """
        success_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name  :  {environment},
            Job Status  :  Success,
            Message : zero records fetched,
            Lambda Name : source-raw,
            Service  :  AWS - Lambda
        """
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_EVERBRIGHT_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        print(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e

    
def lambda_handler(event, context):
    # TODO implement
    payload             = event.get('Payload')
    rs_secret           = payload.get('rs_secret')
    sf_secret           = payload.get('sf_secret')
    environment         = payload.get('environment')
    last_load_dttm      = payload.get('last_load_dttm')
    job_name            = payload.get('job_name')
    region_name         = payload.get('region_name')
    batch_id            = payload.get('batch_id')
    landing_zone        = payload.get('landing_zone')
    load_type           = payload.get('load_type')
    params              = payload.get('params')
    api_response_code   = event.get('Payload').get('api_response_code') 
    etl_batch_id                = payload.get("etl_batch_id")
    CLOUDWATCH = cwl.Handler(params, etl_batch_id)
    
    try:
        csv_path = landing_zone.replace('json','csv')
        CLOUDWATCH      =   cwl.Handler( params, batch_id)
        s3_client = boto3.client('s3')
        s3_bucket = config.s3_staging_path[environment].split('/')[2]
        
        s3_object_name  = os.environ['s3_object_key']
        
        
        CLOUDWATCH.log_to_stream(' last load date : ---- > ' + last_load_dttm)
        CLOUDWATCH.log_to_stream(' secret_name ' + rs_secret + ' s3_bucket ' + s3_bucket + ' object name ' + s3_object_name )

        jsecret = cn.get_secret(sf_secret, region_name,CLOUDWATCH)
        
        CLOUDWATCH.log_to_stream( ' received secret ' )
        url_end_pt = jsecret.get('urlEndpoint').replace('query/?','query/?q=')
    
        
        purl = urlparse(url_end_pt)
        base_url  = purl.scheme +'://' + purl.netloc + '/'
        
        resp = cn.get_token(jsecret)
        CLOUDWATCH.log_to_stream(' access response received ')
        
        access_token = resp.get('access_token')
        CLOUDWATCH.log_to_stream(' access token recieved  ' )
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + access_token }
        
        
        if load_type.upper() == FULL_LOAD:
            full_url_end_point = url_end_pt + payload.get('soql_query').replace('+where+LastModifiedDate+>+{last_load_dttm}','' )
            
            
        elif load_type.upper() == DELTA_LOAD :
            sf_formatted_date = cn.convert_datetime_to_sf_format(last_load_dttm)
            full_url_end_point = url_end_pt + payload.get('soql_query').replace('{last_load_dttm}',sf_formatted_date )
            
        else:
            CLOUDWATCH.log_to_stream("Warning : Not a valid load type, it should be FULL or DELTA")
            
        #CLOUDWATCH.log_to_stream(' full URL end point ' + full_url_end_point )
        print(' full URL end point ' + full_url_end_point )
        
        ###Delete existing csv files
        delete_csv = cn.list_s3_csv_files(s3_client,s3_bucket,csv_path)
        if len(delete_csv) != 0:
            for object in delete_csv:
                s3_client.delete_object(Bucket=s3_bucket, Key=object) 

        #Delete the previous run json files from the path
        delete_json = cn.list_s3_files(s3_client,s3_bucket,landing_zone)
        if len(delete_json) != 0:
            for object in delete_json:
                s3_client.delete_object(Bucket=s3_bucket, Key=object)       	
        
        __done = False
        records = []  
        write_count = 0 
        records_fetched_count = 0
        api_response_code = 0
        
        while not __done:
            try:
                response = requests.get(full_url_end_point, headers=headers)
                api_response_code = response.status_code
                if response.status_code == 200:
                    CLOUDWATCH.log_to_stream(' inside IF. response. status ' +  str(response.status_code) )
                    data = json.loads(response.text)
                    records_fetched_count = data['totalSize']
                    
                    CLOUDWATCH.log_to_stream(' ----- done ' + str(data['done']) + ' totalSize ' + str(data['totalSize'])  )
                    if data.get('nextRecordsUrl') is not None:
                        CLOUDWATCH.log_to_stream(' nextRecordsUrl ----- > ' + str(data.get('nextRecordsUrl')) )
                        
                    if len(data['records']) > 0 :
                        records.extend(data['records'])
                    if len(records) >= 10000:
                        filename= landing_zone.rstrip('/') + '/' + batch_id + '_' + str(write_count) + '.json'
                        
                        CLOUDWATCH.log_to_stream('s3 bucket name ' + s3_bucket + '-------- the filename -------> ' + filename)
                        cn.write_to_s3(records, s3_bucket, filename)
                        write_count+=1
                        records.clear()
                    if data['done']:
                        __done = True
                        CLOUDWATCH.log_to_stream(' stopping here....')
                    else:    
                        full_url_end_point =  base_url.rstrip('/')+'/'+data.get('nextRecordsUrl').lstrip('/')
                        CLOUDWATCH.log_to_stream(' callign the next url ' + full_url_end_point )
                else:
                    __done = True
                    raise Exception(f"{job_name} Lambda failed with following Error  {str(response.text)}")
            except Exception as e:
                CLOUDWATCH.log_to_stream(f"{job_name} Lambda failed with following Error {str(response.text)}")
                raise e
            CLOUDWATCH.log_to_stream(' -------------no of records received ' + str(len(records)) )    
        
            filename = (
                landing_zone.rstrip("/") + "/" + batch_id + "_" + str(write_count) + ".json"
            )
            CLOUDWATCH.log_to_stream(
                "s3 bucket name " + s3_bucket + "-------- the filename -------> " + filename
            )
    
            cn.write_to_s3(records, s3_bucket, filename)
            payload["records_fetched"] = records_fetched_count
            payload["etl_batch_id"]=etl_batch_id
            if records_fetched_count == 0:
                email_content = generate_email_body("success", job_name, environment, "")
                email_sub = email_content[0]
                email_body = email_content[1]
                CLOUDWATCH.log_to_stream("Publishing SNS email")
                # Calling SNS publish function to publish email to end-subscribers
                status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
                if status_code == 200:
                    CLOUDWATCH.log_to_stream("Success Email sent successfully")
                else:
                    CLOUDWATCH.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
                CLOUDWATCH.log_to_stream("Script executed successfully......  check data in s3 folder")
            elif records_fetched_count > 0:
                CLOUDWATCH.log_to_stream("Script executed successfully......  check data in S3")
            else:
                raise Exception("job failed with no records fetched from source")
            return {
                "statusCode": 200,
                "job_name": job_name,
                "api_response_code": api_response_code,
                "body": "Successful execution of data extract from SF ( gexa-source-raw) ",
                "count": str(records_fetched_count),
                "last_load_date": last_load_dttm,
                "s3_bucket": s3_bucket,
                "payload": payload,
                "sns_message": "Successfully extracted data from SF API post date "
                + last_load_dttm
                + ". Count of records :"
                + str(records_fetched_count)
                + ". Written to  : "
                + s3_bucket
                + "/"
                + filename
                + " "
            }
    except Exception as e:
        payload = event.get("Payload")
        payload["records_fetched"] = records_fetched_count
        payload["etl_batch_id"]=etl_batch_id
        error = str(response.text).replace("'", '"')
        payload["error"] = error[:2000]
        email_content = generate_email_body("failure", job_name, environment, error)
        email_sub = email_content[0]
        email_body = email_content[1]
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            print("Failure Email sent successfully")
        else:
            print(f"Failure Email not sent, with error_code = {status_code}")
        error_message = f"Job failed with following error: {error}"
        print(error_message)
        print('exception raised ' + error_message)
        return {
            "statusCode": 500,
            "job_name": event.get('Payload').get('job_name'),
            "api_response_code": api_response_code,
            "body": "Execution of data extract from SF ( gexa-source-raw) Failed ",
            "count": str(records_fetched_count),
            "last_load_date": last_load_dttm,
            "s3_bucket": s3_bucket,
            "payload": payload,
            "sns_message": error[:2000], 
            "error": error[:2000], 
            "environment": event.get('Payload').get('environment')
            
        }
