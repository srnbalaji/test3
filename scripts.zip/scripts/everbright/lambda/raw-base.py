import json, time, re, os, sys
import boto3
import dateutil, time
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from redshiftutils.gmputils import connection as cn
from redshiftutils.gmputils import cloudwatch_logging as cwl
from axisconfig.gmputils import sp_config_axis as config


s3_key = os.environ['s3_key']
environment = os.environ['environment']
sns_arn = os.environ['sns_arn']

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        print(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag, job_name, environment, error):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = cn.timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name   :  {environment},
            Job Status  :  Failure ,
            Job Failure Reason  :  {error},
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda  
        """
        success_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name  :  {environment},
            Job Status  :  Success,
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda
        """
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_EVERBRIGHT_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        print(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def lambda_handler(event, context):
   
    payload                 = event.get('Payload').get('payload')
    batch_id                = payload.get('batch_id')
    s3_bucket               = event.get('Payload').get('s3_bucket')
    job_name                = payload.get('job_name')
    environment             = payload.get('environment')
    landing_zone            = payload.get('landing_zone')
    rs_secret               = payload.get('rs_secret')
    region_name             = payload.get('region_name')
    staging_schema_table    = payload.get('staging_table')
    target_schema_table     = payload.get('target_table')
    params                  = payload.get('params')
    api_response_code       = event.get('Payload').get('api_response_code')

    
    staging_path            = s3_key + s3_bucket + '/'+ event.get('Payload').get('staging_path')
    #staging_path = s3_key + s3_bucket + "/"+ "tmp/axis/everbright/output/edp_axis_sfdc_everbright_source_raw_event/staging/out/"
    iam_role                = config.iam_role[environment]['copy_cmd_role']
    CLOUDWATCH = cwl.Handler( params, batch_id)
    
    _secret = cn.get_secret(rs_secret,region_name,CLOUDWATCH )
    CLOUDWATCH.log_to_stream( ' secret received is ')
    
    rs_conn = cn.get_redshift_conn(_secret, region_name)
    CLOUDWATCH.log_to_stream(' after getting RS connection ')
    cursor = rs_conn.cursor() 
    
    staging_table_name = staging_schema_table.split('.')[1]
    target_table_name = target_schema_table.split('.')[1]
    update_query_tgt = ""
    insert_query_tgt = ""
   
    try:
        delete_query = f"""DELETE FROM {staging_schema_table}"""
        CLOUDWATCH.log_to_stream('delete Statement  ' + delete_query  )
        cursor.execute(delete_query) 
        
        copy_query = f"""COPY {staging_schema_table} FROM '{staging_path}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' IGNOREHEADER 1"""
        cursor.execute(copy_query)
        
        staging_count_query = f"""(SELECT COUNT(*) FROM {staging_schema_table} custom)"""
        cursor.execute(staging_count_query)  
        staging_count = cursor.fetchone()[0]
        CLOUDWATCH.log_to_stream("stage count --> "+str(staging_count))
        
        delete_tgt_query = f"""DELETE  FROM {target_schema_table}  USING  {staging_schema_table}
                            WHERE {target_table_name}.Id =  {staging_table_name}.Id"""
        cursor.execute(delete_tgt_query) 
        delete_count = cursor.rowcount
        CLOUDWATCH.log_to_stream(" Delete target completed with count "+str(delete_count))
        
        insert_tgt_query = f"""INSERT INTO {target_schema_table} SELECT * FROM {staging_schema_table}"""
        cursor.execute(insert_tgt_query)   
        insert_count = cursor.rowcount
        CLOUDWATCH.log_to_stream(" Insert target completed with count - "+str(insert_count))
        
        cursor.close()
        rs_conn.commit()
        rs_conn.close()
        CLOUDWATCH.log_to_stream(' after closing the connection ')
        return {
        'statusCode'        : 200,
        'payload'           : payload,
        'modified_dttm'     : event.get('Payload').get('modified_dttm'),
        'records_inserted'  : insert_count,        
        'sns_message'       : event.get('Payload').get('sns_message'),
        'api_response_code' : api_response_code
        }
    except Exception as e:
        payload = event.get("Payload")
        error = str(e).replace("'", '"')
        payload["error"] = error[:2000]
        email_content = generate_email_body("failure", job_name, environment, error)
        email_sub = email_content[0]
        email_body = email_content[1]
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            print("Failure Email sent successfully")
        else:
            print(f"Failure Email not sent, with error_code = {status_code}")
        error_message = f"Job failed with following error: {str(e)}"
        print(error_message)
        print('exception raised ' + str(e))
        return {
        'statusCode'        : 500,
        'error' : error[:2000]
        }
