import json, time, re, os, sys
import boto3
import dateutil, time
import pandas as pd
import csv
import datetime
from io import StringIO
from datetime import date
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from transformutils.gmputils import common_functions as cf
from redshiftutils.gmputils import connection as cn
from transformutils.gmputils import transform as tr
from transformutils.gmputils import cloudwatch_logging as cwl


created_by  = os.environ['created_by']
modified_by = os.environ['modified_by']
environment = os.environ['environment']
sns_arn = os.environ['sns_arn']

def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(TopicArn=sns_arn, Subject=email_sub, Message=email_body)
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        print(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag, job_name, environment, error):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = cn.timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name   :  {environment},
            Job Status  :  Failure ,
            Job Failure Reason  :  {error},
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda  
        """
        success_email_body = """
            Project Name  :  EDP_AXIS,
            Job Name  :  {job_name},
            Job RunDate  :  {run_date},
            Job Environment Name  :  {environment},
            Job Status  :  Success,
            Lambda Name : Update Audit,
            Service  :  AWS - Lambda
        """
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment=environment)
        else:
            email_body = failure_email_body.format(job_name=job_name, run_date=curnt_time_msg, environment= environment, error=error)
        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_EVERBRIGHT_{curnt_time_msg}"
        return [email_sub, email_body]

    except Exception as e:
        print(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def lambda_handler(event, context):
    # TODO implement
   
    payload         = event.get('Payload').get('payload')
    landing_zone    = payload.get('landing_zone')
    bucket          = event.get('Payload').get('s3_bucket')
    job_name        = payload.get('job_name')
    source_system   = payload.get('source_system')
    created_dttm    = payload.get('created_dttm')
    batch_id        = payload.get('batch_id')
    params          = payload.get('params')
    api_response_code = event.get('Payload').get('api_response_code')

    CLOUDWATCH  =  cwl.Handler( params, batch_id)
    try:
        s3_client = boto3.client('s3')
        csv_path = landing_zone.replace('json', 'csv/')
         
        CLOUDWATCH.log_to_stream(" CSV file path -->"+ csv_path)
        modified_dttm = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        
        
        json_filenames = cf.list_s3_files(s3_client,bucket,landing_zone) 
        
        json_data_list = []
        
        
        for file in json_filenames:
            csv_file_name = file.split('/')[-1].replace('.json','')
            json_data_list = cf.read_json_df(bucket,s3_client,file)
            df = pd.DataFrame(json_data_list)
            
            
            if len(df) != 0:
        
                df=df.drop('attributes', axis=1)
                if 'account' in job_name :
                    df = tr.transform_everbright_raw_base_account(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'contact' in job_name:
                    df = tr.transform_everbright_raw_base_contact(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'event' in job_name:
                    df = tr.transform_everbright_raw_base_event(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)  
                elif 'opportunity' in job_name:
                    df = tr.transform_everbright_raw_base_opportunity(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'task' in job_name:  
                    df = tr.transform_everbright_raw_base_task(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'user' in  job_name:
                    df = tr.transform_everbright_raw_base_user(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'lead' in  job_name:
                    df = tr.transform_everbright_raw_base_lead(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)
                elif 'hubspot' in  job_name:
                    df = tr.transform_everbright_raw_base_hubspot_intelligence(df,batch_id,source_system, created_by, created_dttm, modified_by, modified_dttm)            
                    
                    
                
                cf.write_csv_everbright(df,bucket,s3_client,csv_path,csv_file_name)
                CLOUDWATCH.log_to_stream("json data written to csv")
               
        
            else:
                cf.write_csv_everbright(df,bucket,s3_client,csv_path,csv_file_name) 
                CLOUDWATCH.log_to_stream("empty json data written to csv")
    except Exception as e:
        payload = event.get("Payload")
        error = str(e).replace("'", '"')
        payload["error"] = error[:2000]
        email_content = generate_email_body("failure", job_name, environment, error)
        email_sub = email_content[0]
        email_body = email_content[1]
        status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
        if status_code == 200:
            print("Failure Email sent successfully")
        else:
            print(f"Failure Email not sent, with error_code = {status_code}")
        error_message = f"Job failed with following error: {str(e)}"
        print(error_message)
        print('exception raised ' + str(e))
        return {
        'statusCode'    : 500,
        'payload'       : payload,
        'staging_path'  : csv_path,
        's3_bucket'     : bucket,
        'modified_dttm' : modified_dttm,
        'sns_message'   : error[:2000], 
        'error'         : error[:2000], 
        'api_response_code' : api_response_code
        }
       
    return {
        'statusCode'    : 200,
        'payload'       : payload,
        'staging_path'  : csv_path,
        's3_bucket'     : bucket,
        'modified_dttm' : modified_dttm,
        'sns_message'   : event.get('Payload').get('sns_message'),
        'api_response_code' : api_response_code
    }

