import sys
import boto3
import pyspark
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import cloudwatch_logging
import sp_config_axis as config
import dateutil
import time
from datetime import datetime, timedelta
from pyspark.sql.functions import col,lit
from pyspark.sql.functions import trim,regexp_replace
from pyspark.sql import functions as F
args = getResolvedOptions(sys.argv,["environment","job_name","extra_params"])
extra_params_obj = config.EXTRA_PARAMS_GLUE[args['extra_params']]

environment = args["environment"].upper()
job_name = args["job_name"]
file_name = extra_params_obj.get("file_name")
batch_status = extra_params_obj.get("batch_status")
load_type = extra_params_obj.get("load_type")
project_name  = extra_params_obj.get("project_name")
source_system = extra_params_obj.get("source_system")
stage_name = extra_params_obj.get("stage_name")
landing_zone = extra_params_obj.get("landing_zone")
staging_table_schema = extra_params_obj.get("staging_table_schema")
staging_table_name = extra_params_obj.get("staging_table_name")
target_table_schema = extra_params_obj.get("target_table_schema")
target_table_name = extra_params_obj.get("target_table_name")
audit_schema = extra_params_obj.get("audit_schema")
audit_table = extra_params_obj.get("audit_table")
created_by = extra_params_obj.get("created_by")
modified_by = extra_params_obj.get("modified_by")
owner = extra_params_obj.get("owner")
user_id = extra_params_obj.get("user_id")
src_path = config.fix_src_path(extra_params_obj.get("src_path"),environment)
   
redshift_config = config.redshift_connection[environment]
s3_staging_config = config.s3_staging_path[environment]
iam_role = config.iam_role[environment]['copy_cmd_role']
sns_arn = config.sns_arn[environment]
log_group = config.LOG_FILES_Bloomberg[environment]
staging_path = s3_staging_config + "/" + job_name + "/staging"
staging_file =staging_path + "/staging_file"


sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session


job = Job(glueContext)
job.init(job_name)

params = {
    "pipeline_name": job_name,
    "log_group_name": log_group,
	}
log_file_name = params["log_group_name"]



def sns_publish(sns_arn, email_sub, email_body):
    try:
        sns_client = boto3.client("sns")
        sns_status = sns_client.publish(
            TopicArn=sns_arn, Subject=email_sub, Message=email_body
        )
        return sns_status["ResponseMetadata"]["HTTPStatusCode"]
    except Exception as e:
        cloudwatch.log_to_stream(f"sns_publish function failed with follwoing error..... {e} ")
        raise e

def generate_email_body(alert_flag):
    try:
        alert_flag = alert_flag.upper()
        curnt_time_msg = timestamp_generator("%a %b %d %H:%M:%S %Z %Y")
        failure_email_body = config.failure_email_body
        success_email_body = config.success_email_body
        if alert_flag == "SUCCESS":
            email_body = success_email_body.format(
                job_name=job_name, run_date=curnt_time_msg, environment=environment
            )
        else:
            email_body = failure_email_body.format(
                job_name=job_name,
                run_date=curnt_time_msg,
                environment=environment,
                error=error
            )

        email_sub = f"{environment}:{alert_flag}:EDP_AXIS_{curnt_time_msg}"

        return [email_sub, email_body]

    except Exception as e:
        cloudwatch.log_to_stream(f"generate_email_body function failed with follwoing error..... {e} ")
        raise e


def timestamp_generator(format):
    try:
        
        result = datetime.now().strftime(format)
 
        return result
 
    except Exception as e:
        raise e

etl_batch_id = f"{job_name}_" + timestamp_generator("%Y%m%d%H%M%S")
cloudwatch = cloudwatch_logging.Handler(params, etl_batch_id)
cloudwatch.log_to_stream("Script started....")

batch_id = timestamp_generator("%Y%m%d%H%M%S%f")[:-3]
batch_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
job_start_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
created_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]



redshift_connection_name = redshift_config["REDSHIFT_CONNECTION_NAME"]
redshift_db_table = extra_params_obj.get('REDSHIFT_DB_TABLE')
redshift_temp_dir = redshift_config["REDSHIFT_TEMP_DIR"]
redshift_transformation_ctx = redshift_config["REDSHIFT_TRANSFORMATION_CTX"]
redshift_connection_type = "redshift"

redshift_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=redshift_connection_name)

redshift_jdbc_url = redshift_jdbc_conf["fullUrl"]
redshift_user = redshift_jdbc_conf["user"]
redshift_password = redshift_jdbc_conf["password"]
redshift_vendor = redshift_jdbc_conf["vendor"]
useConnectionProperties = "true"


try:
    redshift_properties = spark._jvm.java.util.Properties()
    redshift_properties.setProperty("url", redshift_jdbc_url)
    redshift_properties.setProperty("dbtable", redshift_db_table)
    redshift_properties.setProperty("user", redshift_user)
    redshift_properties.setProperty("password", redshift_password)
    redshift_properties.setProperty("TempDir", redshift_temp_dir)
    redshift_properties.setProperty("useConnectionProperties", useConnectionProperties)
    redshift_properties.setProperty("connectionName", redshift_connection_name)
    connection = spark._jvm.java.sql.DriverManager.getConnection(redshift_jdbc_url, redshift_properties)
     
    sql_stmt = f"""(select nvl(max(job_end_dttm),TO_DATE('1900-01-01 12:00:00','YYYY-MM-DD HH24:MI:SS')) as last_load_dttm
                from {audit_schema}.{audit_table} where target_table_name = '{target_table_name}') custom"""
    redshift_last_load_dt = spark.read.jdbc(url=redshift_jdbc_url,table=sql_stmt, properties=redshift_properties)
    auditt_last_load_dt = redshift_last_load_dt.collect()[0]["last_load_dttm"].strftime("%Y-%m-%d %H:%M:%S:%f")
    
    insert_audit = f"""INSERT INTO {audit_schema}.{audit_table}(batch_id, batch_start_dttm, batch_status, load_type, last_load_dttm, project_name, source_system, stage_name, job_name, job_start_dttm, target_table_name, landing_zone, created_dttm )
	VALUES('{batch_id}',to_timestamp('{batch_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{batch_status}','{load_type}',to_timestamp('{auditt_last_load_dt}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{project_name}','{source_system}','{stage_name}','{job_name}',to_timestamp('{job_start_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),'{target_table_name}','{landing_zone}',to_timestamp('{created_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'))"""
    statement = connection.createStatement()
    statement.executeUpdate(insert_audit)
    statement.close()
    
    sql_statement = f"""DELETE FROM {staging_table_schema}.{staging_table_name}"""
    statement = connection.createStatement()
    statement.executeUpdate(sql_statement)
    statement.close()
    
    
    
    row2 = spark.read.option("multiline","True").json(src_path)
    
    
    output1 = row2.select(
    	row2.companyKey.alias('phoenix_company_key'),
    	(upper(row2.companyName)).alias('name'),
    	row2.investmentGrade.alias('investment_grade'),
    	(when(row2.moodysCreditRating.contains(lit("_PLUS")) , regexp_replace(row2.moodysCreditRating, "_PLUS", "+")).otherwise((when(row2.moodysCreditRating.contains(lit("_MINUS")), regexp_replace(row2.moodysCreditRating, "_MINUS", "-")).otherwise(row2.moodysCreditRating)))).alias('moodys_credit_rating'),
    	(when(row2.fitchsCreditRating.contains(lit("_PLUS")) , regexp_replace(row2.fitchsCreditRating, "_PLUS", "+")) .otherwise((when(row2.fitchsCreditRating.contains(lit("_MINUS")) , regexp_replace(row2.fitchsCreditRating, "_MINUS", "-")) .otherwise(row2.fitchsCreditRating)))).alias('fitchs_credit_rating'),
    	(when(row2.sAndPCreditRating.contains(lit("_PLUS")) , regexp_replace(row2.sAndPCreditRating, "_PLUS", "+")) .otherwise((when(row2.sAndPCreditRating.contains(lit("_MINUS")) , regexp_replace(row2.sAndPCreditRating, "_MINUS", "-")) .otherwise(row2.sAndPCreditRating)))).alias('s_and_p_credit_rating'),
    	(when(row2.taxID.isNull(), None).otherwise(row2.taxID)).alias('tax_id'),
    	row2.active.alias('active'),
    	(lit(batch_id)).alias('batch_id'),
    	(lit(source_system)).alias('source_system'),
    	(lit(created_by)).alias('created_by'),
    	(lit(created_dttm)).alias('created_dttm'),
    	(lit(modified_by)).alias('modified_by'),
    	(lit(modified_dttm)).alias('modified_dttm')
    )
    
    output = output1.withColumn("name", F.regexp_replace(F.col("name"), r'\\', ''))
    
    output.write.csv(path=staging_file, sep='|',escape='\"', header=True, mode="overwrite")

    copy_query = f"""COPY {staging_table_schema}.{staging_table_name} FROM '{staging_file}' iam_role '{iam_role}' FORMAT CSV delimiter '|' QUOTE '"' IGNOREHEADER 1"""

    statement = connection.createStatement()
    statement.executeUpdate(copy_query)
    statement.close()

    count_query = f"""(SELECT * FROM {staging_table_schema}.{staging_table_name}) custom"""
    
    redshift_spark_df = spark.read.jdbc(
        redshift_jdbc_url, count_query, properties=redshift_properties)
    count_final = redshift_spark_df.count()
    
    
    job_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    batch_end_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    modified_dttm = timestamp_generator('%Y-%m-%d %H:%M:%S:%f')[:-3]
    
    update_audit = f"""Update {audit_schema}.{audit_table} set job_end_dttm = to_timestamp('{job_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'),batch_end_dttm = to_timestamp('{batch_end_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\'), records_fetched = '{count_final}',batch_status='Batch Successful', records_inserted = '{count_final}' ,  modified_dttm = to_timestamp('{modified_dttm}', \'YYYY-MM-DD HH24:MI:SS:MS\') where batch_id = {batch_id} """

    statement = connection.createStatement()
    statement.executeUpdate(update_audit)
    statement.close()
    connection.close()
    
    
    email_content = generate_email_body("success")
    email_sub = email_content[0]
    email_body = email_content[1]
    cloudwatch.log_to_stream("Publishing SNS email")
    
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Success Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Success Email not sent, with error_code = {status_code}")
    cloudwatch.log_to_stream("Writing  data to redshift has been successfully done..")
    job.commit()
except Exception as e:
    cloudwatch.log_to_stream(f"Job failed with following error ......{e}")
    error = str(e).replace("'", '"')
    email_content = generate_email_body("failure")
    email_sub = email_content[0]
    email_body = email_content[1]
    status_code = sns_publish(sns_arn, email_sub.upper(), email_body)
    if status_code == 200:
        cloudwatch.log_to_stream("Failure Email sent successfully")
    else:
        cloudwatch.log_to_stream(f"Failure Email not sent, with error_code = {status_code}")
    error_message = f"Job failed with following error: {str(e)}"
    cloudwatch.log_to_stream(error_message)
    sns_publish(sns_arn,"Glue Job Failure",f"{job_name} failed with error: {str(e)}")
    raise e
