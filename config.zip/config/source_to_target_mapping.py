# Databricks notebook source
# DBTITLE 1,Config - neer_soltn_dev
# Configuration for neer_soltn_dev catalog
# Catalogs details
catalogs = {
    "source_catalog": "sequoia_dev",    
    "target_catalog": "neer_soltn_dev"
}

# Schemas details
schemas = {
    "wind_source": {"source": "wind_curated"},
    "wind_target": {
        "foundation": "geniq_wind_bronze",
        "trusted": "geniq_wind_silver",
        "unified": "geniq_wind_gold"
    }
}

# Ref table details
ref_tables = {
    "metadata_config": "wind_bronze_metadata_ingestion",
    "metadata_log": "wind_metadata_ingestion_log",  

}
